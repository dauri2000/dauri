# Fuentes propias conservadas para IF52

Este paquete conserva33 archivos de parches propios, helpers de producción y
herramientas locales de preparación. El mod listo para instalar se entrega como
`ViaFabricPlus-Bedrock-IF52.jar`; este ZIP contiene solamente fuentes.

Se incluyen los cambios de Bedrock26.60, el ajuste de estado de élitros y los
helpers previos de atributos, inventario al volver del End y diagnóstico de
atributos desactivado por defecto. `SOURCE-MANIFEST.json` relaciona cada archivo
con su SHA256, tamaño y función, y lo vincula al JAR IF52 final.

Es una conservación parcial de fuentes, no un proyecto autónomo listo para
compilar. Las herramientas requieren el addon base exacto, las dependencias de
Java/Fabric/ViaVersion/ASM y los datos correspondientes obtenidos por separado.
Dos reconstrucciones completas de familias del mod se omitieron por no haberse
establecido de forma independiente su propiedad; sus herramientas de parcheo
sí están incluidas. Las rutas absolutas de los scripts describen el entorno
original de trabajo y necesitan adaptación para otro equipo.

No se incluyen binarios ni código descompilado de Minecraft/BDS, recursos
oficiales del juego, controles del laboratorio, telemetría, observadores,
registros, cuentas, mundos o configuración del servidor. Los productos y las
dependencias externas mantienen sus propias licencias.
