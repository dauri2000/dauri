import java.nio.file.*;
import java.io.*;
import java.util.*;
import java.util.jar.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.*;

/** Isolated surgery on the exact IF51 codec; no other existing method instruction is rebuilt. */
public final class PatchTransactionHands2225 {
    static final String ROOT = "net/raphimc/viabedrock/protocol/";
    static final String TYPE = ROOT + "types/inventory/InventoryTransactionPacketType";
    static final String DATA = ROOT + "model/inventory/InventoryTransactionData$";
    static final String HAND = ROOT + "data/enums/bedrock/generated/HandSlot";
    static final String HELPER = ROOT + "types/inventory/HandSlotWire2225";
    static final String ITEM = "L" + ROOT + "model/BedrockItem;";
    static final String POS = "L" + ROOT + "model/Position3f;";
    static final String H = "L" + HAND + ";";
    static final String OLD_ENTITY = "(JL" + ROOT + "data/enums/bedrock/generated/ItemUseOnActorActionType;I" + ITEM + POS + POS + ")V";
    static final String NEW_ENTITY = OLD_ENTITY.replace(";I" + ITEM, ";I" + H + ITEM);
    static final String OLD_RELEASE = "(L" + ROOT + "data/enums/bedrock/generated/ItemReleaseActionType;I" + ITEM + POS + ")V";
    static final String NEW_RELEASE = OLD_RELEASE.replace(")V", H + ")V");

    static void require(boolean condition, String message) {
        if (!condition) throw new IllegalStateException(message);
    }

    static String canonical(ClassNode node) {
        StringWriter out = new StringWriter();
        node.accept(new TraceClassVisitor(new PrintWriter(out)));
        return out.toString();
    }

    static AbstractInsnNode previousReal(AbstractInsnNode instruction) {
        while (instruction != null && instruction.getOpcode() < 0) instruction = instruction.getPrevious();
        return instruction;
    }

    static InsnList readHand() {
        InsnList added = new InsnList();
        added.add(new VarInsnNode(Opcodes.ALOAD, 1));
        added.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HELPER, "read", "(Lio/netty/buffer/ByteBuf;)" + H, false));
        return added;
    }

    static InsnList writeHand(String owner, int dataLocal) {
        InsnList added = new InsnList();
        added.add(new VarInsnNode(Opcodes.ALOAD, 1));
        added.add(new VarInsnNode(Opcodes.ALOAD, dataLocal));
        added.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, owner, "handSlot", "()" + H, false));
        added.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HELPER, "write", "(Lio/netty/buffer/ByteBuf;" + H + ")V", false));
        return added;
    }

    public static void main(String[] args) throws Exception {
        Path baseline = Path.of(args[0]), output = Path.of(args[1]);
        byte[] original;
        try (JarFile jar = new JarFile(baseline.toFile())) {
            original = jar.getInputStream(jar.getJarEntry(TYPE + ".class")).readAllBytes();
        }
        ClassReader reader = new ClassReader(original);
        ClassNode node = new ClassNode(); reader.accept(node, 0);
        String before = canonical(node);
        MethodNode read = node.methods.stream().filter(m -> m.name.equals("read") && m.desc.endsWith("BedrockInventoryTransaction;")).findFirst().orElseThrow();
        MethodNode write = node.methods.stream().filter(m -> m.name.equals("write") && m.desc.contains("BedrockInventoryTransaction;")).findFirst().orElseThrow();
        int sites = 0;
        for (AbstractInsnNode n : read.instructions.toArray()) {
            if (!(n instanceof MethodInsnNode call) || !call.name.equals("<init>")) continue;
            if (call.owner.equals(DATA + "UseItemOnEntityTransactionData")) {
                require(call.desc.equals(OLD_ENTITY), "Unexpected entity constructor");
                AbstractInsnNode cursor = n.getPrevious();
                MethodInsnNode itemRead = null;
                while (cursor != null && cursor.getOpcode() != Opcodes.NEW) {
                    if (cursor instanceof MethodInsnNode method && method.owner.equals("com/viaversion/viaversion/api/type/Type") && method.name.equals("read")) itemRead = method;
                    cursor = cursor.getPrevious();
                }
                require(itemRead != null, "Entity item read missing");
                AbstractInsnNode bufferLoad = previousReal(itemRead.getPrevious());
                AbstractInsnNode itemTypeLoad = previousReal(bufferLoad.getPrevious());
                require(bufferLoad instanceof VarInsnNode v && v.getOpcode() == Opcodes.ALOAD && v.var == 1, "Entity buffer load changed");
                require(itemTypeLoad instanceof VarInsnNode v && v.getOpcode() == Opcodes.ALOAD && v.var == 2, "Entity item type load changed");
                read.instructions.insertBefore(itemTypeLoad, readHand());
                call.desc = NEW_ENTITY; sites++;
            } else if (call.owner.equals(DATA + "ReleaseItemTransactionData")) {
                require(call.desc.equals(OLD_RELEASE), "Unexpected release constructor");
                read.instructions.insertBefore(call, readHand());
                call.desc = NEW_RELEASE; sites++;
            }
        }
        for (AbstractInsnNode n : write.instructions.toArray()) {
            if (!(n instanceof MethodInsnNode access)) continue;
            if ((access.owner.equals(DATA + "UseItemOnEntityTransactionData") && access.name.equals("hotbarSlot"))
                    || (access.owner.equals(DATA + "ReleaseItemTransactionData") && access.name.equals("headPosition"))) {
                AbstractInsnNode data = previousReal(access.getPrevious());
                require(data instanceof VarInsnNode v && v.getOpcode() == Opcodes.ALOAD, "Data local missing");
                int local = ((VarInsnNode)data).var;
                AbstractInsnNode cursor = access.getNext();
                MethodInsnNode fieldWrite = null;
                while (cursor != null) {
                    if (cursor instanceof MethodInsnNode method && method.name.equals("write")) { fieldWrite = method; break; }
                    cursor = cursor.getNext();
                }
                require(fieldWrite != null, "Field write missing");
                write.instructions.insert(fieldWrite, writeHand(access.owner, local)); sites++;
            }
        }
        require(sites == 4, "Expected four exact insertion sites, got " + sites);
        ClassNode reversed = new ClassNode(); node.accept(reversed);
        int removed = 0, constructors = 0;
        for (MethodNode method : reversed.methods) {
            for (AbstractInsnNode n : method.instructions.toArray()) {
                if (!(n instanceof MethodInsnNode call)) continue;
                if (call.owner.equals(HELPER)) {
                    if (call.name.equals("read")) {
                        AbstractInsnNode load = previousReal(call.getPrevious());
                        require(load instanceof VarInsnNode v && v.var == 1, "Bad inverse read");
                        method.instructions.remove(load); method.instructions.remove(call);
                    } else {
                        AbstractInsnNode accessor = previousReal(call.getPrevious());
                        AbstractInsnNode dataLoad = previousReal(accessor.getPrevious());
                        AbstractInsnNode bufferLoad = previousReal(dataLoad.getPrevious());
                        require(accessor instanceof MethodInsnNode a && a.name.equals("handSlot"), "Bad inverse write");
                        method.instructions.remove(accessor); method.instructions.remove(dataLoad);
                        method.instructions.remove(bufferLoad); method.instructions.remove(call);
                    }
                    removed++;
                } else if (call.name.equals("<init>") && call.owner.equals(DATA + "UseItemOnEntityTransactionData")) {
                    require(call.desc.equals(NEW_ENTITY), "Bad inverse entity"); call.desc = OLD_ENTITY; constructors++;
                } else if (call.name.equals("<init>") && call.owner.equals(DATA + "ReleaseItemTransactionData")) {
                    require(call.desc.equals(NEW_RELEASE), "Bad inverse release"); call.desc = OLD_RELEASE; constructors++;
                }
            }
        }
        require(removed == 4 && constructors == 2, "Incomplete inverse");
        require(before.equals(canonical(reversed)), "Original codec canonical instructions/frames changed outside allowlist");
        ClassWriter writer = new ClassWriter(reader, ClassWriter.COMPUTE_MAXS); node.accept(writer);
        Files.createDirectories(output.resolve(TYPE).getParent());
        Files.write(output.resolve(TYPE + ".class"), writer.toByteArray());
        System.out.println("PASS exact codec surgery: four insertions, two constructor descriptors; complete canonical inverse preserves all original instructions/frames");
    }
}
