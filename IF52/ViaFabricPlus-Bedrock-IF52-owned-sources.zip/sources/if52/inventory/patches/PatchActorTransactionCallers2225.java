import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.*;

/** Two-site transform composable after the independently verified animation transform. */
public final class PatchActorTransactionCallers2225 {
    static final String CLASS="net/raphimc/viabedrock/protocol/packet/ClientPlayerPackets";
    static final String HELPER="net/raphimc/viabedrock/protocol/types/inventory/ActorTransactionHand2225";
    static final String WRAPPER="com/viaversion/viaversion/api/protocol/packet/PacketWrapper";
    static final String METHOD_DESC="(L"+WRAPPER+";)V";

    static void ck(boolean ok,String why){if(!ok)throw new IllegalStateException(why);}
    static String canonical(ClassNode node){StringWriter sw=new StringWriter();node.accept(new TraceClassVisitor(new PrintWriter(sw)));return sw.toString();}
    static String sha(byte[] bytes)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));}

    public static void main(String[] args)throws Exception {
        Path input=Path.of(args[0]),output=Path.of(args[1]);String boundInputHash=args[2];
        byte[] original=Files.readAllBytes(input);ck(sha(original).equals(boundInputHash),"Input class differs from explicitly bound stage");
        ClassReader reader=new ClassReader(original);ClassNode node=new ClassNode();reader.accept(node,0);ck(node.name.equals(CLASS),"Unexpected class");
        String before=canonical(node);List<String> sites=new ArrayList<>();
        for(String name:List.of("lambda$register$8","lambda$register$9")) {
            MethodNode method=node.methods.stream().filter(m->m.name.equals(name)&&m.desc.equals(METHOD_DESC)).findFirst().orElseThrow();
            boolean nativeEntity=false;int inserted=0;
            for(AbstractInsnNode n:method.instructions.toArray()) {
                if(n instanceof FieldInsnNode field&&field.owner.equals("net/raphimc/viabedrock/protocol/data/enums/bedrock/ComplexInventoryTransaction_Type")&&field.name.equals("ItemUseOnEntityTransaction"))nativeEntity=true;
                if(!nativeEntity||!(n instanceof MethodInsnNode call)||!call.owner.equals("net/raphimc/viabedrock/api/model/container/player/InventoryContainer")||!call.name.equals("getSelectedHotbarSlot"))continue;
                AbstractInsnNode cursor=n.getNext();MethodInsnNode slotWrite=null;
                while(cursor!=null) {
                    if(cursor instanceof MethodInsnNode candidate&&candidate.owner.equals(WRAPPER)&&candidate.name.equals("write")){slotWrite=candidate;break;}
                    cursor=cursor.getNext();
                }
                ck(slotWrite!=null,"Selected-slot typed write missing");
                InsnList added=new InsnList();added.add(new VarInsnNode(Opcodes.ALOAD,0));
                added.add(new MethodInsnNode(Opcodes.INVOKESTATIC,HELPER,"writeMainHand",METHOD_DESC,false));
                method.instructions.insert(slotWrite,added);inserted++;
            }
            ck(inserted==1,"Expected exactly one accepted native actor slot write in "+name);sites.add(name);
        }
        ClassNode inverse=new ClassNode();node.accept(inverse);int removed=0;
        for(MethodNode method:inverse.methods)for(AbstractInsnNode n:method.instructions.toArray())if(n instanceof MethodInsnNode call&&call.owner.equals(HELPER)) {
            ck(sites.contains(method.name)&&call.name.equals("writeMainHand")&&call.desc.equals(METHOD_DESC),"Unexpected helper use");
            AbstractInsnNode previous=call.getPrevious();ck(previous instanceof VarInsnNode v&&v.getOpcode()==Opcodes.ALOAD&&v.var==0,"Unexpected injected wrapper load");
            method.instructions.remove(previous);method.instructions.remove(call);removed++;
        }
        ck(removed==2&&before.equals(canonical(inverse)),"Canonical inverse changed original class logic/frames/other patches");
        ClassWriter writer=new ClassWriter(reader,ClassWriter.COMPUTE_MAXS);node.accept(writer);byte[] result=writer.toByteArray();
        Files.createDirectories(output.getParent());Files.write(output,result);
        System.out.println("PASS two exact actor transaction hand insertions; inputSHA="+sha(original)+" outputSHA="+sha(result)+" completeCanonicalInverse=true");
    }
}
