import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.*;

/** One stateless post-string-decode call, preserving the existing descriptor wire layout. */
public final class PatchDescriptorNames2225 {
    static final String TYPE="net/raphimc/viabedrock/protocol/types/recipe/NetworkItemDescriptorType";
    static final String HELPER="net/raphimc/viabedrock/protocol/types/recipe/NativeDescriptorNames2225";
    static final String RECORD="net/raphimc/viabedrock/protocol/model/recipe/ItemDescriptor$ItemNameDescriptor";
    static void ck(boolean ok,String why){if(!ok)throw new IllegalStateException(why);}
    static String text(ClassNode c){StringWriter sw=new StringWriter();c.accept(new TraceClassVisitor(new PrintWriter(sw)));return sw.toString();}
    static String sha(byte[] b)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));}
    public static void main(String[] args)throws Exception{
        byte[] original=Files.readAllBytes(Path.of(args[0]));ck(sha(original).equals(args[2]),"Bound frozen source class required");
        ClassReader reader=new ClassReader(original);ClassNode c=new ClassNode();reader.accept(c,ClassReader.EXPAND_FRAMES);ck(c.name.equals(TYPE),"Unexpected type");String before=text(c);
        MethodNode read=c.methods.stream().filter(m->m.name.equals("read")&&m.desc.endsWith("ItemDescriptor;")).findFirst().orElseThrow();
        TypeInsnNode cast=null;int constructors=0;
        for(AbstractInsnNode n:read.instructions)if(n instanceof MethodInsnNode call&&call.owner.equals(RECORD)&&call.name.equals("<init>")&&call.desc.equals("(Ljava/lang/String;I)V")){
            constructors++;AbstractInsnNode cursor=n.getPrevious();
            while(cursor!=null&&cursor.getOpcode()!=Opcodes.NEW){if(cursor instanceof TypeInsnNode t&&t.getOpcode()==Opcodes.CHECKCAST&&t.desc.equals("java/lang/String")){ck(cast==null,"Unique item-name string cast");cast=t;break;}cursor=cursor.getPrevious();}
        }
        ck(constructors==1&&cast!=null,"Unique item-name branch");
        MethodInsnNode added=new MethodInsnNode(Opcodes.INVOKESTATIC,HELPER,"canonicalName","(Ljava/lang/String;)Ljava/lang/String;",false);read.instructions.insert(cast,added);
        ClassWriter writer=new ClassWriter(reader,ClassWriter.COMPUTE_MAXS);c.accept(writer);byte[] bytes=writer.toByteArray();read.instructions.remove(added);ck(before.equals(text(c)),"Canonical inverse changed other branches/methods/frames");
        Path out=Path.of(args[1]);Files.createDirectories(out.getParent());Files.write(out,bytes);
        System.out.println("{\"status\":\"PASS_SINGLE_DESCRIPTOR_NAME_NORMALIZATION_CALL\",\"canonical_inverse\":true,\"changed_read_sites\":1,\"write_unchanged\":true,\"input_sha256\":\""+sha(original)+"\",\"output_sha256\":\""+sha(bytes)+"\"}");
    }
}
