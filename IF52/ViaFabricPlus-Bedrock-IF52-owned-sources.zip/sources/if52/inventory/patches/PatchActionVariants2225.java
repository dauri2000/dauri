import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.*;

/** New native union variant, while retaining every old enum ordinal and caller ABI. */
public final class PatchActionVariants2225 {
    static final String TYPE="net/raphimc/viabedrock/protocol/data/enums/bedrock/generated/ItemStackRequestActionType";
    static final String NEW_NAME="CraftReservedAction";
    static final String CTOR="(Ljava/lang/String;II)V";
    static void ck(boolean ok,String why){if(!ok)throw new IllegalStateException(why);}
    static String text(ClassNode c){StringWriter sw=new StringWriter();c.accept(new TraceClassVisitor(new PrintWriter(sw)));return sw.toString();}
    static String sha(byte[] b)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));}
    static AbstractInsnNode integer(int value){return value>=-1&&value<=5?new InsnNode(Opcodes.ICONST_0+value):value>=-128&&value<=127?new IntInsnNode(Opcodes.BIPUSH,value):new LdcInsnNode(value);}
    static AbstractInsnNode previous(AbstractInsnNode n){while(n!=null&&n.getOpcode()<0)n=n.getPrevious();return n;}
    static int value(AbstractInsnNode n){
        if(n.getOpcode()>=Opcodes.ICONST_M1&&n.getOpcode()<=Opcodes.ICONST_5)return n.getOpcode()-Opcodes.ICONST_0;
        if(n instanceof IntInsnNode i)return i.operand;
        if(n instanceof LdcInsnNode l&&l.cst instanceof Integer i)return i;
        throw new IllegalStateException("Expected integer operand");
    }
    public static void main(String[] args)throws Exception{
        Path input=Path.of(args[0]),output=Path.of(args[1]);byte[] bytes=Files.readAllBytes(input);ck(sha(bytes).equals(args[3]),"Exact frozen enum input required");
        Map<String,Integer> target=new LinkedHashMap<>();
        for(String line:Files.readAllLines(Path.of(args[2]))){String[] p=line.split("\t");if(p.length!=3)throw new IllegalStateException("Bad bound map");int outer=Integer.parseInt(p[1]),inner=Integer.parseInt(p[2]);ck(inner==(outer<=6?outer:outer+2),"Existing native inner enum encoder no longer matches official schema");target.put(p[0],outer);}
        ck(target.size()==19&&target.get(NEW_NAME)==16,"Bound target union must include Reserved at16");
        ClassReader reader=new ClassReader(bytes);ClassNode node=new ClassNode();reader.accept(node,ClassReader.EXPAND_FRAMES);ck(node.name.equals(TYPE),"Unexpected class");String before=text(node);
        MethodNode init=node.methods.stream().filter(m->m.name.equals("<clinit>")).findFirst().orElseThrow();
        MethodNode values=node.methods.stream().filter(m->m.name.equals("$values")).findFirst().orElseThrow();
        Map<String,Integer> oldValues=new LinkedHashMap<>(),ordinals=new LinkedHashMap<>();
        Map<AbstractInsnNode,AbstractInsnNode> changed=new LinkedHashMap<>();
        for(AbstractInsnNode n:init.instructions.toArray())if(n instanceof MethodInsnNode call&&call.owner.equals(TYPE)&&call.name.equals("<init>")&&call.desc.equals(CTOR)){
            AbstractInsnNode oldValue=previous(n.getPrevious()),ordinal=previous(oldValue.getPrevious()),name=previous(ordinal.getPrevious());
            ck(name instanceof LdcInsnNode l&&l.cst instanceof String,"Constant enum name required");String constant=(String)((LdcInsnNode)name).cst;
            oldValues.put(constant,value(oldValue));ordinals.put(constant,value(ordinal));ck(target.containsKey(constant),"Unexpected baseline enum constant");
            if(target.get(constant)!=value(oldValue)){AbstractInsnNode replacement=integer(target.get(constant));init.instructions.set(oldValue,replacement);changed.put(replacement,oldValue);}
        }
        ck(oldValues.size()==18&&ordinals.get("CraftNonImplemented")==16&&ordinals.get("CraftResults")==17,"Expected18 original stable ordinals");
        ck(changed.size()==2,"Only native NonImplemented/Results variant values may shift");
        FieldNode reserved=new FieldNode(Opcodes.ACC_PUBLIC|Opcodes.ACC_STATIC|Opcodes.ACC_FINAL|Opcodes.ACC_ENUM,NEW_NAME,"L"+TYPE+";",null,null);node.fields.add(reserved);
        MethodInsnNode valuesCall=null;
        for(AbstractInsnNode n:init.instructions)if(n instanceof MethodInsnNode call&&call.owner.equals(TYPE)&&call.name.equals("$values")){ck(valuesCall==null,"Unique values initializer");valuesCall=call;}
        ck(valuesCall!=null,"Values initializer exists");
        InsnList addedInit=new InsnList();addedInit.add(new TypeInsnNode(Opcodes.NEW,TYPE));addedInit.add(new InsnNode(Opcodes.DUP));addedInit.add(new LdcInsnNode(NEW_NAME));addedInit.add(integer(18));addedInit.add(integer(16));addedInit.add(new MethodInsnNode(Opcodes.INVOKESPECIAL,TYPE,"<init>",CTOR,false));addedInit.add(new FieldInsnNode(Opcodes.PUTSTATIC,TYPE,NEW_NAME,"L"+TYPE+";"));
        List<AbstractInsnNode> initNodes=new ArrayList<>();for(AbstractInsnNode n:addedInit)initNodes.add(n);init.instructions.insertBefore(valuesCall,addedInit);
        AbstractInsnNode first=values.instructions.getFirst();while(first.getOpcode()<0)first=first.getNext();ck(value(first)==18,"Expected original values length18");AbstractInsnNode length=integer(19);values.instructions.set(first,length);
        AbstractInsnNode ret=null;for(AbstractInsnNode n:values.instructions)if(n.getOpcode()==Opcodes.ARETURN){ck(ret==null,"Unique array return");ret=n;}
        InsnList addedValue=new InsnList();addedValue.add(new InsnNode(Opcodes.DUP));addedValue.add(integer(18));addedValue.add(new FieldInsnNode(Opcodes.GETSTATIC,TYPE,NEW_NAME,"L"+TYPE+";"));addedValue.add(new InsnNode(Opcodes.AASTORE));
        List<AbstractInsnNode> valueNodes=new ArrayList<>();for(AbstractInsnNode n:addedValue)valueNodes.add(n);values.instructions.insertBefore(ret,addedValue);
        ClassWriter writer=new ClassWriter(reader,ClassWriter.COMPUTE_MAXS);node.accept(writer);byte[] result=writer.toByteArray();
        node.fields.remove(reserved);for(AbstractInsnNode n:initNodes)init.instructions.remove(n);for(AbstractInsnNode n:valueNodes)values.instructions.remove(n);values.instructions.set(length,first);changed.forEach((now,old)->init.instructions.set(now,old));
        ck(text(node).equals(before),"Canonical inverse must restore all original methods, enum ordinals and frames");
        Files.createDirectories(output.getParent());Files.write(output,result);
        System.out.println("{\"status\":\"PASS_RESERVED_VARIANT_INSERTION_ONLY\",\"original_ordinals_preserved\":18,\"shifted_variant_values\":2,\"added_reserved_ordinal\":18,\"added_reserved_variant\":16,\"canonical_inverse\":true,\"input_sha256\":\""+sha(bytes)+"\",\"output_sha256\":\""+sha(result)+"\"}");
    }
}
