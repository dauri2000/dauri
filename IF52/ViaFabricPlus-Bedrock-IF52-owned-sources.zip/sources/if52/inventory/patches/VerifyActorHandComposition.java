import java.nio.file.*;
import java.io.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.*;

/** Read the actual written classes, then reverse the two independently frozen stages in order. */
public final class VerifyActorHandComposition {
    static ClassNode read(Path path)throws Exception{ClassNode node=new ClassNode();new ClassReader(Files.readAllBytes(path)).accept(node,ClassReader.EXPAND_FRAMES);return node;}
    static String text(ClassNode node){StringWriter sw=new StringWriter();node.accept(new TraceClassVisitor(new PrintWriter(sw)));return sw.toString();}
    static int reverse(ClassNode node,String owner,String[] methods){
        int count=0;
        for(MethodNode method:node.methods)for(AbstractInsnNode n:method.instructions.toArray())if(n instanceof MethodInsnNode call&&call.owner.equals(owner)){
            if(!java.util.List.of(methods).contains(method.name)||!call.name.equals("writeMainHand"))throw new AssertionError("Unexpected composition call");
            AbstractInsnNode previous=call.getPrevious();if(!(previous instanceof VarInsnNode v)||v.getOpcode()!=Opcodes.ALOAD||v.var!=0)throw new AssertionError("Unexpected wrapper local");
            method.instructions.remove(previous);method.instructions.remove(call);count++;
        }
        return count;
    }
    public static void main(String[] args)throws Exception{
        ClassNode combined=read(Path.of(args[0])),animation=read(Path.of(args[1])),baseline=read(Path.of(args[2]));
        int actorSites=reverse(combined,"net/raphimc/viabedrock/protocol/types/inventory/ActorTransactionHand2225",new String[]{"lambda$register$8","lambda$register$9"});
        if(actorSites!=2||!text(combined).equals(text(animation)))throw new AssertionError("Written combined class does not reverse to frozen animation stage");
        int animateSites=reverse(combined,"net/raphimc/viabedrock/protocol/model/Protocol2225Hands",new String[]{"lambda$register$20"});
        if(animateSites!=1||!text(combined).equals(text(baseline)))throw new AssertionError("Written composition does not reverse to complete original IF51 CPP");
        System.out.println("{\"status\":\"PASS_WRITTEN_CLASSES_ORDERED_CANONICAL_INVERSE\",\"actor_sites\":"+actorSites+",\"animate_sites\":"+animateSites+",\"original_methods_preserved\":"+baseline.methods.size()+",\"IF51_portal_inventory_fix_retained\":true}");
    }
}
