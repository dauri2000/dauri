package net.raphimc.viabedrock.protocol.types.recipe;

/** Remove only the redundant native aux suffix, leaving the separately encoded aux value authoritative. */
public final class NativeDescriptorNames2225 {
    private NativeDescriptorNames2225() {}

    public static String canonicalName(String identifier) {
        int first = identifier.indexOf(':');
        int last = identifier.lastIndexOf(':');
        // A canonical namespace:path may itself have a numeric path (addon:123).
        // An aux decoration needs a second colon and nonempty namespace/path.
        if (first <= 0 || last <= first + 1 || last == identifier.length() - 1
                || identifier.indexOf(':', first + 1) != last) return identifier;
        for (int i = last + 1; i < identifier.length(); i++) {
            char value = identifier.charAt(i);
            if (value < '0' || value > '9') return identifier;
        }
        return identifier.substring(0, last);
    }
}
