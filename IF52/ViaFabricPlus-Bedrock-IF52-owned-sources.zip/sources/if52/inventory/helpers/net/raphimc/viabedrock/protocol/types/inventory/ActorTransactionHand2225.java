package net.raphimc.viabedrock.protocol.types.inventory;

import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Types;
import net.raphimc.viabedrock.protocol.data.enums.bedrock.generated.HandSlot;

/** Accepted Java26.3 ATTACK/INTERACT routes use the selected main-hand item. */
public final class ActorTransactionHand2225 {
    private ActorTransactionHand2225() {}

    public static void writeMainHand(PacketWrapper wrapper) {
        wrapper.write(Types.UNSIGNED_BYTE, (short) HandSlot.Mainhand.getValue());
    }
}
