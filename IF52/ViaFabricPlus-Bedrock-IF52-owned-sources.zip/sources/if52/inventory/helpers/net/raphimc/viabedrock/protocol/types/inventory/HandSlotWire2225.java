package net.raphimc.viabedrock.protocol.types.inventory;

import io.netty.buffer.ByteBuf;
import java.util.Objects;
import net.raphimc.viabedrock.protocol.data.enums.bedrock.generated.HandSlot;

/** The additional one-byte native hand field, corroborated by Mojang schema and Cloudburst v2225. */
public final class HandSlotWire2225 {
    private HandSlotWire2225() {}

    public static HandSlot read(ByteBuf buffer) {
        int value = buffer.readUnsignedByte();
        HandSlot hand = HandSlot.getByValue(value);
        if (hand == null) throw new IllegalArgumentException("Unknown Bedrock hand slot: " + value);
        return hand;
    }

    public static void write(ByteBuf buffer, HandSlot hand) {
        buffer.writeByte(Objects.requireNonNull(hand, "handSlot").getValue());
    }
}
