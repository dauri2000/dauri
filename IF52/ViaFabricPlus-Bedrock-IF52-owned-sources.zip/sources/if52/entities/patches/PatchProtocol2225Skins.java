import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.*;
import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;

/** Provisional schema-2225-only patch: never changes the protocol selector or public JAR. */
public final class PatchProtocol2225Skins implements Opcodes {
    private static final String B = "net/raphimc/viabedrock/protocol/types/BedrockTypes";
    private static final String S = "net/raphimc/viabedrock/protocol/model/SkinData";
    private static final String H = "net/raphimc/viabedrock/protocol/model/Protocol2225Skins";
    private static final String WR = "com/viaversion/viaversion/api/protocol/packet/PacketWrapper";
    private static final String TY = "Lcom/viaversion/viaversion/api/type/Type;";

    private static void require(boolean condition, String why) {
        if (!condition) throw new IllegalStateException(why);
    }
    private static List<AbstractInsnNode> real(MethodNode m) {
        List<AbstractInsnNode> result = new ArrayList<>();
        for (AbstractInsnNode n : m.instructions) if (n.getOpcode() >= 0) result.add(n);
        return result;
    }
    private static MethodNode method(ClassNode c, String name, String desc) {
        return c.methods.stream().filter(m -> m.name.equals(name) && m.desc.equals(desc)).findFirst().orElseThrow();
    }
    private static String canonical(ClassNode c) {
        StringWriter out = new StringWriter();
        c.accept(new TraceClassVisitor(new PrintWriter(out)));
        return out.toString();
    }
    private static List<AbstractInsnNode> cloneNodes(List<AbstractInsnNode> nodes) {
        Map<LabelNode, LabelNode> labels = new IdentityHashMap<>();
        List<AbstractInsnNode> result = new ArrayList<>();
        for (AbstractInsnNode node : nodes) result.add(node.clone(labels));
        return result;
    }
    private static byte[] write(ClassNode c, ClassReader reader) {
        ClassWriter writer = new ClassWriter(reader, ClassWriter.COMPUTE_MAXS);
        c.accept(writer); return writer.toByteArray();
    }
    private static boolean field(AbstractInsnNode n, String name) {
        return n instanceof FieldInsnNode f && f.getOpcode() == GETSTATIC && f.owner.equals(B) && f.name.equals(name);
    }
    private static String sha(byte[] data) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
    }
    public static void main(String[] args) throws Exception {
        Path base = Path.of(args[0]), out = Path.of(args[1]);
        byte[] skinBytes, hudBytes;
        try (ZipFile jar = new ZipFile(base.toFile())) {
            skinBytes = jar.getInputStream(jar.getEntry("net/raphimc/viabedrock/protocol/types/model/SkinType.class")).readAllBytes();
            hudBytes = jar.getInputStream(jar.getEntry("net/raphimc/viabedrock/protocol/packet/HudPackets.class")).readAllBytes();
        }
        ClassReader sr = new ClassReader(skinBytes); ClassNode skin = new ClassNode(); sr.accept(skin, 0);
        String skinBefore = canonical(skin);
        MethodNode read = method(skin, "read", "(Lio/netty/buffer/ByteBuf;)L" + S + ";");
        List<AbstractInsnNode> ri = real(read);
        require(ri.size() > 15 && field(ri.get(0), "STRING") && field(ri.get(5), "STRING") && field(ri.get(10), "STRING"), "three initial skin strings");
        List<AbstractInsnNode> removedRead = new ArrayList<>(ri.subList(5, 9));
        require(ri.get(9) instanceof VarInsnNode v && v.getOpcode() == ASTORE && v.var == 3, "PlayFab local3");
        LdcInsnNode empty = new LdcInsnNode(""); read.instructions.insertBefore(removedRead.getFirst(), empty);
        for (AbstractInsnNode n : removedRead) read.instructions.remove(n);

        MethodNode write = method(skin, "write", "(Lio/netty/buffer/ByteBuf;L" + S + ";)V");
        List<AbstractInsnNode> wi = real(write); int play = -1;
        for (int i = 0; i < wi.size(); i++) if (wi.get(i) instanceof MethodInsnNode call && call.owner.equals(S) && call.name.equals("playFabId")) {
            require(play == -1, "one PlayFab writer"); play = i;
        }
        require(play >= 3 && field(wi.get(play - 3), "STRING"), "PlayFab writer prefix");
        List<AbstractInsnNode> removedWrite = new ArrayList<>(wi.subList(play - 3, play + 2));
        AbstractInsnNode writeNext = removedWrite.getLast().getNext();
        require(removedWrite.getLast() instanceof MethodInsnNode c && c.name.equals("write"), "PlayFab writer call");
        for (AbstractInsnNode n : removedWrite) write.instructions.remove(n);
        byte[] patchedSkin = write(skin, sr);
        // Canonical inverse proves every other method/instruction/frame remains exactly as before.
        for (AbstractInsnNode n : removedRead) read.instructions.insertBefore(empty, n);
        read.instructions.remove(empty);
        for (AbstractInsnNode n : removedWrite) write.instructions.insertBefore(writeNext, n);
        require(canonical(skin).equals(skinBefore), "skin canonical inverse");

        ClassReader hr = new ClassReader(hudBytes); ClassNode hud = new ClassNode(); hr.accept(hud, 0);
        String hudBefore = canonical(hud);
        MethodNode list = method(hud, "lambda$register$0", "(L" + WR + ";)V");
        List<AbstractInsnNode> li = real(list); FieldInsnNode skinField = null; int si = -1;
        for (int i = 0; i < li.size(); i++) if (field(li.get(i), "SKIN")) { require(skinField == null, "one list skin"); skinField = (FieldInsnNode) li.get(i); si = i; }
        require(si > 0, "skin list read");
        List<Integer> stringFields = new ArrayList<>();
        for (int i = 0; i < si; i++) if (field(li.get(i), "STRING")) stringFields.add(i);
        require(stringFields.size() == 3, "name xuid platform before skin");
        int pi = stringFields.get(2);
        List<AbstractInsnNode> platformRead = new ArrayList<>(li.subList(pi - 1, pi + 4));
        require(platformRead.getFirst() instanceof VarInsnNode v && v.getOpcode() == ALOAD && v.var == 0, "wrapper load");
        require(platformRead.getLast() instanceof VarInsnNode v && v.getOpcode() == ASTORE, "platform store");
        int savedMaxLocals = list.maxLocals, savedMaxStack = list.maxStack;
        int playFabLocal = list.maxLocals++;
        List<AbstractInsnNode> addedRead = cloneNodes(platformRead);
        ((VarInsnNode) addedRead.getLast()).var = playFabLocal;
        for (AbstractInsnNode n : addedRead) list.instructions.insertBefore(platformRead.getFirst(), n);
        AbstractInsnNode skinStore = li.get(si + 3);
        require(skinStore instanceof VarInsnNode v && v.getOpcode() == ASTORE, "skin store");
        int skinLocal = ((VarInsnNode) skinStore).var;
        for (AbstractInsnNode n = platformRead.getFirst(); n != skinStore; n = n.getNext()) require(!(n instanceof FrameNode) && !(n instanceof JumpInsnNode), "new local is straight-line only");
        InsnList tail = new InsnList();
        tail.add(new VarInsnNode(ALOAD, skinLocal)); tail.add(new VarInsnNode(ALOAD, playFabLocal));
        tail.add(new MethodInsnNode(INVOKESTATIC, H, "withPlayFabId", "(L" + S + ";Ljava/lang/String;)L" + S + ";", false));
        tail.add(new VarInsnNode(ASTORE, skinLocal));
        List<AbstractInsnNode> addedTail = new ArrayList<>(); for (AbstractInsnNode n : tail) addedTail.add(n);
        list.instructions.insert(skinStore, tail);
        byte[] patchedHud = write(hud, hr);
        for (AbstractInsnNode n : addedRead) list.instructions.remove(n);
        for (AbstractInsnNode n : addedTail) list.instructions.remove(n);
        list.maxLocals = savedMaxLocals; list.maxStack = savedMaxStack;
        require(canonical(hud).equals(hudBefore), "HUD canonical inverse");
        Path sp = out.resolve("net/raphimc/viabedrock/protocol/types/model/SkinType.class"); Files.createDirectories(sp.getParent()); Files.write(sp, patchedSkin);
        Path hp = out.resolve("net/raphimc/viabedrock/protocol/packet/HudPackets.class"); Files.createDirectories(hp.getParent()); Files.write(hp, patchedHud);
        System.out.println("{\"status\":\"PASS_PROVISIONAL_2225_SKIN_PLAYER_LIST_PATCH\",\"skin_before\":\"" + sha(skinBytes) + "\",\"skin_after\":\"" + sha(patchedSkin) + "\",\"hud_before\":\"" + sha(hudBytes) + "\",\"hud_after\":\"" + sha(patchedHud) + "\",\"skin_canonical_inverse\":true,\"hud_canonical_inverse\":true,\"new_hud_local\":" + playFabLocal + ",\"new_target_protocol_claimed\":false}");
    }
}
