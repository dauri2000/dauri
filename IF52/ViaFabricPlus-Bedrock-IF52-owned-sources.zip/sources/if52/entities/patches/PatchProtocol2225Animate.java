import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.*;
import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;

/** Isolated field-level 2225 animation prototype; retains IF51 Java logic and portal fix. */
public final class PatchProtocol2225Animate implements Opcodes {
    static final String WR="com/viaversion/viaversion/api/protocol/packet/PacketWrapper";
    static final String B="net/raphimc/viabedrock/protocol/types/BedrockTypes";
    static final String H="net/raphimc/viabedrock/protocol/model/Protocol2225Hands";
    static void ck(boolean ok,String why){if(!ok)throw new IllegalStateException(why);}
    static List<AbstractInsnNode> code(MethodNode m){List<AbstractInsnNode> r=new ArrayList<>();for(AbstractInsnNode n:m.instructions)if(n.getOpcode()>=0)r.add(n);return r;}
    static MethodNode method(ClassNode c,String name){return c.methods.stream().filter(m->m.name.equals(name)).findFirst().orElseThrow();}
    static String dump(ClassNode c){StringWriter out=new StringWriter();c.accept(new TraceClassVisitor(new PrintWriter(out)));return out.toString();}
    static boolean field(AbstractInsnNode n,String owner,String name){return n instanceof FieldInsnNode f&&f.owner.equals(owner)&&f.name.equals(name);}
    static byte[] write(ClassNode c,ClassReader reader){ClassWriter w=new ClassWriter(reader,ClassWriter.COMPUTE_MAXS);c.accept(w);return w.toByteArray();}
    static String sha(byte[] b)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));}
    static List<AbstractInsnNode> list(InsnList list){List<AbstractInsnNode> r=new ArrayList<>();for(AbstractInsnNode n:list)r.add(n);return r;}
    static AbstractInsnNode optionalCall(MethodNode m,String name){
        List<AbstractInsnNode> nodes=code(m);AbstractInsnNode result=null;
        for(int i=0;i<nodes.size();i++)if(field(nodes.get(i),B,"OPTIONAL_STRING")){
            MethodInsnNode call=null;
            for(int j=i+1;j<nodes.size()&&j<i+12;j++)if(nodes.get(j) instanceof MethodInsnNode c&&c.owner.equals(WR)&&c.name.equals(name)){call=c;break;}
            ck(call!=null&&result==null,"unique optional "+name);result=call;
        }
        ck(result!=null,"optional call present");return result;
    }
    static byte[] incoming(byte[] bytes)throws Exception{
        ClassReader reader=new ClassReader(bytes);ClassNode c=new ClassNode();reader.accept(c,ClassReader.EXPAND_FRAMES);String before=dump(c);
        MethodNode m=method(c,"lambda$register$13");int oldLocals=m.maxLocals,oldStack=m.maxStack,handLocal=m.maxLocals++;
        AbstractInsnNode read=optionalCall(m,"read"),pop=read.getNext();while(pop.getOpcode()<0)pop=pop.getNext();ck(pop.getOpcode()==POP,"optional read discarded");
        InsnList add=new InsnList();add.add(new VarInsnNode(ALOAD,0));add.add(new MethodInsnNode(INVOKESTATIC,H,"read","(L"+WR+";)I",false));add.add(new VarInsnNode(ISTORE,handLocal));List<AbstractInsnNode> added=list(add);m.instructions.insert(pop,add);
        Map<FrameNode,List<Object>> savedFrames=new IdentityHashMap<>();boolean after=false;
        for(AbstractInsnNode n:m.instructions){
            if(n==pop)after=true;
            if(n instanceof FrameNode f){
                ck(after,"no frame before native hand read");ck(f.type==F_NEW,"expanded frame");savedFrames.put(f,new ArrayList<>(f.local));
                int slots=0;for(Object type:f.local)slots+=type.equals(LONG)||type.equals(DOUBLE)?2:1;
                ck(slots<=handLocal,"new local outside old frame");while(slots++<handLocal)f.local.add(TOP);f.local.add(INTEGER);
            }
        }
        List<AbstractInsnNode> nodes=code(m);AbstractInsnNode zero=null;
        for(int i=0;i<nodes.size();i++)if(field(nodes.get(i),"com/viaversion/viaversion/protocols/v26_2to26_3/packet/ClientboundPackets26_3","SWING_ANIMATION")){
            for(int j=i+1;j<i+8&&j<nodes.size();j++)if(nodes.get(j).getOpcode()==ICONST_0){ck(zero==null,"single Java swing hand");zero=nodes.get(j);}
        }
        ck(zero!=null,"Java mainhand old constant");VarInsnNode load=new VarInsnNode(ILOAD,handLocal);m.instructions.set(zero,load);
        byte[] result=write(c,reader);
        m.instructions.set(load,zero);for(AbstractInsnNode n:added)m.instructions.remove(n);savedFrames.forEach((f,locals)->f.local=locals);m.maxLocals=oldLocals;m.maxStack=oldStack;
        ck(dump(c).equals(before),"incoming canonical inverse of every method and frame");return result;
    }
    static byte[] outgoing(byte[] bytes,String methodName,int wrapperLocal)throws Exception{
        ClassReader reader=new ClassReader(bytes);ClassNode c=new ClassNode();reader.accept(c,ClassReader.EXPAND_FRAMES);String before=dump(c);
        MethodNode m=method(c,methodName);AbstractInsnNode call=optionalCall(m,"write");InsnList add=new InsnList();
        add.add(new VarInsnNode(ALOAD,wrapperLocal));add.add(new MethodInsnNode(INVOKESTATIC,H,"writeMainHand","(L"+WR+";)V",false));List<AbstractInsnNode> added=list(add);m.instructions.insert(call,add);
        byte[] result=write(c,reader);for(AbstractInsnNode n:added)m.instructions.remove(n);ck(dump(c).equals(before),"outgoing canonical inverse "+methodName);return result;
    }
    public static void main(String[] args)throws Exception{
        Path base=Path.of(args[0]),out=Path.of(args[1]);String prefix="net/raphimc/viabedrock/";
        Map<String,byte[]> old=new LinkedHashMap<>(),patched=new LinkedHashMap<>();
        try(ZipFile z=new ZipFile(base.toFile())){for(String n:List.of("protocol/packet/EntityPackets.class","protocol/packet/ClientPlayerPackets.class","api/model/entity/ClientPlayerEntity.class"))old.put(prefix+n,z.getInputStream(z.getEntry(prefix+n)).readAllBytes());}
        String entity=prefix+"protocol/packet/EntityPackets.class",cpp=prefix+"protocol/packet/ClientPlayerPackets.class",cpe=prefix+"api/model/entity/ClientPlayerEntity.class";
        ck(sha(old.get(cpp)).equals("67ee4831fdd041fe1734f53a750cfc4c5b8aaa3fc03de92276bb05d9cf03f8d7"),"exact retained IF51 portal-inventory fix input");
        patched.put(entity,incoming(old.get(entity)));patched.put(cpp,outgoing(old.get(cpp),"lambda$register$20",0));patched.put(cpe,outgoing(old.get(cpe),"sendSwingPacketToServer",1));
        List<String> rows=new ArrayList<>();for(var e:patched.entrySet()){Path p=out.resolve(e.getKey());Files.createDirectories(p.getParent());Files.write(p,e.getValue());rows.add("{\"entry\":\""+e.getKey()+"\",\"before_sha256\":\""+sha(old.get(e.getKey()))+"\",\"after_sha256\":\""+sha(e.getValue())+"\"}");}
        System.out.println("{\"status\":\"PASS_PROVISIONAL_2225_ANIMATION_PATCH\",\"all_original_instructions_and_frames_canonical_inverse\":true,\"IF51_CPP_portal_fix_retained\":true,\"PUNCH_has_no_hand_input\":true,\"native_hand_incoming_validated_0_or_1\":true,\"native_emitters_write_main_hand_0\":true,\"classes\":["+String.join(",",rows)+"],\"runtime_support_claimed\":false}");
    }
}
