import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.TraceClassVisitor;

import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;

/** Composable, isolated AddActor/AddPlayer passenger-reader insertion.
 * Usage: INPUT_JAR_OR_DIR OUTPUT_DIR [FALLBACK_JAR_FOR_MISSING_DIR_CLASSES]
 * Does not copy any unrelated class, mutate the input, or produce a complete JAR.
 */
public final class PatchProtocol2225Passengers implements Opcodes {
    private static final String ROOT = "net/raphimc/viabedrock/protocol/packet/";
    private static final String B = "net/raphimc/viabedrock/protocol/types/BedrockTypes";
    private static final String WR = "com/viaversion/viaversion/api/protocol/packet/PacketWrapper";
    private static final String H = "net/raphimc/viabedrock/protocol/model/Protocol2225Passengers";
    private static final String RD = "(L" + WR + ";)L" + H + "$Passenger;";
    private record Target(String owner, String method, int store) {}
    private static final List<Target> TARGETS = List.of(
            new Target(ROOT + "EntityPackets", "lambda$register$1", 14),
            new Target(ROOT + "OtherPlayerPackets", "lambda$register$2", 17));

    private static void require(boolean value, String message) {
        if (!value) throw new IllegalStateException(message);
    }
    private static String sha(byte[] bytes) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
    }
    private static ClassNode parse(byte[] bytes) {
        ClassNode node = new ClassNode();
        new ClassReader(bytes).accept(node, ClassReader.EXPAND_FRAMES);
        return node;
    }
    private static String canonical(ClassNode node) {
        StringWriter out = new StringWriter();
        node.accept(new TraceClassVisitor(new PrintWriter(out)));
        return out.toString();
    }
    private static MethodNode target(ClassNode node, Target t) {
        List<MethodNode> found = node.methods.stream().filter(m -> m.name.equals(t.method)
                && m.desc.equals("(L" + WR + ";)V")).toList();
        require(found.size() == 1, "Unique target method " + t.method);
        return found.getFirst();
    }
    private static AbstractInsnNode nextCode(AbstractInsnNode node) {
        do { node = node.getNext(); } while (node != null && node.getOpcode() < 0);
        return node;
    }
    private static AbstractInsnNode insertionPoint(MethodNode method, Target t) {
        List<AbstractInsnNode> fields = new ArrayList<>();
        for (AbstractInsnNode n : method.instructions) {
            if (n instanceof MethodInsnNode c && c.owner.equals(H)) {
                throw new IllegalStateException("Passenger helper already inserted");
            }
            if (n instanceof FieldInsnNode f && f.getOpcode() == GETSTATIC
                    && f.owner.equals(B) && f.name.equals("ENTITY_LINK_ARRAY")) fields.add(n);
        }
        require(fields.size() == 1, "Exactly one native entity-links read");
        AbstractInsnNode read = nextCode(fields.getFirst());
        require(read instanceof MethodInsnNode c && c.getOpcode() == INVOKEINTERFACE
                && c.owner.equals(WR) && c.name.equals("read")
                && c.desc.equals("(Lcom/viaversion/viaversion/api/type/Type;)Ljava/lang/Object;"),
                "Entity links followed by typed wrapper.read");
        AbstractInsnNode cast = nextCode(read);
        require(cast instanceof TypeInsnNode c && c.getOpcode() == CHECKCAST
                && c.desc.equals("[Lnet/raphimc/viabedrock/protocol/model/EntityLink;"), "Entity-links cast");
        AbstractInsnNode store = nextCode(cast);
        require(store instanceof VarInsnNode s && s.getOpcode() == ASTORE && s.var == t.store,
                "Expected original entity-links local");
        return store;
    }
    private static List<AbstractInsnNode> inserted(MethodNode m) {
        List<MethodInsnNode> calls = new ArrayList<>();
        for (AbstractInsnNode n : m.instructions)
            if (n instanceof MethodInsnNode c && c.owner.equals(H) && c.name.equals("read")) calls.add(c);
        require(calls.size() == 1, "Exactly one persisted passenger read");
        MethodInsnNode call = calls.getFirst();
        AbstractInsnNode load = call.getPrevious(), pop = call.getNext();
        require(load instanceof VarInsnNode l && l.getOpcode() == ALOAD && l.var == 0,
                "Passenger wrapper load unchanged");
        require(call.getOpcode() == INVOKESTATIC && call.desc.equals(RD) && !call.itf,
                "Passenger helper static descriptor unchanged");
        require(pop != null && pop.getOpcode() == POP, "Typed passenger result explicitly unused");
        return List.of(load, call, pop);
    }
    private static byte[] patch(byte[] original, Target t) {
        ClassReader reader = new ClassReader(original);
        ClassNode node = parse(original);
        require(node.name.equals(t.owner), "Expected input class owner");
        String before = canonical(node);
        MethodNode method = target(node, t);
        AbstractInsnNode anchor = insertionPoint(method, t);
        InsnList add = new InsnList();
        add.add(new VarInsnNode(ALOAD, 0));
        add.add(new MethodInsnNode(INVOKESTATIC, H, "read", RD, false));
        add.add(new InsnNode(POP));
        method.instructions.insert(anchor, add);
        List<AbstractInsnNode> added = inserted(method);
        ClassWriter writer = new ClassWriter(reader, ClassWriter.COMPUTE_MAXS);
        node.accept(writer);
        byte[] result = writer.toByteArray();

        for (AbstractInsnNode n : added) method.instructions.remove(n);
        require(canonical(node).equals(before), "Canonical inverse preserves every original method and frame");

        ClassNode disk = parse(result);
        MethodNode persisted = target(disk, t);
        for (AbstractInsnNode n : inserted(persisted)) persisted.instructions.remove(n);
        require(canonical(disk).equals(before), "Persisted class canonical inverse preserves every method and frame");
        return result;
    }
    private static byte[] read(Path source, String entry, Path fallback) throws Exception {
        if (Files.isDirectory(source)) {
            Path file = source.resolve(entry);
            if (Files.isRegularFile(file)) return Files.readAllBytes(file);
            require(fallback != null, "Missing input directory class; give explicit fallback JAR: " + entry);
            source = fallback;
        }
        try (ZipFile zip = new ZipFile(source.toFile())) {
            ZipEntry found = zip.getEntry(entry);
            require(found != null, "Required input JAR entry: " + entry);
            return zip.getInputStream(found).readAllBytes();
        }
    }
    public static void main(String[] args) throws Exception {
        require(args.length == 2 || args.length == 3, "INPUT_JAR_OR_DIR OUTPUT_DIR [FALLBACK_JAR]");
        Path input = Path.of(args[0]), output = Path.of(args[1]);
        Path fallback = args.length == 3 ? Path.of(args[2]) : null;
        List<String> rows = new ArrayList<>();
        for (Target t : TARGETS) {
            String entry = t.owner + ".class";
            byte[] before = read(input, entry, fallback), after = patch(before, t);
            Path target = output.resolve(entry);
            require(!Files.exists(target), "Refuse to overwrite an existing output class: " + target);
            Files.createDirectories(target.getParent()); Files.write(target, after);
            rows.add("{\"entry\":\"" + entry + "\",\"input_sha256\":\"" + sha(before)
                    + "\",\"output_sha256\":\"" + sha(after)
                    + "\",\"target_method\":\"" + t.method
                    + "\",\"canonical_inverse_all_methods_and_frames\":true}");
        }
        String report = "{\"status\":\"PASS_PROVISIONAL_2225_PASSENGER_WIRE_INSERTIONS\","
                + "\"classes\":[" + String.join(",", rows) + "],"
                + "\"insertions\":2,\"true_passenger_semantics_supported\":false,"
                + "\"runtime_26_60_compatibility_claimed\":false}\n";
        Files.writeString(output.resolve("passenger-patch-verification.json"), report);
        System.out.print(report);
    }
}
