package net.raphimc.viabedrock.protocol.model;

/** Native 2225 moves PlayFab identity from serialized skin to player-list entries. */
public final class Protocol2225Skins {
    private Protocol2225Skins() {}

    public static SkinData withPlayFabId(SkinData skin, String playFabId) {
        return new SkinData(skin.skinId(), playFabId, skin.skinResourcePatch(), skin.skinData(),
                skin.animations(), skin.capeData(), skin.geometryData(), skin.geometryDataEngineVersion(),
                skin.animationData(), skin.premium(), skin.persona(), skin.capeOnClassic(),
                skin.primaryUser(), skin.capeId(), skin.fullSkinId(), skin.armSize(), skin.skinColor(),
                skin.personaPieces(), skin.tintColors(), skin.overridingPlayerAppearance(),
                skin.trustedSkinFlag(), skin.profileHash());
    }
}
