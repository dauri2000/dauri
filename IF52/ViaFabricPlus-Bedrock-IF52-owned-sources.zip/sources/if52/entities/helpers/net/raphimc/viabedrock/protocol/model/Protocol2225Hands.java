package net.raphimc.viabedrock.protocol.model;

import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Types;

/** Mandatory hand byte added by the native 2225 Animate serializer. */
public final class Protocol2225Hands {
    private Protocol2225Hands() {}

    public static int read(PacketWrapper wrapper) {
        int hand = wrapper.read(Types.UNSIGNED_BYTE);
        if (hand > 1) throw new IllegalArgumentException("Invalid native animation hand: " + hand);
        return hand;
    }

    public static void writeMainHand(PacketWrapper wrapper) {
        // Java26.3 PUNCH and the mining helper have no offhand input field.
        wrapper.write(Types.UNSIGNED_BYTE, (short) 0);
    }
}
