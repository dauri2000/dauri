package net.raphimc.viabedrock.protocol.model;

import com.viaversion.viaversion.api.minecraft.BlockPosition;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Types;
import net.raphimc.viabedrock.protocol.types.BedrockTypes;

/** Native protocol 2225's optional PassengerOfBlockArguments wire representation.
 *
 * This reader provides complete, typed consumption. Java block-passenger pose and
 * camera behavior are separate work and are deliberately not inferred here.
 */
public final class Protocol2225Passengers {
    public enum Emote {
        STANDING, RIDING, LAYING;

        static Emote fromWire(final short value) {
            return switch (value) {
                case 0 -> STANDING;
                case 1 -> RIDING;
                case 2 -> LAYING;
                default -> throw new IllegalArgumentException("Invalid protocol 2225 block passenger emote: " + value);
            };
        }
    }

    public record Passenger(BlockPosition blockPosition, Position3f offset,
                            float rotation, float rotationLimit, Emote emote) {}

    private Protocol2225Passengers() {}

    public static Passenger read(final PacketWrapper wrapper) {
        if (!wrapper.read(Types.BOOLEAN)) {
            return null;
        }
        final BlockPosition blockPosition = wrapper.read(BedrockTypes.BLOCK_POSITION);
        final Position3f offset = wrapper.read(BedrockTypes.POSITION_3F);
        final float rotation = wrapper.read(BedrockTypes.FLOAT_LE);
        final float rotationLimit = wrapper.read(BedrockTypes.FLOAT_LE);
        final Emote emote = Emote.fromWire(wrapper.read(Types.UNSIGNED_BYTE));
        return new Passenger(blockPosition, offset, rotation, rotationLimit, emote);
    }
}
