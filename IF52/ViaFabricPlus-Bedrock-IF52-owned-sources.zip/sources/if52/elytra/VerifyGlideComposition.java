import java.nio.file.*;
import java.io.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.*;

/** Re-reads written candidate and removes only added method; entire remaining class must match. */
public final class VerifyGlideComposition {
  static ClassNode read(Path p)throws Exception{ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(p)).accept(c,ClassReader.EXPAND_FRAMES);return c;}
  static String text(ClassNode c){StringWriter s=new StringWriter();c.accept(new TraceClassVisitor(new PrintWriter(s)));return s.toString();}
  public static void main(String[] a)throws Exception {
    ClassNode before=read(Path.of(a[0])),after=read(Path.of(a[1]));
    int count=after.methods.size();
    if(!after.methods.removeIf(m->m.name.equals("translateEntityData")&&m.desc.equals(PatchGlideMetadata.DESC)))throw new AssertionError("Missing added override");
    if(after.methods.size()!=count-1||!text(before).equals(text(after)))throw new AssertionError("Original class changed beyond added override");
    System.out.println("PASS written-class canonical inverse: originalMethods="+before.methods.size()+" originalFields="+before.fields.size()+" retained exactly; new metadata override only; main-hand/passenger additions preserved; CPP untouched");
  }
}
