import java.nio.file.*;
import java.security.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Isolated candidate only. Adds one metadata override; every existing method stays byte-for-byte as ASM events. */
public final class PatchGlideMetadata {
  static final String OWNER="net/raphimc/viabedrock/api/model/entity/ClientPlayerEntity";
  static final String SUPER="net/raphimc/viabedrock/api/model/entity/PlayerEntity";
  static final String IDS="net/raphimc/viabedrock/protocol/data/enums/bedrock/ActorDataIds";
  static final String FLAGS="net/raphimc/viabedrock/protocol/data/enums/bedrock/ActorFlags";
  static final String DESC="(L"+IDS+";Lcom/viaversion/viaversion/api/minecraft/entitydata/EntityData;Ljava/util/List;)Z";
  static String sha(byte[] b)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));}
  public static void main(String[] a)throws Exception {
    byte[] before=Files.readAllBytes(Path.of(a[0]));
    if(!sha(before).equals("36894a8f92f1f22e526b15eae7bfecee02b606718cb16741bd8f25bc7ffa4dcc"))throw new IllegalArgumentException("Expected composed staged CPE with hand/passenger fixes");
    ClassReader cr=new ClassReader(before);ClassNode c=new ClassNode();cr.accept(c,0);
    if(!c.name.equals(OWNER)||!c.superName.equals(SUPER)||c.methods.stream().anyMatch(m->m.name.equals("translateEntityData")))throw new IllegalStateException("Unexpected input class");
    MethodNode m=new MethodNode(Opcodes.ACC_PROTECTED,"translateEntityData",DESC,"(L"+IDS+";Lcom/viaversion/viaversion/api/minecraft/entitydata/EntityData;Ljava/util/List<Lcom/viaversion/viaversion/api/minecraft/entitydata/EntityData;>;)Z",null);
    m.visitCode();
    m.visitVarInsn(Opcodes.ALOAD,0);m.visitVarInsn(Opcodes.ALOAD,1);m.visitVarInsn(Opcodes.ALOAD,2);m.visitVarInsn(Opcodes.ALOAD,3);
    m.visitMethodInsn(Opcodes.INVOKESPECIAL,SUPER,"translateEntityData",DESC,false);m.visitVarInsn(Opcodes.ISTORE,4);
    Label done=new Label();m.visitVarInsn(Opcodes.ALOAD,1);m.visitFieldInsn(Opcodes.GETSTATIC,IDS,"RESERVED_0","L"+IDS+";");m.visitJumpInsn(Opcodes.IF_ACMPNE,done);
    m.visitVarInsn(Opcodes.ALOAD,0);m.visitVarInsn(Opcodes.ALOAD,0);m.visitMethodInsn(Opcodes.INVOKEVIRTUAL,OWNER,"entityFlags","()Ljava/util/Set;",false);
    m.visitFieldInsn(Opcodes.GETSTATIC,FLAGS,"GLIDING","L"+FLAGS+";");m.visitMethodInsn(Opcodes.INVOKEINTERFACE,"java/util/Set","contains","(Ljava/lang/Object;)Z",true);
    m.visitFieldInsn(Opcodes.PUTFIELD,OWNER,"gliding","Z");
    m.visitLabel(done);m.visitFrame(Opcodes.F_APPEND,1,new Object[]{Opcodes.INTEGER},0,null);m.visitVarInsn(Opcodes.ILOAD,4);m.visitInsn(Opcodes.IRETURN);m.visitMaxs(4,5);m.visitEnd();c.methods.add(m);
    // Preserve every preexisting frame/max value; the sole new branch has one explicit append frame.
    ClassWriter cw=new ClassWriter(cr,0);c.accept(cw);byte[] after=cw.toByteArray();
    Path out=Path.of(a[1]);Files.createDirectories(out.getParent());Files.write(out,after);
    System.out.println("PASS input="+sha(before)+" candidate="+sha(after)+" existingMethods="+(c.methods.size()-1)+" addedMethods=1");
  }
}
