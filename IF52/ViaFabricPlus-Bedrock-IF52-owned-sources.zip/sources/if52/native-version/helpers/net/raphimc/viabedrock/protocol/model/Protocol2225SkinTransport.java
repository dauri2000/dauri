package net.raphimc.viabedrock.protocol.model;
import io.netty.buffer.ByteBuf;
import net.raphimc.viabedrock.protocol.types.BedrockTypes;
/** Internal2225fragmentidentity envelope. NeverusedasnativeBedrockSkincodec. */
public final class Protocol2225SkinTransport {
    private Protocol2225SkinTransport() {}
    public static void writeIdentity(ByteBuf buffer, SkinData skin) {
        BedrockTypes.STRING.write(buffer, skin.playFabId());
    }
    public static SkinData readInternal(ByteBuf buffer) {
        String identity = BedrockTypes.STRING.read(buffer);
        return Protocol2225Skins.withPlayFabId(BedrockTypes.SKIN.read(buffer), identity);
    }
}
