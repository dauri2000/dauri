import java.nio.file.*;
import java.util.*;
import java.security.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.*;
public final class PatchSoundType {
 static String key(MethodNode m){return m.name+m.desc;}
 static String body(MethodNode m){Textifier t=new Textifier();m.accept(new TraceMethodVisitor(t));return t.getText().toString();}
 static String sha(byte[]v)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(v));}
 public static void main(String[]a)throws Exception{
  byte[]before=Files.readAllBytes(Path.of(a[0])),replacement=Files.readAllBytes(Path.of(a[1]));
  ClassReader reader=new ClassReader(before);ClassNode original=new ClassNode(),template=new ClassNode();reader.accept(original,0);new ClassReader(replacement).accept(template,0);
  if(!original.name.equals(template.name)||!original.superName.equals(template.superName)||original.version!=template.version||!original.fields.isEmpty()||!template.fields.isEmpty())throw new AssertionError("class identity changed");
  String read="read(Lio/netty/buffer/ByteBuf;)Lnet/raphimc/viabedrock/protocol/model/SoundUpdate;",write="write(Lio/netty/buffer/ByteBuf;Lnet/raphimc/viabedrock/protocol/model/SoundUpdate;)V";
  Set<String>allowed=Set.of(read,write);Map<String,String>oldBodies=new TreeMap<>();Map<String,MethodNode>source=new HashMap<>();for(MethodNode m:template.methods)source.put(key(m),m);
  int changes=0;
  for(MethodNode m:original.methods){oldBodies.put(key(m),body(m));if(!allowed.contains(key(m)))continue;MethodNode n=source.get(key(m));if(n==null||m.access!=n.access)throw new AssertionError("missing method");m.instructions=n.instructions;m.tryCatchBlocks=n.tryCatchBlocks;m.maxStack=n.maxStack;m.maxLocals=n.maxLocals;m.localVariables=n.localVariables;m.visibleLocalVariableAnnotations=n.visibleLocalVariableAnnotations;m.invisibleLocalVariableAnnotations=n.invisibleLocalVariableAnnotations;changes++;}
  if(changes!=2||original.methods.size()!=5)throw new AssertionError("unexpected changed methods");
  ClassWriter out=new ClassWriter(reader,0);original.accept(out);byte[]result=out.toByteArray();ClassNode check=new ClassNode();new ClassReader(result).accept(check,0);List<String>actual=new ArrayList<>();
  for(MethodNode m:check.methods){boolean differs=!Objects.equals(oldBodies.get(key(m)),body(m));if(differs)actual.add(key(m));if(differs!=allowed.contains(key(m)))throw new AssertionError("unapproved method delta:"+key(m));}
  if(!Objects.equals(original.nestHostClass,check.nestHostClass)||!original.interfaces.equals(check.interfaces)||check.fields.size()!=0||check.methods.size()!=5)throw new AssertionError("class structure changed");
  Files.createDirectories(Path.of(a[2]).getParent());Files.write(Path.of(a[2]),result);
  System.out.println("original_sha256="+sha(before));System.out.println("candidate_sha256="+sha(result));System.out.println("unchanged_constructor_and_bridges=3");for(String m:actual)System.out.println("modified="+m);System.out.println("PASS_ONLY_TWO_TYPED_METHOD_BODIES_CHANGED");
 }
}
