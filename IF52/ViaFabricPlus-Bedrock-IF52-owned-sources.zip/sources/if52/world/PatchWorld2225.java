import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.TraceClassVisitor;

/** Private parser prototype for the corroborated 2225 fields; not a complete adapter. */
public final class PatchWorld2225 implements Opcodes {
  static final String WRAPPER="com/viaversion/viaversion/api/protocol/packet/PacketWrapper";
  static final String BT="net/raphimc/viabedrock/protocol/types/BedrockTypes";
  static final String TYPES="com/viaversion/viaversion/api/type/Types";
  static final String READ="(Lcom/viaversion/viaversion/api/type/Type;)Ljava/lang/Object;";
  record Edit(MethodNode method, AbstractInsnNode anchor, List<AbstractInsnNode> nodes) {}
  static void require(boolean value,String message){if(!value)throw new AssertionError(message);}
  static String sha(byte[] value)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value));}
  static String trace(ClassNode value){StringWriter s=new StringWriter();value.accept(new TraceClassVisitor(new PrintWriter(s)));return s.toString();}
  static AbstractInsnNode next(AbstractInsnNode value){do{value=value.getNext();}while(value!=null&&value.getOpcode()<0);return value;}
  static boolean field(AbstractInsnNode n,String owner,String name){return n instanceof FieldInsnNode f&&f.getOpcode()==GETSTATIC&&f.owner.equals(owner)&&f.name.equals(name);}
  static MethodNode method(ClassNode c,String name){return c.methods.stream().filter(m->m.name.equals(name)&&m.desc.equals("(L"+WRAPPER+";)V")).findFirst().orElseThrow();}
  static AbstractInsnNode readPop(AbstractInsnNode load,String owner,String name){
    require(load instanceof VarInsnNode v&&v.getOpcode()==ALOAD&&v.var==0,"Missing wrapper load");
    AbstractInsnNode f=next(load),call=next(f),pop=next(call);
    require(field(f,owner,name),"Wrong field at parser anchor "+name);
    require(call instanceof MethodInsnNode m&&m.getOpcode()==INVOKEINTERFACE&&m.owner.equals(WRAPPER)&&m.name.equals("read")&&m.desc.equals(READ)&&m.itf,"Wrong wrapper read");
    require(pop.getOpcode()==POP,"Expected discarded existing field");return pop;
  }
  static InsnList consume(String owner,String name,String desc){
    InsnList value=new InsnList();value.add(new VarInsnNode(ALOAD,0));value.add(new FieldInsnNode(GETSTATIC,owner,name,desc));
    value.add(new MethodInsnNode(INVOKEINTERFACE,WRAPPER,"read",READ,true));value.add(new InsnNode(POP));return value;
  }
  static void add(List<Edit> edits,MethodNode method,AbstractInsnNode anchor,InsnList extra){
    List<AbstractInsnNode> nodes=new ArrayList<>();for(AbstractInsnNode n:extra)nodes.add(n);
    method.instructions.insert(anchor,extra);edits.add(new Edit(method,anchor,nodes));
  }
  public static void main(String[] args)throws Exception {
    require(args.length==3,"Expected original.class output.class expectedSHA256");
    byte[] original=Files.readAllBytes(Path.of(args[0]));require(sha(original).equals(args[2]),"Unapproved IF51 class");
    ClassNode c=new ClassNode();new ClassReader(original).accept(c,0);String before=trace(c);List<Edit> edits=new ArrayList<>();
    if(c.name.equals("net/raphimc/viabedrock/protocol/packet/JoinPackets")){
      MethodNode start=method(c,"lambda$register$3");List<AbstractInsnNode> editor=new ArrayList<>();
      for(AbstractInsnNode n:start.instructions)if(n instanceof MethodInsnNode m&&m.owner.equals("net/raphimc/viabedrock/protocol/data/enums/bedrock/generated/EditorWorldType")&&m.name.equals("getByValue"))editor.add(n);
      require(editor.size()==1,"Ambiguous EditorWorldType parse");AbstractInsnNode store=next(editor.getFirst());
      require(store.getOpcode()==ASTORE,"Missing editor enum store");
      AbstractInsnNode created=readPop(next(store),TYPES,"BOOLEAN");AbstractInsnNode exported=readPop(next(created),TYPES,"BOOLEAN");
      require(field(next(next(exported)),BT,"VAR_INT"),"Day cycle no longer follows editor flags");
      add(edits,start,exported,consume(TYPES,"BYTE","Lcom/viaversion/viaversion/api/type/types/ByteType;"));

      MethodNode dimensions=method(c,"lambda$register$5");List<AbstractInsnNode> uuids=new ArrayList<>();
      for(AbstractInsnNode n:dimensions.instructions)if(field(n,BT,"UUID"))uuids.add(n);
      require(uuids.size()==1,"Ambiguous dimension UUID");AbstractInsnNode uuidRead=next(uuids.getFirst()),uuidPop=next(uuidRead);
      require(uuidPop.getOpcode()==POP,"Dimension UUID retention changed");AbstractInsnNode defaultBiome=readPop(next(uuidPop),BT,"STRING");
      InsnList fields=consume(BT,"VAR_INT","Lnet/raphimc/viabedrock/protocol/types/primitive/VarIntType;");
      fields.add(consume(TYPES,"BOOLEAN","Lcom/viaversion/viaversion/api/type/types/BooleanType;"));
      add(edits,dimensions,defaultBiome,fields);
      require(edits.size()==2,"Expected two JoinPackets sites");
    }else if(c.name.equals("net/raphimc/viabedrock/protocol/packet/WorldPackets")){
      MethodNode chunk=method(c,"lambda$register$2");List<AbstractInsnNode> arrays=new ArrayList<>();
      for(AbstractInsnNode n:chunk.instructions)if(field(n,BT,"BYTE_ARRAY"))arrays.add(n);
      require(arrays.size()==1,"Ambiguous LEVEL_CHUNK payload");AbstractInsnNode call=next(arrays.getFirst()),cast=next(call),store=next(cast);
      require(call instanceof MethodInsnNode m&&m.owner.equals(WRAPPER)&&m.name.equals("read")&&m.desc.equals(READ),"Wrong payload read");
      require(cast instanceof TypeInsnNode t&&t.getOpcode()==CHECKCAST&&t.desc.equals("[B")&&store.getOpcode()==ASTORE,"Wrong serialized chunk retention");
      add(edits,chunk,store,consume(TYPES,"BOOLEAN","Lcom/viaversion/viaversion/api/type/types/BooleanType;"));
      require(edits.size()==1,"Expected one WorldPackets site");
    }else throw new AssertionError("Unexpected parser class");
    ClassWriter writer=new ClassWriter(new ClassReader(original),0);c.accept(writer);byte[] candidate=writer.toByteArray();
    // No labels, jumps, local slots, max stack or frames were changed. Reverse each
    // exact inserted node list and compare the complete original class canonically.
    for(Edit edit:edits)for(AbstractInsnNode n:edit.nodes)edit.method.instructions.remove(n);
    require(trace(c).equals(before),"An original method, frame, instruction or field changed");
    Path output=Path.of(args[1]);Files.createDirectories(output.getParent());Files.write(output,candidate);
    System.out.println("PASS "+c.name+" parser_sites="+edits.size()+" original_methods="+c.methods.size()+" canonical_reversal=exact sha256="+sha(candidate));
  }
}
