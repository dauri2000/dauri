package com.viaversion.viafabricplus.bedrock.diagnostics;

import io.netty.buffer.ByteBuf;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.HexFormat;

/** Read-only bounded prefix observation; never decodes, retains or modifies a packet. */
public final class AttributeDecodePrefix {
    public static final int UPDATE_ATTRIBUTES_ID = 134;
    public static final int ATTRIBUTE_LIMIT = 128;
    public static final int PREFIX_LIMIT = 8192;
    private AttributeDecodePrefix() {}

    public record Prefix(int readerIndex, int writerIndex, int headerBytes,
                         int entityId, int declaredCount) {}
    public record Snapshot(int readableBytes, int capturedPrefixBytes, boolean truncated,
                           String prefixSha256, String prefixBase64) {}

    /** Returns only a complete, well-formed ID134/entity/count prefix with count >128. */
    public static Prefix malformedCount(ByteBuf input) {
        int start = input.readerIndex();
        int end = input.writerIndex();
        int[] cursor = {start};
        Integer packetId = unsignedVarIntBits(input, cursor, end);
        if (packetId == null || packetId != UPDATE_ATTRIBUTES_ID) return null;
        Integer entityId = unsignedVarIntBits(input, cursor, end);
        if (entityId == null) return null;
        Integer count = unsignedVarIntBits(input, cursor, end);
        if (count == null || count <= ATTRIBUTE_LIMIT) return null;
        return new Prefix(start, end, cursor[0] - start, entityId, count);
    }

    /** Reads the Java32-bit VarInt representation using absolute access only. */
    private static Integer unsignedVarIntBits(ByteBuf input, int[] cursor, int end) {
        int value = 0;
        for (int n = 0; n < 5; n++) {
            if (cursor[0] >= end) return null;
            int next = input.getUnsignedByte(cursor[0]++);
            if (n == 4 && (next & 0xf0) != 0) return null;
            value |= (next & 0x7f) << (7 * n);
            if ((next & 0x80) == 0) return value;
        }
        return null;
    }

    public static Snapshot snapshot(ByteBuf input, Prefix prefix) {
        if (input.readerIndex() != prefix.readerIndex() || input.writerIndex() != prefix.writerIndex()) {
            throw new IllegalStateException("Diagnostic input changed after prefix observation");
        }
        int readable = prefix.writerIndex() - prefix.readerIndex();
        int length = Math.min(readable, PREFIX_LIMIT);
        byte[] bytes = new byte[length];
        input.getBytes(prefix.readerIndex(), bytes);
        try {
            String digest = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
            return new Snapshot(readable, length, readable > length, digest,
                    Base64.getEncoder().encodeToString(bytes));
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 unavailable", impossible);
        }
    }
}
