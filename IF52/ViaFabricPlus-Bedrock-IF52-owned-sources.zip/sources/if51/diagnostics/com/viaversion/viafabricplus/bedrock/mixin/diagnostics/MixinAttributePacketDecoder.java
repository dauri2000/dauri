package com.viaversion.viafabricplus.bedrock.mixin.diagnostics;

import com.viaversion.viafabricplus.bedrock.diagnostics.AttributeDecodeDiagnostics;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import java.util.List;
import net.minecraft.network.PacketDecoder;
import net.minecraft.network.ProtocolInfo;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = PacketDecoder.class, remap = false)
public abstract class MixinAttributePacketDecoder {
    @Shadow @Final private ProtocolInfo<?> protocolInfo;

    @Inject(method = "decode(Lio/netty/channel/ChannelHandlerContext;Lio/netty/buffer/ByteBuf;Ljava/util/List;)V",
            at = @At("HEAD"), require = 1)
    private void bedrock$observeMalformedAttributes(ChannelHandlerContext context, ByteBuf input,
                                                   List<Object> packets, CallbackInfo callback) {
        AttributeDecodeDiagnostics.beforeDecode(context, input, protocolInfo);
    }
}
