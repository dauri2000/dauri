package com.viaversion.viafabricplus.bedrock.diagnostics;

import com.viaversion.viafabricplus.ViaFabricPlus;
import com.viaversion.viafabricplus.protocoltranslator.ProtocolTranslationImpl;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.libs.gson.JsonObject;
import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.function.Consumer;
import net.minecraft.network.Connection;
import net.minecraft.network.ConnectionProtocol;
import net.minecraft.network.ProtocolInfo;
import net.minecraft.network.protocol.PacketFlow;
import net.raphimc.viabedrock.protocol.BedrockProtocol;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Optional observation at the actual Java decoder. Never changes packet handling. */
public final class AttributeDecodeDiagnostics {
    public static final String PROPERTY = "viabedrock.attributeDecodeDiagnostics";
    public static final String MARKER = "[IF51-ATTRIBUTE-DECODE]";
    public static final int GLOBAL_LIMIT = 4;
    private static final Logger LOGGER = LoggerFactory.getLogger("ViaFabricPlus-Bedrock-AttributeDecode");
    private static final Map<Channel, Boolean> CAPTURED = new WeakHashMap<>();
    private static int captures;
    private AttributeDecodeDiagnostics() {}

    /** Called by a non-cancellable HEAD injection; even diagnostic failures cannot escape. */
    public static void beforeDecode(ChannelHandlerContext context, ByteBuf input, ProtocolInfo<?> protocol) {
        try {
            observe(context, input, protocol, value -> LOGGER.info("{} {}", MARKER, value));
        } catch (Throwable ignored) {
            // Observation must never alter the original decoder's success, failure or indices.
        }
    }

    private static void observe(ChannelHandlerContext context, ByteBuf input, ProtocolInfo<?> protocol,
                                Consumer<String> sink) {
        if (!Boolean.getBoolean(PROPERTY) || context == null || input == null || protocol == null
                || protocol.id() != ConnectionProtocol.PLAY || protocol.flow() != PacketFlow.CLIENTBOUND) return;
        AttributeDecodePrefix.Prefix prefix = AttributeDecodePrefix.malformedCount(input);
        if (prefix == null) return;
        Channel channel = context.channel();
        if (channel == null || !channel.hasAttr(ProtocolTranslationImpl.MINECRAFT_CONNECTION_ATTRIBUTE_KEY)) return;
        Connection connection = channel.attr(ProtocolTranslationImpl.MINECRAFT_CONNECTION_ATTRIBUTE_KEY).get();
        if (connection == null || ViaFabricPlus.api() == null) return;
        UserConnection via = ViaFabricPlus.api().protocolTranslation().userConnection(connection);
        if (via == null || via.getChannel() != channel || via.getProtocolInfo() == null
                || via.getProtocolInfo().serverProtocolVersion() == null
                || via.getProtocolInfo().serverProtocolVersion().getVersion() != 2193
                || via.getProtocolInfo().getPipeline() == null
                || !via.getProtocolInfo().getPipeline().contains(BedrockProtocol.class)) return;
        int ordinal;
        synchronized (CAPTURED) {
            if (captures >= GLOBAL_LIMIT || CAPTURED.containsKey(channel)) return;
            CAPTURED.put(channel, Boolean.TRUE);
            ordinal = ++captures;
        }
        AttributeDecodePrefix.Snapshot snapshot = AttributeDecodePrefix.snapshot(input, prefix);
        JsonObject row = new JsonObject();
        row.addProperty("schema", 1);
        row.addProperty("source", "PacketDecoder.decode:HEAD");
        row.addProperty("java_protocol", protocol.id().id());
        row.addProperty("java_flow", protocol.flow().name());
        row.addProperty("native_protocol", 2193);
        row.addProperty("bedrock_pipeline_present", true);
        row.addProperty("via_connection_matches_channel", true);
        row.addProperty("via_active", via.isActive());
        row.addProperty("channel_active", channel.isActive());
        row.addProperty("via_client_state", String.valueOf(via.getProtocolInfo().getClientState()));
        row.addProperty("via_server_state", String.valueOf(via.getProtocolInfo().getServerState()));
        row.addProperty("java_packet_id_unsigned", Integer.toUnsignedLong(AttributeDecodePrefix.UPDATE_ATTRIBUTES_ID));
        row.addProperty("java_entity_id_unsigned", Integer.toUnsignedLong(prefix.entityId()));
        row.addProperty("declared_attribute_count", prefix.declaredCount());
        row.addProperty("attribute_count_limit", AttributeDecodePrefix.ATTRIBUTE_LIMIT);
        row.addProperty("prefix_header_bytes", prefix.headerBytes());
        row.addProperty("readable_bytes", snapshot.readableBytes());
        row.addProperty("captured_prefix_bytes", snapshot.capturedPrefixBytes());
        row.addProperty("truncated", snapshot.truncated());
        row.addProperty("prefix_sha256", snapshot.prefixSha256());
        row.addProperty("prefix_base64", snapshot.prefixBase64());
        row.addProperty("capture_ordinal", ordinal);
        row.addProperty("captures_per_connection_limit", 1);
        row.addProperty("captures_process_limit", GLOBAL_LIMIT);
        sink.accept(row.toString());
    }
}
