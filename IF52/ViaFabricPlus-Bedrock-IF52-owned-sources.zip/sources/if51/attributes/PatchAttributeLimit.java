import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.TraceClassVisitor;

public final class PatchAttributeLimit {
  static String trace(ClassNode c){StringWriter s=new StringWriter();c.accept(new TraceClassVisitor(new PrintWriter(s)));return s.toString();}
  public static void main(String[] a)throws Exception {
    byte[] input=Files.readAllBytes(Path.of(a[0]));String sha=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(input));
    if(!sha.equals(a[2]))throw new AssertionError("Baseline LivingEntity hash differs");
    ClassReader reader=new ClassReader(input);ClassNode c=new ClassNode();reader.accept(c,0);
    if(!c.name.equals("net/raphimc/viabedrock/api/model/entity/LivingEntity"))throw new AssertionError("Wrong class");
    String old=trace(c);MethodNode m=c.methods.stream().filter(x->x.name.equals("updateAttributes")&&x.desc.equals("([Lnet/raphimc/viabedrock/protocol/model/EntityAttribute;Lcom/viaversion/viaversion/api/protocol/packet/PacketWrapper;)V")).findFirst().orElseThrow();
    List<AbstractInsnNode> returns=new ArrayList<>();for(AbstractInsnNode n:m.instructions)if(n.getOpcode()==Opcodes.RETURN)returns.add(n);
    if(returns.size()!=1)throw new AssertionError("Expected the single original final return");
    InsnList addition=new InsnList();VarInsnNode load=new VarInsnNode(Opcodes.ALOAD,2);MethodInsnNode call=new MethodInsnNode(Opcodes.INVOKESTATIC,"net/raphimc/viabedrock/api/util/BoundedJavaAttributes","splitIfNecessary","(Lcom/viaversion/viaversion/api/protocol/packet/PacketWrapper;)V",false);addition.add(load);addition.add(call);m.instructions.insertBefore(returns.getFirst(),addition);
    ClassWriter writer=new ClassWriter(reader,ClassWriter.COMPUTE_MAXS);c.accept(writer);Path dest=Path.of(a[1]);Files.createDirectories(dest.getParent());Files.write(dest,writer.toByteArray());
    m.instructions.remove(load);m.instructions.remove(call);if(!trace(c).equals(old))throw new AssertionError("Canonical reversal changed original class");
    System.out.println("PASS one final wrapper helper call; "+c.methods.size()+" original methods and all original instructions/frames preserved under canonical reversal");
  }
}
