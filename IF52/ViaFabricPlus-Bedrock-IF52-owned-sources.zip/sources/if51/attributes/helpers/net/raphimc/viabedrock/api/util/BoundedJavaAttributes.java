package net.raphimc.viabedrock.api.util;

import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Types;
import com.viaversion.viaversion.protocols.v26_2to26_3.packet.ClientboundPackets26_3;
import net.raphimc.viabedrock.protocol.BedrockProtocol;
import net.raphimc.viabedrock.ViaBedrock;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/** Retains all translated snapshots while respecting Java's per-packet list bound. */
public final class BoundedJavaAttributes {
    private static final int MAX_ATTRIBUTES = 128;
    private static final AtomicInteger DIAGNOSTIC_LINES = new AtomicInteger();
    private BoundedJavaAttributes() {}

    public static void splitIfNecessary(PacketWrapper original) throws Exception {
        int count = original.get(Types.VAR_INT, 1);
        if (count <= MAX_ATTRIBUTES) return;
        if (original.getPacketType() != ClientboundPackets26_3.UPDATE_ATTRIBUTES)
            throw new IllegalArgumentException("Expected translated UPDATE_ATTRIBUTES");
        int entity = original.get(Types.VAR_INT, 0);
        int ints = 2, doubles = 0, strings = 0, bytes = 0;
        List<Snapshot> snapshots = new ArrayList<>(count);
        // Read and validate the complete translated body before sending any prefix.
        // Typed access never changes reader indices, consumes input, or serializes a wrapper.
        for (int i = 0; i < count; i++) {
            int attribute = original.get(Types.VAR_INT, ints++);
            double base = original.get(Types.DOUBLE, doubles++);
            int modifierCount = original.get(Types.VAR_INT, ints++);
            if (attribute < 0 || modifierCount < 0)
                throw new IllegalArgumentException("Invalid translated attribute count or ID");
            List<Modifier> modifiers = new ArrayList<>(modifierCount);
            for (int j = 0; j < modifierCount; j++) {
                String id = Objects.requireNonNull(original.get(Types.STRING, strings++));
                double amount = original.get(Types.DOUBLE, doubles++);
                byte operation = original.get(Types.BYTE, bytes++);
                if (operation < 0 || operation > 2)
                    throw new IllegalArgumentException("Invalid translated attribute operation");
                modifiers.add(new Modifier(id, amount, operation));
            }
            snapshots.add(new Snapshot(attribute, base, modifiers));
        }
        if (original.is(Types.VAR_INT, ints) || original.is(Types.DOUBLE, doubles)
                || original.is(Types.STRING, strings) || original.is(Types.BYTE, bytes))
            throw new IllegalArgumentException("Trailing translated attribute fields");
        int lastStart = ((count - 1) / MAX_ATTRIBUTES) * MAX_ATTRIBUTES;
        List<PacketWrapper> prefixes = new ArrayList<>(lastStart / MAX_ATTRIBUTES);
        for (int start = 0; start < lastStart; start += MAX_ATTRIBUTES) {
            PacketWrapper prefix = PacketWrapper.create(ClientboundPackets26_3.UPDATE_ATTRIBUTES, original.user());
            write(prefix, entity, snapshots, start, start + MAX_ATTRIBUTES);
            prefixes.add(prefix);
        }
        // Prefix packets retain the same remaining protocol path as the original wrapper.
        for (PacketWrapper prefix : prefixes) prefix.send(BedrockProtocol.class);
        // Let the caller/pipeline send the final batch normally; no packet is cancelled.
        original.clearPacket();
        write(original, entity, snapshots, lastStart, count);
        diagnostic(entity, count);
    }

    private static void diagnostic(int entity, int count) {
        try {
            if (!Boolean.getBoolean("viabedrock.attributeDecodeDiagnostics")) return;
            int current;
            do {
                current = DIAGNOSTIC_LINES.get();
                if (current >= 4) return;
            } while (!DIAGNOSTIC_LINES.compareAndSet(current, current + 1));
            StringBuilder batches = new StringBuilder("[");
            for (int start = 0; start < count; start += MAX_ATTRIBUTES) {
                if (start != 0) batches.append(',');
                batches.append(Math.min(MAX_ATTRIBUTES, count - start));
            }
            batches.append(']');
            ViaBedrock.getPlatform().getLogger().info("[IF51-ATTRIBUTE-SPLIT] javaEntityId=" + entity
                    + " originalAttributes=" + count + " batches=" + batches);
        } catch (RuntimeException ignored) {
            // Optional diagnostics cannot interrupt an already prepared attribute update.
        }
    }

    private static void write(PacketWrapper target, int entity, List<Snapshot> snapshots, int from, int to) {
        target.write(Types.VAR_INT, entity);
        target.write(Types.VAR_INT, to - from);
        for (int i = from; i < to; i++) {
            Snapshot snapshot = snapshots.get(i);
            target.write(Types.VAR_INT, snapshot.attribute());
            target.write(Types.DOUBLE, snapshot.base());
            target.write(Types.VAR_INT, snapshot.modifiers().size());
            for (Modifier modifier : snapshot.modifiers()) {
                target.write(Types.STRING, modifier.id());
                target.write(Types.DOUBLE, modifier.amount());
                target.write(Types.BYTE, modifier.operation());
            }
        }
    }
    private record Snapshot(int attribute, double base, List<Modifier> modifiers) {}
    private record Modifier(String id, double amount, byte operation) {}
}
