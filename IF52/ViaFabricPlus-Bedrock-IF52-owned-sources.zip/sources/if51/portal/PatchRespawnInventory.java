import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.TraceClassVisitor;

/** Isolated candidate only: resend the retained or death-cleared cache after respawn. */
public final class PatchRespawnInventory {
  static final String OWNER="net/raphimc/viabedrock/protocol/packet/ClientPlayerPackets";
  static String trace(ClassNode node) {
    StringWriter out=new StringWriter();node.accept(new TraceClassVisitor(new PrintWriter(out)));return out.toString();
  }
  static AbstractInsnNode next(AbstractInsnNode n){do{n=n.getNext();}while(n!=null&&n.getOpcode()<0);return n;}
  public static void main(String[] args)throws Exception {
    byte[] input=Files.readAllBytes(Path.of(args[0]));
    String sha=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(input));
    if(!sha.equals("c833b164912b1d4cac4dc2a5f1449ce2cbfe8f353069b198023efedd63b599ae"))throw new AssertionError("Unexpected baseline hash");
    ClassNode c=new ClassNode();new ClassReader(input).accept(c,0);
    if(!c.name.equals(OWNER))throw new AssertionError("Wrong class");
    String original=trace(c);
    MethodNode m=c.methods.stream().filter(x->x.name.equals("lambda$register$0")&&x.desc.equals("(Lcom/viaversion/viaversion/api/protocol/packet/PacketWrapper;)V")).findFirst().orElseThrow();
    List<JumpInsnNode> guards=new ArrayList<>();
    for(AbstractInsnNode n:m.instructions)if(n instanceof LdcInsnNode ldc&&"keepInventory".equals(ldc.cst)){
      AbstractInsnNode getter=next(n), cast=next(getter), bool=next(cast), branch=next(bool);
      if(!(getter instanceof MethodInsnNode g)||!g.owner.equals("net/raphimc/viabedrock/protocol/storage/GameRulesStorage")||!g.name.equals("getGameRule")||
         !(cast instanceof TypeInsnNode t)||!t.desc.equals("java/lang/Boolean")||
         !(bool instanceof MethodInsnNode b)||!b.owner.equals("java/lang/Boolean")||!b.name.equals("booleanValue")||
         !(branch instanceof JumpInsnNode jump))throw new AssertionError("Unexpected game-rule guard");
      guards.add(jump);
    }
    if(guards.size()!=2||guards.get(0).getOpcode()!=Opcodes.IFNE||guards.get(1).getOpcode()!=Opcodes.IFEQ)throw new AssertionError("Unexpected death-clear / resend guards");
    JumpInsnNode skip=guards.get(1);
    boolean resend=false;
    for(AbstractInsnNode n=next(skip);n!=skip.label;n=n.getNext())if(n instanceof MethodInsnNode call&&call.owner.equals("net/raphimc/viabedrock/api/util/PacketFactory")&&call.name.equals("sendJavaContainerSetContent"))resend=true;
    if(!resend)throw new AssertionError("Final guard does not control inventory resend");
    InsnNode discard=new InsnNode(Opcodes.POP);m.instructions.set(skip,discard);
    ClassWriter w=new ClassWriter(new ClassReader(input),0);c.accept(w);byte[] output=w.toByteArray();
    Path p=Path.of(args[1]);Files.createDirectories(p.getParent());Files.write(p,output);
    m.instructions.set(discard,skip);
    if(!trace(c).equals(original))throw new AssertionError("Canonical reversal changed other instructions/frames/methods");
    System.out.println("PASS one final IFEQ->POP; death-clear branch and all "+c.methods.size()+" original methods retained; full canonical reversal exact");
  }
}
