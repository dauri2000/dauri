package net.raphimc.viabedrock.api.model;
public record PlayerPosture(boolean swimming, boolean crawling, boolean sneaking) {
 public static final PlayerPosture STANDING = new PlayerPosture(false, false, false);
}
