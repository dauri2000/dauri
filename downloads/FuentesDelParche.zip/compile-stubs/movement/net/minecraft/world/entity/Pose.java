package net.minecraft.world.entity;
public enum Pose { STANDING, CROUCHING, SWIMMING, FALL_FLYING }
