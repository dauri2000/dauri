package net.minecraft.client.player;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Pose;
public class LocalPlayer extends Entity {
 public boolean passenger, swimming, shift;
 public Pose pose = Pose.STANDING;
 public boolean isPassenger() { return passenger; }
 public boolean isSwimming() { return swimming; }
 public boolean isShiftKeyDown() { return shift; }
 public Pose getPose() { return pose; }
}
