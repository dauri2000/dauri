package com.viaversion.viafabricplus.bedrock.input;
public final class BedrockInputPermissions {
 public static boolean connected;
 public static boolean isBedrockConnection() { return connected; }
}
