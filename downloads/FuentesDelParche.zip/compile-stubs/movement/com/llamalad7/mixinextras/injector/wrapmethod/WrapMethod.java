package com.llamalad7.mixinextras.injector.wrapmethod;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) @Target(ElementType.METHOD)
public @interface WrapMethod { String[] method(); }
