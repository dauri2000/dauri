import java.nio.file.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

/** Version-specific, fail-closed transformation of the supplied IF54.2 artifact. */
public final class HybridPatch implements Opcodes {
  static final String ROOT="com/viaversion/viafabricplus/bedrock/";
  static final String MOV=ROOT+"injection/mixin/features/movement/";
  static final String INPUT=ROOT+"input/BedrockInputPermissions";
  static final String POLICY=ROOT+"hybrid/HybridMovementPolicy";
  static final String POSTURE="Lnet/raphimc/viabedrock/api/model/PlayerPosture;";
  static Path input, output;
  static final List<String> log=new ArrayList<>();

  static ClassNode read(String name) throws Exception {
    ClassNode c=new ClassNode();
    new ClassReader(Files.readAllBytes(input.resolve(name+".class"))).accept(c,0);
    return c;
  }
  static void save(ClassNode c) throws Exception {
    for(MethodNode m:c.methods) if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)
      new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);
    ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);
    c.accept(w);
    // Validate inserted stack instructions after maxima have been recalculated.
    ClassNode check=new ClassNode(); new ClassReader(w.toByteArray()).accept(check,0);
    for(MethodNode m:check.methods) if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)
      new Analyzer<BasicValue>(new BasicVerifier()).analyze(check.name,m);
    Path p=output.resolve(c.name+".class"); Files.createDirectories(p.getParent());
    Files.write(p,w.toByteArray());
  }
  static int gate(MethodNode m,Integer entitySlot) {
    int n=0;
    for(AbstractInsnNode i:m.instructions.toArray()) {
      if(i instanceof MethodInsnNode call && call.owner.equals(INPUT) && call.name.equals("isBedrockConnection") && call.desc.equals("()Z")) {
        if(entitySlot!=null) m.instructions.insertBefore(call,new VarInsnNode(ALOAD,entitySlot));
        call.owner=POLICY;
        call.name=entitySlot==null?"bedrockInContext":"bedrockFor";
        call.desc=entitySlot==null?"()Z":"(Ljava/lang/Object;)Z";
        n++;
      }
    }
    if(n>0) log.add(m.name+m.desc+" : "+n+" predicate(s), "+(entitySlot==null?"scoped context":"entity slot "+entitySlot));
    // Original maxStack was valid but the inserted ALOAD can add one slot.
    if(n>0) m.maxStack+=2;
    return n;
  }
  static void patchMethods(String name,Set<String> methods,Integer slot) throws Exception {
    ClassNode c=read(name); int total=0; Set<String> found=new HashSet<>();
    for(MethodNode m:c.methods) if(methods.contains(m.name)) {
      int n=gate(m,slot); if(n==0) throw new IllegalStateException("Missing expected predicate: "+name+"."+m.name);
      total+=n; found.add(m.name);
    }
    if(!found.equals(methods)) throw new IllegalStateException("Missing methods in "+name+": "+methods+" vs "+found);
    save(c); log.add("CLASS "+name+" ("+total+")");
  }
  static void patchAllExcept(String name,Set<String> excluded,Integer slot) throws Exception {
    ClassNode c=read(name); int n=0;
    for(MethodNode m:c.methods) if(!excluded.contains(m.name)) n+=gate(m,slot);
    if(n==0) throw new IllegalStateException("No predicates in "+name);
    save(c); log.add("CLASS "+name+" ("+n+")");
  }
  static void patchLocalPlayer() throws Exception {
    String name=MOV+"MixinLocalPlayer"; ClassNode c=read(name);
    Set<String> exclude=Set.of("retainNativeLocalUseStart","retainNativeLocalUseStop","rememberPreviousSwimming","sendBedrockPrediction","jumpFromGround");
    int n=0,fields=0;
    for(MethodNode m:c.methods) {
      if(!exclude.contains(m.name)) n+=gate(m,0);
      if(m.name.equals("sendBedrockPrediction")||m.name.equals("viaFabricPlusBedrock$posture")) {
        for(AbstractInsnNode i:m.instructions.toArray()) if(i instanceof FieldInsnNode f && f.getOpcode()==GETFIELD && f.owner.equals(name) && f.name.equals("viaFabricPlusBedrock$posture")) {
          m.instructions.insertBefore(f,new InsnNode(DUP));
          m.instructions.insert(f,new MethodInsnNode(INVOKESTATIC,POLICY,"selectPosture","(Ljava/lang/Object;"+POSTURE+")"+POSTURE,false));
          m.maxStack+=2; fields++;
        }
      }
    }
    if(n!=9||fields!=2) throw new IllegalStateException("Unexpected local player layout: predicates="+n+", posture="+fields);
    save(c); log.add("CLASS "+name+"; two posture reads now report Java state when unmounted");
  }
  static void patchEntity() throws Exception {
    ClassNode c=read(MOV+"MixinEntity"); int n=0,equals=0;
    for(MethodNode m:c.methods) {
      if(!m.name.equals("retainFloatingBoatSupport")) n+=gate(m,0);
      if(m.name.equals("prioritySlowestMovementMultiplier")) for(AbstractInsnNode i:m.instructions.toArray())
        if(i instanceof MethodInsnNode call&&call.name.equals("equals")&&call.desc.equals("(Ljava/lang/Object;)Z")) {
          InsnList guard=new InsnList(); guard.add(new VarInsnNode(ALOAD,0));
          guard.add(new MethodInsnNode(INVOKESTATIC,POLICY,"bedrockFor","(Ljava/lang/Object;)Z",false));
          guard.add(new InsnNode(IAND)); m.instructions.insert(call,guard); m.maxStack+=2; equals++;
        }
    }
    if(n!=2||equals!=1) throw new IllegalStateException("Unexpected Entity gates "+n+"/"+equals);
    save(c); log.add("CLASS "+c.name+"; boat world support unchanged");
  }
  static void patchHoney() throws Exception {
    ClassNode c=read(MOV+"MixinHoneyBlock"); int total=0;
    Map<String,Integer> methods=new HashMap<>();
    methods.put("applyBedrockHoneyCollision",4); methods.put("stepOn",4);
    methods.put("getFriction",null); methods.put("getSpeedFactor",null); methods.put("getJumpFactor",null);
    for(MethodNode m:c.methods) if(methods.containsKey(m.name)) {
      int count=0;
      for(AbstractInsnNode i:m.instructions.toArray()) if(i instanceof MethodInsnNode call&&call.name.equals("equals")&&call.desc.equals("(Ljava/lang/Object;)Z")) {
        InsnList guard=new InsnList(); Integer slot=methods.get(m.name);
        if(slot!=null) guard.add(new VarInsnNode(ALOAD,slot));
        guard.add(new MethodInsnNode(INVOKESTATIC,POLICY,slot==null?"bedrockInContext":"bedrockFor",slot==null?"()Z":"(Ljava/lang/Object;)Z",false));
        guard.add(new InsnNode(IAND)); m.instructions.insert(call,guard); m.maxStack+=2; count++;
      }
      if(count!=1) throw new IllegalStateException("Unexpected honey "+m.name+": "+count); total+=count;
    }
    if(total!=5) throw new IllegalStateException("Honey methods missing");
    save(c); log.add("CLASS "+c.name+"; 5 locomotion guards, Bedrock world shape retained");
  }
  static void patchSulfur() throws Exception {
    ClassNode c=read(MOV+"MixinPotentSulfurBlockEntity"); int n=0;
    for(MethodNode m:c.methods) if(m.name.startsWith("lambda$")) {
      Type[] args=Type.getArgumentTypes(m.desc); int slot=(m.access&ACC_STATIC)!=0?0:1; Integer entity=null;
      for(Type t:args) {if(t.getDescriptor().equals("Lnet/minecraft/world/entity/Entity;")) entity=slot; slot+=t.getSize();}
      if(entity!=null) n+=gate(m,entity);
    }
    if(n!=1) throw new IllegalStateException("Unexpected sulfur "+n);
    save(c); log.add("CLASS "+c.name+"; Java local entity included in vanilla geyser processing");
  }
  static void patchSneak() throws Exception {
    ClassNode c=read(ROOT+"injection/mixin/features/input/MixinLocalPlayerInput"); int n=0;
    for(MethodNode m:c.methods) for(AbstractInsnNode i:m.instructions.toArray())
      if(i instanceof MethodInsnNode call&&call.owner.equals(INPUT)&&call.name.equals("active")&&call.desc.equals("()Z")) {
        m.instructions.insertBefore(call,new VarInsnNode(ALOAD,1));
        call.owner=POLICY;call.name="bedrockFor";call.desc="(Ljava/lang/Object;)Z";m.maxStack++;n++;
      }
    if(n!=1) throw new IllegalStateException("Unexpected sneak "+n);save(c);log.add("CLASS "+c.name+"; Java sneak handling, permission filter retained");
  }
  static void patchInventory() throws Exception {
    ClassNode c=read("net/raphimc/viabedrock/protocol/packet/InventoryPackets"); int n=0;
    for(MethodNode m:c.methods) if(m.name.equals("sendNativeContainerPresentation")) {
      if(!m.desc.equals("(Lcom/viaversion/viaversion/api/protocol/packet/PacketWrapper;Lnet/raphimc/viabedrock/api/resourcepack/ui/ContainerUi$Kind;Lnet/raphimc/viabedrock/api/resourcepack/ui/ContainerUi$Title;)V") || (m.access&ACC_STATIC)==0) throw new IllegalStateException(m.desc);
      m.instructions.clear();m.instructions.add(new InsnNode(RETURN));m.tryCatchBlocks.clear();
      if(m.localVariables!=null)m.localVariables.clear();
      m.visibleLocalVariableAnnotations=null;m.invisibleLocalVariableAnnotations=null;
      m.maxStack=0;n++;
    }
    if(n!=1) throw new IllegalStateException("Inventory method missing");
    save(c);log.add("CLASS "+c.name+"; native presentation disabled; all transaction methods preserved");
  }
  public static void main(String[] args) throws Exception {
    input=Path.of(args[0]);output=Path.of(args[1]);
    if(args.length>2&&args[2].equals("inventory")) patchInventory();
    else {
      patchLocalPlayer();patchEntity();
      patchAllExcept(MOV+"MixinLivingEntity",Set.of("boundNativeItemUseDuration","useNativeSwimmingBlendStep"),0);
      patchAllExcept(MOV+"MixinPlayer",Set.of(),0);
      patchMethods(MOV+"MixinAvatar",Set.of("useNativeCrouchingHeight"),0);
      patchMethods(MOV+"MixinGlideLandingPrediction",Set.of("stopLandedGlideBeforeNextTravel"),0);
      patchMethods(MOV+"MixinGlideRocketPrediction",Set.of("predictAcceptedRocket"),1);
      patchMethods(MOV+"MixinFireworkRocketEntity",Set.of("deferLocalRocketImpulseToGlideTravel"),1);
      patchAllExcept(MOV+"MixinEntityFluidInteraction",Set.of(),null);
      patchMethods(MOV+"MixinEntityFluidInteraction_CurrentAccumulator",Set.of("accumulateBedrockCurrent"),null);
      // applyTo has an explicit entity parameter; patch into the same output class.
      Path savedInput=input; input=output;
      patchMethods(MOV+"MixinEntityFluidInteraction_CurrentAccumulator",Set.of("applyBedrockCurrent"),1);
      input=savedInput;
      patchMethods(MOV+"MixinVoxelShape",Set.of("nativeContactClipping"),null);
      patchMethods(ROOT+"movement/BedrockFlightPhysics",Set.of("applies"),0);
      patchMethods(ROOT+"movement/BedrockClimbingPhysics",Set.of("applies"),0);
      patchHoney();patchSulfur();patchSneak();
    }
    Files.createDirectories(output);Files.writeString(output.resolve("patch-log.txt"),String.join("\n",log)+"\n");
    log.forEach(System.out::println);
  }
}
