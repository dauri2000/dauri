import java.nio.file.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import org.objectweb.asm.util.*;

/** Independent structural and method-boundary checks; does not emulate Minecraft. */
public class AuditHybrid {
 static String text(MethodNode m) { Textifier t=new Textifier();m.accept(new TraceMethodVisitor(t));return t.getText().toString(); }
 static ClassNode parse(byte[] b) { ClassNode c=new ClassNode();new ClassReader(b).accept(c,0);return c; }
 static Map<String,MethodNode> methods(ClassNode c) {Map<String,MethodNode> m=new TreeMap<>();for(MethodNode n:c.methods)m.put(n.name+n.desc,n);return m;}
 static void require(boolean ok,String why) {if(!ok)throw new AssertionError(why);}
 static Set<String> names(String s) {return new TreeSet<>(Arrays.asList(s.split(",")));}
 public static void main(String[] a)throws Exception {
  Map<String,Set<String>> allowed=new TreeMap<>();
  allowed.put("MixinLocalPlayer",names("respectNativeBlockEscapeFlag,updateSwimming,usePreviousNativePostureForInput,useNativeSneakingScale,applyItemUseAfterNativePosture,retainNativeNormalizedInput,retainSprintUntilSwimmingStops,updateSwimmingBeforeTravel,allowNonSwimWaterSprinting,sendBedrockPrediction,viaFabricPlusBedrock$posture"));
  allowed.put("MixinEntity",names("prioritySlowestMovementMultiplier,skipPassengerChanges,inflateFluidInteractionBox"));
  allowed.put("MixinLivingEntity",names("applyNativeGeyserTravel,applyNativeWaterAcceleration,applyNativeWaterDamping,applyNativeGlideTravel,changeFluidGravityCondition,applyLevitationVelocity"));
  allowed.put("MixinPlayer",names("retainNativeCrawlingPose,useNativeEdgeContacts,useNativePostureSpace,modifyWaterAbovePosition,preventSwimmingMotionWhenJumping,suppressLiquidJumpDuringSwimmingTransition,preventSwimmingResurface"));
  allowed.put("MixinAvatar",names("useNativeCrouchingHeight"));
  allowed.put("MixinGlideLandingPrediction",names("stopLandedGlideBeforeNextTravel"));
  allowed.put("MixinGlideRocketPrediction",names("predictAcceptedRocket"));
  allowed.put("MixinFireworkRocketEntity",names("deferLocalRocketImpulseToGlideTravel"));
  allowed.put("MixinEntityFluidInteraction",names("bedrockCurrentStrength,removeConditional,adjustHeightCalculation,dontScaleCurrent"));
  allowed.put("MixinEntityFluidInteraction_CurrentAccumulator",names("accumulateBedrockCurrent,applyBedrockCurrent"));
  allowed.put("MixinVoxelShape",names("nativeContactClipping"));
  allowed.put("BedrockFlightPhysics",names("applies"));allowed.put("BedrockClimbingPhysics",names("applies"));
  allowed.put("MixinHoneyBlock",names("applyBedrockHoneyCollision,stepOn,getFriction,getSpeedFactor,getJumpFactor"));
  allowed.put("MixinPotentSulfurBlockEntity",names("lambda$excludeNativeLocalTravel$0"));
  allowed.put("MixinLocalPlayerInput",names("predictSneakPress"));
  Path original=Path.of(a[0]),patched=Path.of(a[1]);int classes=0,changed=0,preserved=0;
  try(var paths=Files.walk(patched)) {
   for(Path p:paths.filter(f->f.toString().endsWith(".class")).sorted().toList()) {
    String rel=patched.relativize(p).toString();ClassNode before=parse(Files.readAllBytes(original.resolve(rel))),after=parse(Files.readAllBytes(p));
    require(before.name.equals(after.name)&&before.superName.equals(after.superName)&&before.interfaces.equals(after.interfaces),"Hierarchy changed: "+rel);
    require(before.fields.size()==after.fields.size(),"Fields changed: "+rel);
    for(int i=0;i<before.fields.size();i++) {FieldNode b=before.fields.get(i),c=after.fields.get(i);require(b.name.equals(c.name)&&b.desc.equals(c.desc)&&b.access==c.access&&Objects.equals(b.value,c.value),"Field changed: "+rel);}
    var bm=methods(before);var am=methods(after);require(bm.keySet().equals(am.keySet()),"Method set changed: "+rel);
    Set<String> diff=new TreeSet<>();
    for(String k:bm.keySet()) {if(!text(bm.get(k)).equals(text(am.get(k)))) {diff.add(bm.get(k).name);changed++;}else preserved++;}
    String simple=p.getFileName().toString().replace(".class","");require(diff.equals(allowed.get(simple)),"Unexpected method differences "+simple+": "+diff);
    new ClassReader(Files.readAllBytes(p)).accept(new CheckClassAdapter(new ClassWriter(0),true),0);
    for(MethodNode m:after.methods)if((m.access&(Opcodes.ACC_ABSTRACT|Opcodes.ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(after.name,m);
    System.out.println("PASS "+simple+": "+diff.size()+" intended method changes");classes++;
   }
  }
  require(classes==16,"Unexpected class count");
  Path additions=Path.of(a[2]);int added=0;
  try(var paths=Files.walk(additions)) {for(Path p:paths.filter(f->f.toString().endsWith(".class")).toList()) {new ClassReader(Files.readAllBytes(p)).accept(new CheckClassAdapter(new ClassWriter(0),true),0);added++;}}
  require(added==3,"Unexpected runtime additions");
  System.out.println("PASS: "+classes+" modified outer classes, "+changed+" intended method changes, "+preserved+" unchanged methods, "+added+" new runtime classes; ASM structural and basic dataflow checks passed.");
 }
}
