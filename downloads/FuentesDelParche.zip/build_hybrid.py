#!/usr/bin/env python3
"""Build the version-specific experimental IF54 Java movement/inventory profile.

No networking. Requires JDK >=25 and ASM 9.9 jars obtained from Maven Central.
The original artifact is never changed. Compile stubs are never shipped in the mod.
"""
import argparse
import copy
import hashlib
import io
import json
import pathlib
import shutil
import subprocess
import tempfile
import zipfile

BASE_SHA = 'ea29d43b1f76717c7dd6c03587433f41194a139e3d0eee8552fe91f9ee9980d3'
VERSION = '1.1.1-StackAnvil-InteractionFix54.2-JavaMovementInventory.1'
NESTED = 'META-INF/jars/ViaBedrock-0.0.31-StackAnvil.jar'
PROTOCOL_CLASS = 'net/raphimc/viabedrock/protocol/packet/InventoryPackets.class'
ROOT = 'com/viaversion/viafabricplus/bedrock/'
MOVEMENT = ROOT + 'injection/mixin/features/movement/'
MOVEMENT_CLASSES = [
    'MixinLocalPlayer', 'MixinEntity', 'MixinLivingEntity', 'MixinPlayer',
    'MixinAvatar', 'MixinGlideLandingPrediction', 'MixinGlideRocketPrediction',
    'MixinFireworkRocketEntity', 'MixinEntityFluidInteraction',
    'MixinEntityFluidInteraction_CurrentAccumulator', 'MixinVoxelShape',
    'MixinHoneyBlock', 'MixinPotentSulfurBlockEntity',
]
OUTER_CLASSES = [MOVEMENT + s + '.class' for s in MOVEMENT_CLASSES] + [
    ROOT + 'movement/BedrockFlightPhysics.class',
    ROOT + 'movement/BedrockClimbingPhysics.class',
    ROOT + 'injection/mixin/features/input/MixinLocalPlayerInput.class',
]
NEW_CLASSES = [
    ROOT + 'hybrid/HybridMovementPolicy.class',
    MOVEMENT + 'MixinJavaEntityMovementContext.class',
    MOVEMENT + 'MixinJavaPlayerMovementContext.class',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def run(command, records, label):
    result = subprocess.run([str(x) for x in command], check=True,
                            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    records[label] = result.stdout.strip()
    print(result.stdout, end='', flush=True)


def zip_rewrite(original, changes):
    result = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(original)) as src, zipfile.ZipFile(result, 'w') as dst:
        names = src.namelist()
        assert len(names) == len(set(names)), 'Duplicate archive entries'
        assert not any(n.upper().endswith(('.RSA', '.SF', '.DSA', '.EC')) for n in names), 'Signed artifact requires a separate signing workflow'
        for info in src.infolist():
            data = src.read(info.filename)  # Verifies the original entry CRC too.
            dst.writestr(copy.copy(info), changes.get(info.filename, data))
        for name in sorted(set(changes) - set(names)):
            info = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            dst.writestr(info, changes[name])
    return result.getvalue()


def source_bundle(source_root):
    result = io.BytesIO()
    patterns = ['hybrid-src/**/*.java', 'compile-stubs/movement/**/*.java',
                'patch-src/*.java', 'review-inventory-tools/*.java',
                'MovementPolicyCheck.java', 'build_hybrid.py', 'README_ES.md',
                'LICENSE_viafabricplus-bedrock']
    files = sorted({p for pattern in patterns for p in source_root.glob(pattern) if p.is_file()})
    with zipfile.ZipFile(result, 'w', zipfile.ZIP_DEFLATED) as z:
        for path in files:
            info = zipfile.ZipInfo(path.relative_to(source_root).as_posix(), date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, path.read_bytes())
    return result.getvalue()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('original', type=pathlib.Path)
    p.add_argument('--jdk', required=True, type=pathlib.Path)
    p.add_argument('--asm-dir', required=True, type=pathlib.Path)
    p.add_argument('--output', required=True, type=pathlib.Path)
    args = p.parse_args()
    source = pathlib.Path(__file__).resolve().parent
    original = args.original.read_bytes()
    if sha(original) != BASE_SHA:
        p.error('This patch only accepts the exact supplied IF54.2 JAR (SHA-256 mismatch).')
    assert args.original.resolve() != args.output.resolve(), 'Preserve original'
    args.output.parent.mkdir(parents=True, exist_ok=True)
    java, javac = args.jdk / 'bin/java', args.jdk / 'bin/javac'
    asm = [args.asm_dir / f'{s}.jar' for s in ['asm', 'asm-tree', 'asm-analysis', 'asm-util']]
    for file in [java, javac, *asm]:
        if not file.is_file():
            p.error(f'Missing prerequisite: {file}')
    cp = ':'.join(str(f.resolve()) for f in asm)
    records = {}
    with tempfile.TemporaryDirectory(prefix='if54-hybrid-') as temp:
        work = pathlib.Path(temp)
        outer = work / 'original-outer'
        protocol = work / 'original-protocol'
        modified = work / 'modified-outer'
        modified_protocol = work / 'modified-protocol'
        tools = work / 'tools'
        compiled = work / 'test-compiled'
        additions = work / 'runtime-additions'
        with zipfile.ZipFile(io.BytesIO(original)) as z:
            for name in OUTER_CLASSES:
                path = outer / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(z.read(name))
            nested = z.read(NESTED)
            meta = json.loads(z.read('fabric.mod.json'))
            mixins = json.loads(z.read('viafabricplus-bedrock.mixins.json'))
        nested_path = work / 'original-viabedrock.jar'
        nested_path.write_bytes(nested)
        with zipfile.ZipFile(io.BytesIO(nested)) as z:
            path = protocol / PROTOCOL_CLASS
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(z.read(PROTOCOL_CLASS))
        stub_sources = sorted((source / 'compile-stubs/movement').rglob('*.java'))
        runtime_sources = sorted((source / 'hybrid-src').rglob('*.java'))
        run([javac, '--release', '21', '-proc:none', '-d', compiled,
             *stub_sources, *runtime_sources, source / 'MovementPolicyCheck.java'], records, 'compile_policy')
        for name in NEW_CLASSES:
            path = additions / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes((compiled / name).read_bytes())
        run([javac, '--release', '21', '-proc:none', '-cp', cp, '-d', tools,
             *sorted((source / 'patch-src').glob('*.java')),
             source / 'review-inventory-tools/ReviewInventory.java'], records, 'compile_tools')
        tool_cp = f'{tools}:{cp}'
        run([java, '-Xverify:all', '-cp', tool_cp, 'HybridPatch', outer, modified], records, 'movement_patch')
        run([java, '-Xverify:all', '-cp', tool_cp, 'HybridPatch', protocol, modified_protocol, 'inventory'], records, 'inventory_patch')
        run([java, '-Xverify:all', '-cp', tool_cp, 'AuditHybrid', outer, modified, additions], records, 'movement_bytecode_audit')
        run([java, '-Xverify:all', '-cp', tool_cp, 'ReviewInventory', protocol / PROTOCOL_CLASS,
             modified_protocol / PROTOCOL_CLASS], records, 'inventory_method_audit')
        # Actual PlayerPosture comes from the original ViaBedrock JAR. Game classes,
        # Fabric and Mixin interfaces are test doubles, never an in-game assertion.
        run([java, '-Xverify:all', '-ea', '-cp', f'{nested_path}:{compiled}',
             'MovementPolicyCheck'], records, 'isolated_movement_policy_tests')
        replacement_core = (modified_protocol / PROTOCOL_CLASS).read_bytes()
        modified_nested = zip_rewrite(nested, {PROTOCOL_CLASS: replacement_core})
        replacements = {name: (modified / name).read_bytes() for name in OUTER_CLASSES}
        replacements.update({name: (additions / name).read_bytes() for name in NEW_CLASSES})
        replacements[NESTED] = modified_nested
        meta['version'] = VERSION
        meta['name'] = 'ViaFabricPlus Bedrock - IF54 Java Movement & Inventory (Experimental)'
        meta['description'] += ' Experimental profile: Java local unmounted movement and inventory controls; original Bedrock translation and other features retained. Not tested in-game.'
        meta.setdefault('custom', {})['java_movement_inventory'] = {
            'base_sha256': BASE_SHA, 'in_game_tested': False,
            'scope': 'local-unmounted-player-and-inventory-controls',
        }
        replacements['fabric.mod.json'] = (json.dumps(meta, indent=2) + '\n').encode()
        for name in ['features.movement.MixinJavaEntityMovementContext',
                     'features.movement.MixinJavaPlayerMovementContext']:
            assert name not in mixins['client']
            mixins['client'].append(name)
        replacements['viafabricplus-bedrock.mixins.json'] = (json.dumps(mixins, indent=2) + '\n').encode()
        sources = source_bundle(source)
        replacements['META-INF/java-movement-inventory-sources.zip'] = sources
        profile = {
            'version': VERSION, 'base_sha256': BASE_SHA, 'in_game_tested': False,
            'tests_are_isolated_not_gameplay': True,
            'modified_outer_classes': OUTER_CLASSES,
            'added_runtime_classes': NEW_CLASSES,
            'modified_core_class': PROTOCOL_CLASS,
            'core_methods_changed': ['sendNativeContainerPresentation'],
            'preserved_core_methods': 58,
            'movement_policy_assertions_passed': 31,
            'original_bedrock_server_authority_preserved': True,
            'sources_sha256': sha(sources),
            'limitations': [
                'No Minecraft/Fabric launch or live Bedrock server session was available.',
                'Actual Mixin target application, gameplay, mounts and portal transitions require in-game testing.',
                'Bedrock server rules and inventory results remain authoritative.',
                'Unscoped shared collision/fluid queries default to Bedrock.',
                'The base JAR includes an earlier unresolved portal/inventory experimental receipt.',
                'Other Bedrock features are retained from the supplied base, not a complete reimplementation of Bedrock.',
            ],
        }
        replacements['META-INF/java-movement-inventory-profile.json'] = (json.dumps(profile, indent=2) + '\n').encode()
        artifact = zip_rewrite(original, replacements)
        # Check all changed bytes and all preserved bytes, including nested libraries.
        with zipfile.ZipFile(io.BytesIO(original)) as before, zipfile.ZipFile(io.BytesIO(artifact)) as after:
            assert after.testzip() is None
            assert len(after.namelist()) == len(set(after.namelist()))
            changed = sorted(n for n in before.namelist() if before.read(n) != after.read(n))
            assert set(changed) == set(replacements) & set(before.namelist())
            for n in after.namelist():
                if n.endswith('.jar'):
                    with zipfile.ZipFile(io.BytesIO(after.read(n))) as library:
                        assert library.testzip() is None, n
            declared = json.loads(after.read('fabric.mod.json'))
            for entry in declared['jars']:
                assert entry['file'] in after.namelist()
            config = json.loads(after.read('viafabricplus-bedrock.mixins.json'))
            package = config['package'].replace('.', '/')
            for name in config['client']:
                assert package + '/' + name.replace('.', '/') + '.class' in after.namelist(), name
            assert not any(n.startswith(('org/spongepowered/', 'net/minecraft/client/player/LocalPlayer',
                                         'net/minecraft/world/entity/Entity.class', 'com/llamalad7/')) for n in after.namelist()), 'Compile stubs leaked into artifact'
        with zipfile.ZipFile(io.BytesIO(nested)) as before, zipfile.ZipFile(io.BytesIO(modified_nested)) as after:
            core_changed = [n for n in before.namelist() if before.read(n) != after.read(n)]
            assert core_changed == [PROTOCOL_CLASS]
            assert set(before.namelist()) == set(after.namelist())
        args.output.write_bytes(artifact)
        args.output.with_suffix('.sources.zip').write_bytes(sources)
        report = {**profile, 'output_sha256': sha(artifact), 'output_bytes': len(artifact),
                  'outer_entries_changed': changed, 'nested_entries_changed': core_changed,
                  'all_jar_crc_checks_passed': True, 'all_mixin_classes_present': True,
                  'test_output': records}
        args.output.with_suffix('.review.json').write_text(json.dumps(report, indent=2) + '\n')
        args.output.with_suffix('.jar.sha256').write_text(sha(artifact) + '  ' + args.output.name + '\n')
        args.output.with_suffix('.README_ES.md').write_bytes((source / 'README_ES.md').read_bytes())
        print(f'BUILT {args.output.name}: {len(artifact)} bytes, SHA-256 {sha(artifact)}')


if __name__ == '__main__':
    main()
