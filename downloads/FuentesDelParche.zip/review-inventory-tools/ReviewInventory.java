import java.nio.file.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.*;
public class ReviewInventory {
 static ClassNode read(String path) throws Exception { ClassNode c=new ClassNode(); new ClassReader(Files.readAllBytes(Path.of(path))).accept(c,0);return c; }
 static String dump(MethodNode m) { Textifier p=new Textifier();m.accept(new TraceMethodVisitor(p));return p.getText().toString(); }
 public static void main(String[] a) throws Exception {
  ClassNode before=read(a[0]), after=read(a[1]);Map<String,MethodNode> bm=new LinkedHashMap<>(),am=new LinkedHashMap<>();
  for(MethodNode m:before.methods)bm.put(m.name+m.desc,m);for(MethodNode m:after.methods)am.put(m.name+m.desc,m);
  if(!bm.keySet().equals(am.keySet()))throw new AssertionError("method set differs");
  int changed=0;for(String id:bm.keySet())if(!dump(bm.get(id)).equals(dump(am.get(id)))){System.out.println("DIFF "+id);changed++;if(!id.startsWith("sendNativeContainerPresentation(")) throw new AssertionError("unintended method changed: "+id);}
  if(changed!=1)throw new AssertionError("expected exactly one method difference");
  MethodNode target=am.values().stream().filter(m->m.name.equals("sendNativeContainerPresentation")).findFirst().orElseThrow();
  if(target.instructions.size()!=1||target.instructions.getFirst().getOpcode()!=Opcodes.RETURN||!target.tryCatchBlocks.isEmpty())throw new AssertionError("unexpected target body");
  System.out.println("PASS: "+bm.size()+" methods; exactly native presentation body changed; all remaining methods identical ASM text including metadata");
 }
}
