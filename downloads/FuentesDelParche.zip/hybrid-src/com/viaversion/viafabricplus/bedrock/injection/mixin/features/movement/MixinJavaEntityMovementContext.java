package com.viaversion.viafabricplus.bedrock.injection.mixin.features.movement;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.viaversion.viafabricplus.bedrock.hybrid.HybridMovementPolicy;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Entity.class)
public abstract class MixinJavaEntityMovementContext {
    @WrapMethod(method = "move")
    private void viaFabricPlusBedrock$javaEntityMoveContext(
            MoverType moverType, Vec3 movement, Operation<Void> original) {
        Object previous = HybridMovementPolicy.enter(this);
        try {
            original.call(moverType, movement);
        } finally {
            HybridMovementPolicy.exit(previous);
        }
    }

    @WrapMethod(method = "baseTick")
    private void viaFabricPlusBedrock$javaEntityBaseTickContext(Operation<Void> original) {
        Object previous = HybridMovementPolicy.enter(this);
        try {
            original.call();
        } finally {
            HybridMovementPolicy.exit(previous);
        }
    }
}
