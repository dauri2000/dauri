package com.viaversion.viafabricplus.bedrock.injection.mixin.features.movement;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.viaversion.viafabricplus.bedrock.hybrid.HybridMovementPolicy;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(LocalPlayer.class)
public abstract class MixinJavaPlayerMovementContext {
    @WrapMethod(method = "tick")
    private void viaFabricPlusBedrock$javaPlayerTickContext(Operation<Void> original) {
        Object previous = HybridMovementPolicy.enter(this);
        try {
            original.call();
        } finally {
            HybridMovementPolicy.exit(previous);
        }
    }
}
