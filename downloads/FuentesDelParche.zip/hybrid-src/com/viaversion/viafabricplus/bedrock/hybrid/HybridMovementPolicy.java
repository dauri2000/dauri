package com.viaversion.viafabricplus.bedrock.hybrid;

import com.viaversion.viafabricplus.bedrock.input.BedrockInputPermissions;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Pose;
import net.raphimc.viabedrock.api.model.PlayerPosture;

/** Separates local, unmounted Java locomotion from Bedrock entity simulation. */
public final class HybridMovementPolicy {
    private static final ThreadLocal<Object> CONTEXT = new ThreadLocal<>();

    private HybridMovementPolicy() {
    }

    public static boolean bedrockFor(Object entity) {
        return BedrockInputPermissions.isBedrockConnection()
                && (!(entity instanceof LocalPlayer player) || player.isPassenger());
    }

    public static boolean bedrockInContext() {
        return bedrockFor(CONTEXT.get());
    }

    /** Returns the previous scope, which must be restored in a finally block. */
    public static Object enter(Object entity) {
        Object previous = CONTEXT.get();
        CONTEXT.set(entity);
        return previous;
    }

    public static void exit(Object previous) {
        if (previous == null) {
            CONTEXT.remove();
        } else {
            CONTEXT.set(previous);
        }
    }

    /** Describes Java's chosen posture without changing the local player. */
    public static PlayerPosture javaPosture(Object entity) {
        if (!(entity instanceof LocalPlayer player)) {
            return PlayerPosture.STANDING;
        }
        boolean swimming = player.isSwimming();
        boolean crawling = !swimming && player.getPose() == Pose.SWIMMING;
        return new PlayerPosture(swimming, crawling, player.isShiftKeyDown());
    }

    public static PlayerPosture selectPosture(Object entity, PlayerPosture nativePosture) {
        return bedrockFor(entity) || !(entity instanceof LocalPlayer)
                ? nativePosture : javaPosture(entity);
    }
}
