import com.viaversion.viafabricplus.bedrock.hybrid.HybridMovementPolicy;
import com.viaversion.viafabricplus.bedrock.input.BedrockInputPermissions;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Pose;
import net.raphimc.viabedrock.api.model.PlayerPosture;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicReference;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.viaversion.viafabricplus.bedrock.injection.mixin.features.movement.MixinJavaPlayerMovementContext;
import com.viaversion.viafabricplus.bedrock.injection.mixin.features.movement.MixinJavaEntityMovementContext;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.phys.Vec3;

public final class MovementPolicyCheck {
    private static int assertions;

    private static void check(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }

    public static void main(String[] args) throws Exception {
        LocalPlayer player = new LocalPlayer();
        Entity boat = new Entity();
        BedrockInputPermissions.connected = false;
        check(!HybridMovementPolicy.bedrockFor(boat), "Java connection retains Java entity behavior");
        check(!HybridMovementPolicy.bedrockFor(player), "Java connection retains Java player behavior");
        BedrockInputPermissions.connected = true;
        check(HybridMovementPolicy.bedrockFor(boat), "Bedrock entities retain Bedrock behavior");
        check(!HybridMovementPolicy.bedrockFor(player), "Unmounted local player uses Java");
        player.passenger = true;
        check(HybridMovementPolicy.bedrockFor(player), "Mounted local player retains Bedrock");
        player.passenger = false;
        check(HybridMovementPolicy.bedrockInContext(), "No scope preserves shared Bedrock behavior");

        Object outer = HybridMovementPolicy.enter(player);
        try {
            check(outer == null, "Outermost scope has no predecessor");
            check(!HybridMovementPolicy.bedrockInContext(), "Player scope uses Java");
            Object nested = HybridMovementPolicy.enter(boat);
            try {
                check(nested == player, "Nested entity remembers player scope");
                check(HybridMovementPolicy.bedrockInContext(), "Nested entity keeps Bedrock");
            } finally {
                HybridMovementPolicy.exit(nested);
            }
            check(!HybridMovementPolicy.bedrockInContext(), "Nested entity restores Java player scope");
            AtomicReference<Throwable> failure = new AtomicReference<>();
            Thread worker = new Thread(() -> {
                try {
                    if (!HybridMovementPolicy.bedrockInContext()) {
                        throw new AssertionError("Movement context leaked to another thread");
                    }
                } catch (Throwable error) {
                    failure.set(error);
                }
            });
            worker.start();
            worker.join();
            check(failure.get() == null, "Movement contexts are isolated by thread");
            try {
                Object inner = HybridMovementPolicy.enter(boat);
                try {
                    throw new IllegalStateException("expected");
                } finally {
                    HybridMovementPolicy.exit(inner);
                }
            } catch (IllegalStateException expected) {
                check(!HybridMovementPolicy.bedrockInContext(), "Exception restores outer player context");
            }
        } finally {
            HybridMovementPolicy.exit(outer);
        }
        check(HybridMovementPolicy.bedrockInContext(), "Completed player scope restores shared Bedrock");
        Field field = HybridMovementPolicy.class.getDeclaredField("CONTEXT");
        field.setAccessible(true);
        check(((ThreadLocal<?>) field.get(null)).get() == null, "Completed outer scope releases entity reference");

        PlayerPosture nativePosture = new PlayerPosture(false, true, true);
        check(HybridMovementPolicy.javaPosture(player).equals(PlayerPosture.STANDING), "Java standing posture");
        player.pose = Pose.SWIMMING;
        check(HybridMovementPolicy.javaPosture(player).equals(new PlayerPosture(false, true, false)), "Java crawling posture");
        player.swimming = true;
        check(HybridMovementPolicy.javaPosture(player).equals(new PlayerPosture(true, false, false)), "Java swimming excludes crawling");
        player.shift = true;
        check(HybridMovementPolicy.javaPosture(player).sneaking(), "Java sneak flag preserved");
        check(HybridMovementPolicy.selectPosture(player, nativePosture).equals(HybridMovementPolicy.javaPosture(player)), "Unmounted protocol posture follows Java state");
        player.passenger = true;
        check(HybridMovementPolicy.selectPosture(player, nativePosture) == nativePosture, "Mounted protocol posture remains native");
        check(HybridMovementPolicy.selectPosture(boat, nativePosture) == nativePosture, "Nonplayer protocol posture remains native");
        player.passenger = false;
        Object playerScope = HybridMovementPolicy.enter(player);
        try {
            Object playerMixin = new MixinJavaPlayerMovementContext() { };
            Method tick = MixinJavaPlayerMovementContext.class.getDeclaredMethod(
                    "viaFabricPlusBedrock$javaPlayerTickContext", Operation.class);
            tick.setAccessible(true);
            tick.invoke(playerMixin, (Operation<Void>) forwarded -> {
                check(forwarded.length == 0, "Player tick forwards zero arguments");
                check(HybridMovementPolicy.bedrockInContext(), "Player wrapper temporarily installs receiver scope");
                return null;
            });
            check(!HybridMovementPolicy.bedrockInContext(), "Player tick wrapper restores outer scope");

            Object entityMixin = new MixinJavaEntityMovementContext() { };
            Vec3 movement = new Vec3();
            Method move = MixinJavaEntityMovementContext.class.getDeclaredMethod(
                    "viaFabricPlusBedrock$javaEntityMoveContext", MoverType.class, Vec3.class, Operation.class);
            move.setAccessible(true);
            move.invoke(entityMixin, MoverType.SELF, movement, (Operation<Void>) forwarded -> {
                check(forwarded.length == 2 && forwarded[0] == MoverType.SELF && forwarded[1] == movement,
                        "Entity move forwards original mover type and movement");
                return null;
            });
            check(!HybridMovementPolicy.bedrockInContext(), "Entity move wrapper restores outer scope");

            Method baseTick = MixinJavaEntityMovementContext.class.getDeclaredMethod(
                    "viaFabricPlusBedrock$javaEntityBaseTickContext", Operation.class);
            baseTick.setAccessible(true);
            try {
                baseTick.invoke(entityMixin, (Operation<Void>) forwarded -> {
                    check(forwarded.length == 0, "Entity baseTick forwards zero arguments");
                    throw new IllegalStateException("expected wrapper failure");
                });
                throw new AssertionError("Wrapper swallowed original exception");
            } catch (InvocationTargetException expected) {
                check(expected.getCause() instanceof IllegalStateException, "Wrapper preserves original exception");
                check(!HybridMovementPolicy.bedrockInContext(), "Entity baseTick exception restores outer scope");
            }
        } finally {
            HybridMovementPolicy.exit(playerScope);
        }
        BedrockInputPermissions.connected = false;
        check(!HybridMovementPolicy.bedrockInContext(), "Switching to Java connection clears Bedrock behavior");
        System.out.println("PASS: " + assertions + " movement-policy assertions (compile stubs; no Minecraft runtime).");
    }
}
