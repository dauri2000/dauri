import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.io.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import org.objectweb.asm.util.TraceClassVisitor;

/** Own narrow emitter: five instructions plus one private method in an existing class. */
public final class PatchNativeConnectionAuthority implements Opcodes {
  static final String TARGET="net/raphimc/viabedrock/protocol/storage/ChunkTracker";
  static final String POS="Lcom/viaversion/viaversion/api/minecraft/BlockPosition;";
  static final String MODEL="Lnet/raphimc/viabedrock/api/model/BlockState;";
  static final String METHOD_DESC="("+POS+")I";
  static final String GUARD="hasNativeProtocol2225Connections";
  static final String GUARD_DESC="("+POS+MODEL+")Z";
  static String sha(byte[] bytes)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));}
  static void check(boolean condition,String why){if(!condition)throw new AssertionError(why);}
  static ClassNode read(byte[] bytes){ClassNode node=new ClassNode();new ClassReader(bytes).accept(node,0);return node;}
  static String canonical(ClassNode node){StringWriter text=new StringWriter();node.accept(new TraceClassVisitor(new PrintWriter(text)));return text.toString();}
  static MethodNode method(ClassNode node,String name,String desc){var found=node.methods.stream().filter(m->m.name.equals(name)&&m.desc.equals(desc)).toList();check(found.size()==1,"Unique method "+name);return found.get(0);}
  static void verify(ClassNode node)throws Exception{for(MethodNode m:node.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<>(new BasicVerifier()).analyze(node.name,m);}
  public static void main(String[] args)throws Exception{
    Path input=Path.of(args[0]),body=Path.of(args[1]),output=Path.of(args[2]),receipt=Path.of(args[3]);byte[] original=Files.readAllBytes(input),bodyBytes=Files.readAllBytes(body);
    check(sha(original).equals("0bce3bad95b2a5f4c2e00b1cb2293bb39d20b0e40234bb676ca67151d83e42ae"),"Exact unchanged IF53.2/IF54 ChunkTracker input");
    check(sha(bodyBytes).equals("2092fe2cd1ebf4a49bc7647a67b1681eb8139e478c3638ce76288cbfa6a905bb"),"Exact reviewed own guard body");
    ClassNode target=read(original),guardClass=read(bodyBytes);check(target.name.equals(TARGET),"Exact target class");check(target.methods.stream().noneMatch(m->m.name.equals(GUARD)),"No existing method shadowed");
    MethodNode guarded=method(target,"getJavaBlockState",METHOD_DESC);MethodInsnNode call=null;
    for(AbstractInsnNode instruction:guarded.instructions)if(instruction instanceof MethodInsnNode m&&m.owner.equals("net/raphimc/viabedrock/protocol/storage/ConnectedBlockShapes")&&m.name.equals("isConnected")){check(call==null,"Only one shape classification site");call=m;}
    check(call!=null&&call.getOpcode()==INVOKESTATIC,"Exact existing connected classifier");check(call.getPrevious() instanceof VarInsnNode v&&v.getOpcode()==ALOAD&&v.var==3,"Classifier consumes local3 mapped model");check(call.getNext() instanceof JumpInsnNode j&&j.getOpcode()==IFEQ,"Classifier branches to original direct return");
    LabelNode direct=((JumpInsnNode)call.getNext()).label;AbstractInsnNode next=direct;while(next!=null&&next.getOpcode()<0)next=next.getNext();check(next instanceof VarInsnNode v&&v.getOpcode()==ILOAD&&v.var==2&&next.getNext().getOpcode()==IRETURN,"Original direct return unchanged");
    InsnList inserted=new InsnList();inserted.add(new VarInsnNode(ALOAD,0));inserted.add(new VarInsnNode(ALOAD,1));inserted.add(new VarInsnNode(ALOAD,3));inserted.add(new MethodInsnNode(INVOKESPECIAL,TARGET,GUARD,GUARD_DESC,false));inserted.add(new JumpInsnNode(IFNE,direct));guarded.instructions.insertBefore(call.getPrevious(),inserted);check(guarded.maxStack>=3,"Existing stack maximum sufficient; do not recompute frames or maxima");
    MethodNode helper=method(guardClass,"test","(L"+TARGET+";"+POS+MODEL+")Z");helper.name=GUARD;helper.desc=GUARD_DESC;helper.access=ACC_PRIVATE;helper.signature=null;helper.parameters=null;helper.localVariables=null;helper.visibleLocalVariableAnnotations=null;helper.invisibleLocalVariableAnnotations=null;
    for(AbstractInsnNode instruction:helper.instructions.toArray()){
      if(instruction instanceof LineNumberNode)helper.instructions.remove(instruction);
      if(instruction instanceof MethodInsnNode m)check(!m.owner.equals(guardClass.name),"No references to unshipped body class");
      if(instruction instanceof FieldInsnNode f)check(!f.owner.equals(guardClass.name),"No body-class fields");
    }
    target.methods.add(helper);verify(target);ClassWriter writer=new ClassWriter(new ClassReader(original),0);target.accept(writer);byte[] candidate=writer.toByteArray();ClassNode restored=read(candidate);verify(restored);
    MethodNode undo=method(restored,"getJavaBlockState",METHOD_DESC);MethodInsnNode guardCall=null;for(AbstractInsnNode instruction:undo.instructions)if(instruction instanceof MethodInsnNode m&&m.owner.equals(TARGET)&&m.name.equals(GUARD)){check(guardCall==null,"Exactly one injected call");guardCall=m;}
    check(guardCall!=null&&guardCall.getOpcode()==INVOKESPECIAL&&guardCall.desc.equals(GUARD_DESC),"Exact private guard call");AbstractInsnNode first=guardCall.getPrevious().getPrevious().getPrevious();int[] slots={0,1,3};AbstractInsnNode cursor=first;for(int slot:slots){check(cursor instanceof VarInsnNode v&&v.getOpcode()==ALOAD&&v.var==slot,"Exact injected load");cursor=cursor.getNext();}check(cursor==guardCall,"Exact injection sequence");check(cursor.getNext() instanceof JumpInsnNode j&&j.getOpcode()==IFNE,"Exact injected branch");
    cursor=first;for(int i=0;i<5;i++){AbstractInsnNode following=cursor.getNext();undo.instructions.remove(cursor);cursor=following;}
    check(restored.methods.removeIf(m->m.name.equals(GUARD)&&m.desc.equals(GUARD_DESC)),"Remove one private helper");String before=canonical(read(original)),after=canonical(restored);check(before.equals(after),"Whole-class canonical inverse preserves every original method/frame/attribute");
    Files.createDirectories(output.getParent());Files.write(output,candidate);String result="{\n  \"pass\": true,\n  \"input_sha256\": \""+sha(original)+"\",\n  \"candidate_sha256\": \""+sha(candidate)+"\",\n  \"input_bytes\": "+original.length+",\n  \"candidate_bytes\": "+candidate.length+",\n  \"guard_body_sha256\": \""+sha(bodyBytes)+"\",\n  \"existing_instruction_additions\": 5,\n  \"private_method_additions\": 1,\n  \"whole_class_canonical_inverse\": true,\n  \"original_frames_and_maxima_preserved\": true,\n  \"basic_verifier_all_methods\": true,\n  \"original_canonical_sha256\": \""+sha(before.getBytes(StandardCharsets.UTF_8))+"\"\n}\n";Files.writeString(receipt,result);System.out.println(result);
  }
}
