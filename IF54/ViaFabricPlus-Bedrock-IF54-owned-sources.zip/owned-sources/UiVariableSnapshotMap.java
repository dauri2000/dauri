package net.raphimc.viabedrock.api.resourcepack.ui;

import com.viaversion.viaversion.libs.gson.JsonElement;
import java.util.*;

/** Session-local shallow snapshots. Pages hold references, never evaluated bindings or item results. */
public final class UiVariableSnapshotMap extends AbstractMap<String, JsonElement> {
    private static final Object ABSENT = new Object();
    private static final int PAGE_SHIFT = 5;
    private static final int PAGE_SIZE = 1 << PAGE_SHIFT;
    private static final int PAGE_MASK = PAGE_SIZE - 1;
    private static final String CONTAINER_CONTROLLER = "net.raphimc.viabedrock.api.resourcepack.ui.ContainerUi$Controller";

    // This domain belongs only to the maps descended from one source scope in one resolution.
    // It stores keys, not values; a key introduced by a sibling is absent in pages that lack it.
    private final Map<String, Integer> indices;
    private final List<String> keys;
    private Object[][] pages;
    private Object owner = new Object();
    private int count;
    private int modifications;

    public static Map<String, JsonElement> copy(Map<String, JsonElement> source, UiBindings bindings) {
        if (bindings == null || !bindings.getClass().getName().equals(CONTAINER_CONTROLLER)) return new HashMap<>(source);
        return copy(source);
    }

    static UiVariableSnapshotMap copy(Map<String, JsonElement> source) {
        if (source instanceof UiVariableSnapshotMap previous) {
            // Invalidate the old map's write ownership before sharing its pages. Neither map can
            // mutate an old page after this point; each copies its first modified page lazily.
            previous.owner = new Object();
            return new UiVariableSnapshotMap(previous.indices, previous.keys, previous.pages.clone(), previous.count);
        }
        var result = new UiVariableSnapshotMap(new HashMap<>(), new ArrayList<>(), new Object[0][], 0);
        source.forEach(result::put);
        result.modifications = 0;
        return result;
    }

    private UiVariableSnapshotMap(Map<String, Integer> indices, List<String> keys, Object[][] pages, int count) {
        this.indices = indices;
        this.keys = keys;
        this.pages = pages;
        this.count = count;
    }

    private Object value(int index) {
        int page = index >>> PAGE_SHIFT;
        return page >= pages.length || pages[page] == null ? ABSENT : pages[page][1 + (index & PAGE_MASK)];
    }

    private Object lookup(Object key) {
        Integer index = indices.get(key);
        return index == null ? ABSENT : value(index);
    }

    private void store(int index, Object value) {
        int pageIndex = index >>> PAGE_SHIFT;
        if (pageIndex >= pages.length) pages = Arrays.copyOf(pages, pageIndex + 1);
        Object[] page = pages[pageIndex];
        if (page == null) {
            page = new Object[PAGE_SIZE + 1];
            Arrays.fill(page, ABSENT);
            page[0] = owner;
            pages[pageIndex] = page;
        } else if (page[0] != owner) {
            page = page.clone();
            page[0] = owner;
            pages[pageIndex] = page;
        }
        page[1 + (index & PAGE_MASK)] = value;
    }

    @Override public int size() { return count; }
    @Override public boolean containsKey(Object key) { return lookup(key) != ABSENT; }
    @Override public JsonElement get(Object key) {
        Object value = lookup(key);
        return value == ABSENT ? null : (JsonElement) value;
    }

    @Override public JsonElement put(String key, JsonElement value) {
        Integer index = indices.get(key);
        if (index == null) {
            index = keys.size();
            indices.put(key, index);
            keys.add(key);
        }
        Object previous = value(index);
        store(index, value);
        if (previous == ABSENT) { count++; modifications++; return null; }
        return (JsonElement) previous;
    }

    @Override public JsonElement remove(Object key) {
        Integer index = indices.get(key);
        if (index == null) return null;
        Object previous = value(index);
        if (previous == ABSENT) return null;
        store(index, ABSENT);
        count--; modifications++;
        return (JsonElement) previous;
    }

    @Override public void clear() {
        if (count != 0) modifications++;
        pages = new Object[0][];
        owner = new Object();
        count = 0;
    }

    private List<String> activeKeys() {
        var result = new ArrayList<String>(count);
        for (int index = 0; index < keys.size(); index++) if (value(index) != ABSENT) result.add(keys.get(index));
        return result;
    }

    @Override public Set<Map.Entry<String, JsonElement>> entrySet() { return new EntryView(); }
    private final class EntryView extends AbstractSet<Map.Entry<String, JsonElement>> {
        @Override public int size() { return count; }
        @Override public void clear() { UiVariableSnapshotMap.this.clear(); }
        @Override public Iterator<Map.Entry<String, JsonElement>> iterator() { return new EntryIterator(activeKeys()); }
    }

    private final class EntryIterator implements Iterator<Map.Entry<String, JsonElement>> {
        private final Iterator<String> keys;
        private int expected = modifications;
        private String current;
        private boolean canRemove;
        EntryIterator(List<String> keys) { this.keys = keys.iterator(); }
        private void check() { if (expected != modifications) throw new ConcurrentModificationException(); }
        @Override public boolean hasNext() { return keys.hasNext(); }
        @Override public Map.Entry<String, JsonElement> next() {
            check(); current = keys.next(); canRemove = true; return new LiveEntry(current);
        }
        @Override public void remove() {
            check();
            if (!canRemove) throw new IllegalStateException();
            UiVariableSnapshotMap.this.remove(current);
            expected = modifications; canRemove = false;
        }
    }

    private final class LiveEntry implements Map.Entry<String, JsonElement> {
        private final String key;
        LiveEntry(String key) { this.key = key; }
        @Override public String getKey() { return key; }
        @Override public JsonElement getValue() { return UiVariableSnapshotMap.this.get(key); }
        @Override public JsonElement setValue(JsonElement value) { return UiVariableSnapshotMap.this.put(key, value); }
        @Override public boolean equals(Object other) {
            return other instanceof Map.Entry<?, ?> entry && Objects.equals(key, entry.getKey()) && Objects.equals(getValue(), entry.getValue());
        }
        @Override public int hashCode() { return Objects.hashCode(key) ^ Objects.hashCode(getValue()); }
        @Override public String toString() { return key + "=" + getValue(); }
    }
}
