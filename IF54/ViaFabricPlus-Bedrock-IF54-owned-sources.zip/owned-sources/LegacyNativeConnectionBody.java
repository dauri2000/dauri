import com.viaversion.nbt.tag.CompoundTag;
import com.viaversion.nbt.tag.IntTag;
import com.viaversion.nbt.tag.StringTag;
import net.raphimc.viabedrock.api.model.BedrockBlockState;
import net.raphimc.viabedrock.protocol.rewriter.BlockStateRewriter;

/** Own source for a private method in existing BlockStateRewriter; not a packaged class. */
public final class LegacyNativeConnectionBody {
  public static int test(BlockStateRewriter rewriter, CompoundTag tag) {
    if (!(tag.get("name") instanceof StringTag name)) return -1;
    CompoundTag states = tag.getCompoundTag("states");
    if (states == null) return -1;
    if (name.getValue().equals("minecraft:fire")) {
      if (states.size() != 1 || !(states.get("age") instanceof IntTag age) || age.asInt() < 0 || age.asInt() > 15) return -1;
    } else if (name.getValue().equals("minecraft:redstone_wire")) {
      if (states.size() != 1 || !(states.get("redstone_signal") instanceof IntTag signal) || signal.asInt() < 0 || signal.asInt() > 15) return -1;
    } else if (name.getValue().equals("minecraft:chorus_plant")) {
      if (!states.isEmpty()) return -1;
    } else return -1;
    return rewriter.bedrockId(BedrockBlockState.fromNbt(tag));
  }
}
