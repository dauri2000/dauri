import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.ZipFile;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

/** Private experiment: three remaining lexical scope copies use the existing container-only snapshot factory. */
public final class PatchSessionCopies implements Opcodes {
    static final String OWNER="net/raphimc/viabedrock/api/resourcepack/ui/JsonUiProgram$Session";
    static final String HELPER="net/raphimc/viabedrock/api/resourcepack/ui/UiVariableSnapshotMap";
    static final String SHA="630a70475327fbcccd8ba4202fd047f4edf1d4d2c1463e87d30c116870191e67";
    static final String BINDINGS="Lnet/raphimc/viabedrock/api/resourcepack/ui/UiBindings;";
    static final Map<String,Integer> SITES=Map.of("animation",2,"children",3,"collection",3);
    static ClassNode read(byte[] bytes){var c=new ClassNode();new ClassReader(bytes).accept(c,0);return c;}
    static byte[] canonical(ClassNode c){var w=new ClassWriter(0);c.accept(w);return w.toByteArray();}
    static String sha(byte[] b)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));}
    static void verify(ClassNode c)throws Exception{for(var m:c.methods)if((m.access&(ACC_NATIVE|ACC_ABSTRACT))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);}
    public static void main(String[] args)throws Exception {
        byte[] input;try(var z=new ZipFile(args[0])){input=z.getInputStream(z.getEntry(OWNER+".class")).readAllBytes();}
        if(!sha(input).equals(SHA))throw new AssertionError("Unexpected exact IF53.2 Session");
        var c=read(input);Map<String,Integer> counts=new TreeMap<>();
        for(var m:c.methods)if(SITES.containsKey(m.name))for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode call&&call.getOpcode()==INVOKESPECIAL&&call.owner.equals("java/util/HashMap")&&call.name.equals("<init>")&&call.desc.equals("(Ljava/util/Map;)V")){
            var load=call.getPrevious();var dup=load.getPrevious();var allocation=dup.getPrevious();
            if(!(load instanceof VarInsnNode v&&v.getOpcode()==ALOAD&&v.var==SITES.get(m.name)&&dup.getOpcode()==DUP&&allocation instanceof TypeInsnNode n&&n.getOpcode()==NEW&&n.desc.equals("java/util/HashMap")))throw new AssertionError("Unexpected site "+m.name);
            m.instructions.remove(allocation);m.instructions.remove(dup);
            var context=new InsnList();context.add(new VarInsnNode(ALOAD,0));context.add(new FieldInsnNode(GETFIELD,OWNER,"bindings",BINDINGS));m.instructions.insertBefore(call,context);
            call.setOpcode(INVOKESTATIC);call.owner=HELPER;call.name="copy";call.desc="(Ljava/util/Map;"+BINDINGS+")Ljava/util/Map;";call.itf=false;counts.merge(m.name,1,Integer::sum);
        }
        if(!counts.equals(new TreeMap<>(Map.of("animation",1,"children",1,"collection",1))))throw new AssertionError("Unexpected copy sites "+counts);
        verify(read(input));verify(c);byte[] output=canonical(c);verify(read(output));
        var reversed=read(output);int undone=0;
        for(var m:reversed.methods)if(SITES.containsKey(m.name))for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode call&&call.owner.equals(HELPER)&&call.name.equals("copy")){
            var field=call.getPrevious();var self=field.getPrevious();var source=self.getPrevious();
            if(!(field instanceof FieldInsnNode f&&f.getOpcode()==GETFIELD&&f.owner.equals(OWNER)&&f.name.equals("bindings")&&f.desc.equals(BINDINGS)&&self instanceof VarInsnNode v&&v.getOpcode()==ALOAD&&v.var==0&&source instanceof VarInsnNode s&&s.getOpcode()==ALOAD&&s.var==SITES.get(m.name)))throw new AssertionError("Unexpected reverse site");
            m.instructions.remove(field);m.instructions.remove(self);var prefix=new InsnList();prefix.add(new TypeInsnNode(NEW,"java/util/HashMap"));prefix.add(new InsnNode(DUP));m.instructions.insertBefore(source,prefix);
            call.setOpcode(INVOKESPECIAL);call.owner="java/util/HashMap";call.name="<init>";call.desc="(Ljava/util/Map;)V";call.itf=false;undone++;
        }
        if(undone!=3||!Arrays.equals(canonical(read(input)),canonical(reversed)))throw new AssertionError("Whole-class canonical inverse differs");
        Path out=Path.of(args[1],OWNER+".class");Files.createDirectories(out.getParent());Files.write(out,output);
        System.out.println("PASS exact IF53.2 Session "+SHA+"; three lexical scope copies replaced: "+counts);
        System.out.println("PASS all original/candidate methods BasicVerifier; complete canonical inverse recovers original; original frames/maxima retained");
        System.out.println("CANDIDATE_SHA256="+sha(output));
    }
}
