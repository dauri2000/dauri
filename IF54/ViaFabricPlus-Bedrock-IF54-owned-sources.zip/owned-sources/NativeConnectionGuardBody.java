import com.viaversion.nbt.tag.ByteTag;
import com.viaversion.nbt.tag.CompoundTag;
import com.viaversion.nbt.tag.IntTag;
import com.viaversion.nbt.tag.StringTag;
import com.viaversion.viaversion.api.minecraft.BlockPosition;
import net.raphimc.viabedrock.api.model.BedrockBlockState;
import net.raphimc.viabedrock.api.model.BlockState;
import net.raphimc.viabedrock.protocol.rewriter.BlockStateRewriter;
import net.raphimc.viabedrock.protocol.storage.ChunkTracker;

/** Own source for one method transplanted into existing ChunkTracker; this class is never packaged. */
public final class NativeConnectionGuardBody {
  public static boolean test(ChunkTracker chunks, BlockPosition position, BlockState javaState) {
    if (javaState == null) return false;
    String name = javaState.namespacedIdentifier();
    boolean wire = name.equals("minecraft:redstone_wire");
    boolean chorus = name.equals("minecraft:chorus_plant");
    if (!wire && !chorus) return false;
    BlockState nativeState = chunks.user().get(BlockStateRewriter.class).blockState(chunks.getBlockState(position));
    if (!(nativeState instanceof BedrockBlockState typed) || !name.equals(nativeState.namespacedIdentifier())) return false;
    CompoundTag states = typed.blockStateTag().getCompoundTag("states");
    if (states == null) return false;
    if (wire) {
      if (!(states.size() == 5 && states.get("redstone_signal") instanceof IntTag
        && states.get("redstone_east") instanceof StringTag && states.get("redstone_north") instanceof StringTag
        && states.get("redstone_south") instanceof StringTag && states.get("redstone_west") instanceof StringTag)) return false;
      int signal = states.getIntTag("redstone_signal").asInt();
      String east = states.getStringTag("redstone_east").getValue(), north = states.getStringTag("redstone_north").getValue();
      String south = states.getStringTag("redstone_south").getValue(), west = states.getStringTag("redstone_west").getValue();
      return signal >= 0 && signal <= 15
        && (east.equals("none") || east.equals("side") || east.equals("up"))
        && (north.equals("none") || north.equals("side") || north.equals("up"))
        && (south.equals("none") || south.equals("side") || south.equals("up"))
        && (west.equals("none") || west.equals("side") || west.equals("up"));
    }
    if (!(states.size() == 6
      && states.get("minecraft:connection_down") instanceof ByteTag && states.get("minecraft:connection_east") instanceof ByteTag
      && states.get("minecraft:connection_north") instanceof ByteTag && states.get("minecraft:connection_south") instanceof ByteTag
      && states.get("minecraft:connection_up") instanceof ByteTag && states.get("minecraft:connection_west") instanceof ByteTag)) return false;
    byte down = states.getByteTag("minecraft:connection_down").asByte(), east = states.getByteTag("minecraft:connection_east").asByte();
    byte north = states.getByteTag("minecraft:connection_north").asByte(), south = states.getByteTag("minecraft:connection_south").asByte();
    byte up = states.getByteTag("minecraft:connection_up").asByte(), west = states.getByteTag("minecraft:connection_west").asByte();
    return down >= 0 && down <= 1 && east >= 0 && east <= 1 && north >= 0 && north <= 1
      && south >= 0 && south <= 1 && up >= 0 && up <= 1 && west >= 0 && west <= 1;
  }
}
