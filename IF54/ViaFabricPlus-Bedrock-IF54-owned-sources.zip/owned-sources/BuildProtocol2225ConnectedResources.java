import com.google.gson.*;
import com.viaversion.nbt.io.NBTIO;
import com.viaversion.nbt.tag.*;
import io.netty.buffer.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;
import net.raphimc.viabedrock.api.model.BedrockBlockState;
import net.raphimc.viabedrock.api.model.BlockState;
import net.raphimc.viabedrock.api.util.BlockStateHasher;
import net.raphimc.viabedrock.protocol.types.BedrockTypes;

/** Own offline, exact-input data transformation. No game, server, packet transport or inputs. */
public final class BuildProtocol2225ConnectedResources {
  static final String PALETTE="assets/viabedrock/data/bedrock/block_palette.nbt";
  static final String MAPPINGS="assets/viabedrock/data/custom/blockstate_mappings.json";
  static final String[] FIRE_DIRECTIONS={"east","north","south","up","west"};
  static final String[] WIRE_DIRECTIONS={"east","north","south","west"};
  static final String[] CHORUS_DIRECTIONS={"down","east","north","south","up","west"};
  static final Set<String> ADAPTED=Set.of("minecraft:fire","minecraft:redstone_wire","minecraft:chorus_plant");
  static final Set<String> UNSUPPORTED=Set.of("minecraft:icicle","minecraft:ice_crystal","minecraft:disc_press");
  static final String SOURCE_COMMIT="e963aeca854711b5ba843541f6e03ccfcadd3ef1";
  static int checks;
  static void check(boolean condition,String why){checks++;if(!condition)throw new AssertionError(why);}
  static String sha(byte[] bytes)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));}
  static String key(CompoundTag state){return BedrockBlockState.fromNbt(state.copy()).toBlockStateString(true);}
  static CompoundTag readPalette(byte[] bytes)throws Exception{return NBTIO.reader(CompoundTag.class).named().read(new GZIPInputStream(new ByteArrayInputStream(bytes)));}
  static int integer(CompoundTag states,String name,int maximum){check(states.get(name) instanceof IntTag,"IntTag property "+name);int value=states.getIntTag(name).asInt();check(value>=0&&value<=maximum,"Integer domain "+name);return value;}
  static boolean flag(CompoundTag states,String name){check(states.get(name) instanceof ByteTag,"ByteTag property "+name);int value=states.getByteTag(name).asByte();check(value==0||value==1,"Boolean domain "+name);return value!=0;}
  static String wire(CompoundTag states,String name){check(states.get(name) instanceof StringTag,"StringTag property "+name);String value=states.getStringTag(name).getValue();check(Set.of("none","side","up").contains(value),"Wire connection domain");return value;}
  static String mapped(CompoundTag state,JsonObject oldMappings){
    String name=state.getStringTag("name").getValue();CompoundTag values=state.getCompoundTag("states");BlockState result;
    if(name.equals("minecraft:fire")){
      check(values.size()==6,"Fire property set");int age=integer(values,"age",15);
      result=BlockState.fromString(oldMappings.get("minecraft:fire[age="+age+"]").getAsString());
      for(String direction:FIRE_DIRECTIONS)result=result.withProperty(direction,Boolean.toString(flag(values,"minecraft:connection_"+direction)));
    }else if(name.equals("minecraft:redstone_wire")){
      check(values.size()==5,"Wire property set");int power=integer(values,"redstone_signal",15);
      result=BlockState.fromString(oldMappings.get("minecraft:redstone_wire[redstone_signal="+power+"]").getAsString());
      check(result.hasProperty("power",Integer.toString(power)),"Existing signal-to-power translation");
      for(String direction:WIRE_DIRECTIONS)result=result.withProperty(direction,wire(values,"redstone_"+direction));
    }else if(name.equals("minecraft:chorus_plant")){
      check(values.size()==6,"Chorus property set");result=BlockState.fromString(oldMappings.get("minecraft:chorus_plant").getAsString());
      for(String direction:CHORUS_DIRECTIONS)result=result.withProperty(direction,Boolean.toString(flag(values,"minecraft:connection_"+direction)));
    }else throw new AssertionError("No mapping rule for "+name);
    return result.toBlockStateString(true);
  }
  public static void main(String[] args)throws Exception{
    Path core=Path.of(args[0]),source=Path.of(args[1]),output=Path.of(args[2]);
    check(sha(Files.readAllBytes(core)).equals("0df3a2a6c7e35491380d0d5565968e32ab354b307e4f027cc0a4ad02fc75a89a"),"Exact immutable IF53.2 source core");
    byte[] sourceBytes=Files.readAllBytes(source);check(sha(sourceBytes).equals("9d0feee0cd2edc1499bd7f7922615caee4dd268b598fca45dc396f4d0bdcdaa3"),"Exact pinned protocol2225 registry");
    byte[] oldPalette,oldMappings;try(ZipFile zip=new ZipFile(core.toFile())){oldPalette=zip.getInputStream(zip.getEntry(PALETTE)).readAllBytes();oldMappings=zip.getInputStream(zip.getEntry(MAPPINGS)).readAllBytes();}
    check(sha(oldPalette).equals("54c9bed0bef30aadc316b21c6e82b5ac407c5c6e351b9d9690aa4e9a49fec912"),"Exact old palette");
    check(sha(oldMappings).equals("2a81520dd9093b00d26fca4125d899db97861ce8fdbc451cfd1d7106902b36fa"),"Exact old mappings");
    CompoundTag oldRoot=readPalette(oldPalette),sourceRoot=readPalette(sourceBytes);
    var oldStates=oldRoot.getListTag("blocks",CompoundTag.class);var sourceStates=sourceRoot.getListTag("blocks",CompoundTag.class);
    check(oldStates.size()==22091 && sourceStates.size()==23960,"Finite versioned registry counts");
    List<CompoundTag> originals=oldStates.getValue().stream().map(CompoundTag::copy).toList();
    Map<String,CompoundTag> oldByKey=new HashMap<>(),sourceByKey=new HashMap<>();Set<Integer> hashes=new HashSet<>(),sourceHashes=new HashSet<>();
    for(CompoundTag state:oldStates){check(oldByKey.put(key(state),state.copy())==null,"Old logical uniqueness");check(hashes.add(state.getIntTag("network_id").asInt()),"Old runtime uniqueness");check(BlockStateHasher.hash(state)==state.getIntTag("network_id").asInt(),"Actual old typed NBT hash");}
    JsonObject oldJson=JsonParser.parseString(new String(oldMappings,StandardCharsets.UTF_8)).getAsJsonObject();JsonObject additions=new JsonObject();JsonArray newRows=new JsonArray(),unsupported=new JsonArray();Map<String,Integer> counts=new TreeMap<>();int common=0;
    for(CompoundTag state:sourceStates){
      String nativeKey=key(state),name=state.getStringTag("name").getValue();int runtime=state.getIntTag("network_id").asInt();
      check(sourceByKey.put(nativeKey,state.copy())==null,"New registry logical uniqueness");check(sourceHashes.add(runtime),"New registry runtime uniqueness");check(BlockStateHasher.hash(state)==runtime,"All23960 real production hashes match typed registry");
      CompoundTag previous=oldByKey.get(nativeKey);
      if(previous!=null){check(previous.equals(state),"Every common typed metadata field is identical");common++;continue;}
      if(UNSUPPORTED.contains(name)){JsonObject row=new JsonObject();row.addProperty("native_state",nativeKey);row.addProperty("runtime_id",runtime);row.addProperty("reason","No corresponding block registry/model in unchanged Java26.3; no arbitrary replacement assigned");unsupported.add(row);continue;}
      check(ADAPTED.contains(name),"Explicit finite supported family allowlist");
      check(!hashes.contains(runtime),"New runtime does not collide with any retained old runtime");hashes.add(runtime);
      String javaKey=mapped(state,oldJson);check(!oldJson.has(nativeKey)&&!additions.has(nativeKey),"No overwrite or duplicate mapping");additions.addProperty(nativeKey,javaKey);oldStates.add(state.copy());counts.merge(name,1,Integer::sum);
      JsonObject row=new JsonObject();row.addProperty("name",name);row.addProperty("native_state",nativeKey);row.addProperty("runtime_id",runtime);row.addProperty("java_state",javaKey);newRows.add(row);
    }
    check(common==22058,"22058 identical common states");check(additions.size()==1872,"Exactly1872 explicit connected-state additions");check(unsupported.size()==30,"Exactly30 unsupported new-content states retained as explicit limitation");
    check(counts.equals(Map.of("minecraft:fire",512,"minecraft:redstone_wire",1296,"minecraft:chorus_plant",64)),"Exact family counts");check(oldStates.size()==23963,"All22091 old states retained plus1872 additions");
    for(int i=0;i<originals.size();i++)check(originals.get(i).equals(oldStates.get(i)),"Original typed palette entry unchanged in original position");
    JsonArray anchorSources=new JsonArray();Set<String> officialObserved=new HashSet<>();
    for(int i=3;i<args.length;i++){
      Path path=Path.of(args[i]);byte[] bytes=Files.readAllBytes(path);ByteBuf input=Unpooled.wrappedBuffer(bytes);int matched=0;
      try{CompoundTag structure=(CompoundTag)BedrockTypes.TAG_LE.read(input);check(!input.isReadable(),"Exact native structure consumption");var palette=structure.getCompoundTag("structure").getCompoundTag("palette").getCompoundTag("default").getListTag("block_palette",CompoundTag.class);
        for(CompoundTag state:palette){String nativeKey=key(state);CompoundTag registry=sourceByKey.get(nativeKey);check(registry!=null,"Official structure state exists in pinned registry");check(state.getCompoundTag("states").equals(registry.getCompoundTag("states")),"Official raw NBT types and values exactly match registry");check(state.get("version").equals(registry.get("version")),"Official NBT version matches registry");check(BlockStateHasher.hash(state)==registry.getIntTag("network_id").asInt(),"Official raw NBT hash matches registry networkID");officialObserved.add(nativeKey);matched++;}
      }finally{input.release();}
      JsonObject row=new JsonObject();row.addProperty("file",path.toString());row.addProperty("sha256",sha(bytes));row.addProperty("bytes",bytes.length);row.addProperty("palette_entries_matched",matched);anchorSources.add(row);
    }
    check(officialObserved.stream().anyMatch(k->k.startsWith("minecraft:fire[age=0,")),"Official causal fire anchor present");
    ByteArrayOutputStream compressed=new ByteArrayOutputStream();try(GZIPOutputStream gzip=new GZIPOutputStream(compressed)){NBTIO.writer().named().write(gzip,oldRoot);}
    String originalJson=new String(oldMappings,StandardCharsets.UTF_8);int close=originalJson.lastIndexOf('}'),insertion=close;check(close>=0&&originalJson.substring(close+1).isBlank(),"Original JSON delimiter");while(insertion>0&&Character.isWhitespace(originalJson.charAt(insertion-1)))insertion--;
    Gson gson=new Gson();StringBuilder inserted=new StringBuilder();for(var entry:additions.entrySet())inserted.append(",\n  ").append(gson.toJson(entry.getKey())).append(": ").append(gson.toJson(entry.getValue().getAsString()));
    String json=originalJson.substring(0,insertion)+inserted+originalJson.substring(insertion);check((json.substring(0,insertion)+json.substring(insertion+inserted.length())).equals(originalJson),"Canonical exact JSON inverse restores all original bytes");JsonObject parsed=JsonParser.parseString(json).getAsJsonObject();check(parsed.size()==oldJson.size()+1872,"Only1872 JSON entries added");for(var entry:oldJson.entrySet())check(entry.getValue().equals(parsed.get(entry.getKey())),"Every old JSON mapping unchanged");
    Path palettePath=output.resolve("resources").resolve(PALETTE),mappingPath=output.resolve("resources").resolve(MAPPINGS);Files.createDirectories(palettePath.getParent());Files.createDirectories(mappingPath.getParent());Files.write(palettePath,compressed.toByteArray());Files.writeString(mappingPath,json,StandardCharsets.UTF_8);
    JsonObject result=new JsonObject();result.addProperty("pass",true);result.addProperty("checks",checks);result.addProperty("source_commit",SOURCE_COMMIT);result.addProperty("source_registry_sha256",sha(sourceBytes));result.addProperty("source_registry_count",23960);result.addProperty("common_exact_typed_states",common);result.addProperty("retained_old_states",22091);result.addProperty("retained_old_states_absent_from_new_registry",33);result.addProperty("appended_states",1872);result.addProperty("candidate_palette_count",23963);result.addProperty("new_content_not_mapped",30);result.addProperty("scope","Full versioned registry was audited for typed hashes, common metadata, and finite mapping coverage.1872 connected-state entries are added without removing or changing old entries.30 new-content states lack a Java26.3 counterpart and are explicitly excluded; no claim of every behavior/render being tested.");result.add("official_anchor_sources",anchorSources);result.addProperty("official_unique_states_in_anchor_structures",officialObserved.size());result.add("new_states",newRows);result.add("unsupported_new_content",unsupported);
    JsonArray resources=new JsonArray();for(Path path:List.of(palettePath,mappingPath)){JsonObject row=new JsonObject();row.addProperty("file",path.toString());row.addProperty("sha256",sha(Files.readAllBytes(path)));row.addProperty("bytes",Files.size(path));resources.add(row);}result.add("resources",resources);Files.writeString(output.resolve("build-verification.json"),new GsonBuilder().setPrettyPrinting().create().toJson(result)+"\n");System.out.println("PASS checks="+checks+" registry23960 common22058 old22091 kept append1872 unsupported30");
  }
}
