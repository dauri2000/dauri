# IF36: autollenado con cuadrícula ocupada e inventario casi lleno

## Causa y evidencia

`CraftingPlacement.plan` de IF35 intentaba devolver cada casilla ocupada a un hueco vacío independiente del inventario, antes de asignar ingredientes. No apilaba esos objetos con pilas compatibles y tampoco conservaba las casillas que ya coincidían con la nueva receta. Si había 34 pilas en inventario y 3 casillas ocupadas, solo quedaban dos huecos: devolvía null antes de buscar ingredientes. Con 36 pilas y 8 casillas tampoco podía empezar.

Son los dos estados observados en los diagnósticos del último `latest.log` (líneas 263–268): tracker listo, IDs presentes, 61 o 56 unidades de material en inventario. Se reprodujeron ambos rechazos ejecutando la clase original del ViaBedrock incrustado en IF35. Ver `baseline-IF35.txt` y `baseline-IF35-second.txt`; ambos terminan con la aserción de plan válido fallida. No son fallos causados por dependencias o mocks del algoritmo.

## Cambio

- Conserva las casillas que ya contienen un ingrediente compatible; solo llena su déficit.
- Devuelve los ingredientes que sobran a pilas iguales con espacio disponible y después a huecos vacíos; puede dividir la devolución entre destinos.
- Cuenta los ingredientes recuperados de la cuadrícula al buscar fuentes.
- Planea sobre copias; un rechazo no cambia inventario, cursor ni cuadrícula.
- Construye una lista ordenada de transferencias. `actions(..., requestId)` usa el ID negativo impar actual al referirse a cualquier casilla modificada por una transferencia anterior, siguiendo el patrón existente de FurnaceRecipePlacement.
- `apply` copia el resultado calculado solo sobre las casillas modificadas y conserva cantidades y metadatos. Suprime callbacks de equipo durante la predicción y restaura `isPredictingClick` en `finally`.
- `hasTransfers` permite que los callers actualicen el resultado y respondan sin generar una petición vacía cuando la receta ya estaba colocada.

Se conservan el constructor de cinco argumentos y getters anteriores de Placement y el método actions de tres argumentos. Los dos callers de producción deben usar el nuevo overload de cuatro argumentos para que las referencias dentro de una petición sean correctas.

## Integración con los callers

`CraftingTableContainer.handleRecipePlacement` e `InventoryContainer.handleRecipePlacement` deben:

1. Tras un plan no nulo, si `!CraftingPlacement.hasTransfers(plan)`, refrescar el resultado y devolver true sin reservar ID ni enviar petición.
2. Reservar un ID de petición y pasarlo a `CraftingPlacement.actions(plan, grid, inventory, requestId)`.
3. Mantener el orden original de snapshot/registro de request, predicción y envío.

El agente principal prepara esos ajustes de bytecode en `/workspace/minecraft/analysis/if36-callers`.

## Validación

Diez escenarios pasaron en `patched-IF36.txt`: los dos estados del log, receta ya colocada con inventario lleno, materiales disponibles solo en la cuadrícula, capacidad realmente insuficiente, NBT distinto, máximos de pila 16 y 1, devolución repartida entre pila y hueco vacío, y cuadrícula inicialmente vacía.

En cada caso válido, una simulación independiente reproduce las transferencias por orden, comprueba capacidad, tipo/NBT y referencias de red, asignando nuevos IDs positivos después de cada cambio para detectar dependencias accidentales de IDs antiguos. El resultado por casilla coincide con `apply`. Se verifican conservación de cantidades/metadatos y restauración de la bandera de predicción. Los casos rechazados no modifican las entradas.

Se usan las clases originales de inventario, contenedores, recetas y acciones. Solo la conexión se sustituye por un almacén en memoria para evitar I/O real; el matcher de prueba identifica ingredientes por ID. No se han iniciado un servidor ni una sesión gráfica, ni se ha probado todavía este parche en la partida del usuario.

Los casos donde no se pueden guardar ingredientes incompatibles en ningún sitio siguen rechazándose. Esta corrección no implementa una reorganización arbitraria por ciclos cuando una cuadrícula distinta y un inventario completamente saturado no permiten evacuar sobrantes.
