import java.awt.GraphicsEnvironment;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

/** Offline updater with exact known-input/content checks. Does not launch Minecraft or modify its input. */
public final class ActualizarIF36 {
    private static final Set<String> INPUT_SHA256S = Set.of(
        "4b87fdb65e88a9683d6c6c88721a7d2678ef94fac715f0828fd20c4bac3c2140",
        "3e9762a1ca8491dc11f1275fcfd550aeb997d3bc451c7d5103fb32f08e309360",
        "879fe069b80ac6f5d4c4e0929226a0bcc126e39be6a9a8671bda75a0453347fa"
    );
    private static final String OUTPUT_NAME = "ViaFabricPlus-Bedrock-IF36.jar";
    private static final String RESOURCE_ROOT = "/actualizador/";

    private record EntrySpec(String name, String sha256, long size, boolean directory) {}

    public static void main(String[] args) {
        boolean graphical = args.length == 0 && !GraphicsEnvironment.isHeadless();
        try {
            if (args.length > 2) {
                throw new IOException("Uso: java -jar Actualizar-a-IF36.jar IF35-o-IF34.jar [carpetaSalida]");
            }
            Path input;
            if (args.length == 0) {
                if (!graphical) {
                    throw new IOException("Indica el JAR IF35 o IF34 como primer argumento.");
                }
                JFileChooser chooser = new JFileChooser();
                chooser.setDialogTitle("Selecciona ViaFabricPlus-Bedrock-IF35.jar (o IF34.jar)");
                chooser.setFileFilter(new FileNameExtensionFilter("Minecraft mods (*.jar)", "jar"));
                if (chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION) {
                    System.out.println("Cancelado; no se ha creado ningun archivo.");
                    return;
                }
                input = chooser.getSelectedFile().toPath();
            } else {
                input = Path.of(args[0]);
            }
            input = input.toAbsolutePath().normalize();
            Path outputDirectory = args.length == 2
                ? Path.of(args[1]).toAbsolutePath().normalize()
                : Path.of(ActualizarIF36.class.getProtectionDomain().getCodeSource().getLocation().toURI())
                    .toAbsolutePath().normalize().getParent();
            Path output = update(input, outputDirectory);
            String message = "IF36 creado y verificado:\n" + output
                + "\n\nCon Minecraft cerrado, mueve el complemento Bedrock anterior fuera de mods y copia alli este IF36."
                + "\nConserva ViaFabricPlus base y deja una sola version del complemento Bedrock en mods.";
            System.out.println(message);
            if (graphical) {
                JOptionPane.showMessageDialog(null, message, "Actualizacion terminada", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception error) {
            String message = "No se ha completado la actualizacion: " + error.getMessage();
            System.err.println(message);
            if (graphical) {
                JOptionPane.showMessageDialog(null, message, "Actualizacion detenida", JOptionPane.ERROR_MESSAGE);
            }
            System.exit(1);
        }
    }

    private static Path update(Path input, Path outputDirectory) throws Exception {
        if (!Files.isRegularFile(input, LinkOption.NOFOLLOW_LINKS)) {
            throw new IOException("El JAR seleccionado no existe o no es un archivo normal: " + input);
        }
        System.out.println("Comprobando el archivo IF35 o IF34 seleccionado...");
        try (InputStream source = Files.newInputStream(input)) {
            String actual = hash(source);
            if (!INPUT_SHA256S.contains(actual)) {
                // A different JRE may serialize exactly the same IF35 contents differently.
                // Accept that case only after checking every entry against the trusted IF35.
                try {
                    verify(input, readExpected("if35-reference.tsv"));
                } catch (Exception invalidInput) {
                    throw new IOException("El archivo seleccionado no coincide con IF34 o IF35 compatibles."
                        + " No se modifico. SHA256 recibido: " + actual);
                }
            }
        }
        Map<String, EntrySpec> expected = readExpected("expected.tsv");
        Set<String> changed = readChanged();
        if (!expected.keySet().containsAll(changed)) {
            throw new IOException("El actualizador contiene un manifiesto inconsistente.");
        }
        Files.createDirectories(outputDirectory);
        Path output = outputDirectory.resolve(OUTPUT_NAME);
        if (Files.exists(output, LinkOption.NOFOLLOW_LINKS)) {
            throw new IOException("Ya existe " + output + ". No se sobrescribio; elige otra carpeta.");
        }
        Path temporary = Files.createTempFile(outputDirectory, ".if36-en-proceso-", ".tmp");
        boolean completed = false;
        try {
            System.out.println("Creando IF36 sin modificar el JAR seleccionado...");
            try (ZipFile source = new ZipFile(input.toFile());
                 ZipOutputStream target = new ZipOutputStream(Files.newOutputStream(temporary))) {
                target.setLevel(6);
                for (EntrySpec spec : expected.values()) {
                    ZipEntry sourceEntry = source.getEntry(spec.name());
                    ZipEntry entry = new ZipEntry(spec.name());
                    if (sourceEntry != null && sourceEntry.getTime() >= 0) {
                        entry.setTime(sourceEntry.getTime());
                    } else {
                        entry.setTime(315532800000L);
                    }
                    target.putNextEntry(entry);
                    if (!spec.directory()) {
                        try (InputStream content = changed.contains(spec.name())
                                ? resource("payload/" + spec.name())
                                : originalContent(source, sourceEntry, spec.name())) {
                            MessageDigest digest = MessageDigest.getInstance("SHA-256");
                            long size = transfer(content, target, digest);
                            check(spec, size, HexFormat.of().formatHex(digest.digest()));
                        }
                    }
                    target.closeEntry();
                }
            }
            System.out.println("Verificando todas las entradas del nuevo JAR...");
            verify(temporary, expected);
            // No REPLACE_EXISTING: never overwrite a pre-existing output.
            Files.move(temporary, output);
            completed = true;
            System.out.println("Verificadas " + expected.size() + " entradas contra el IF36 de referencia.");
            return output;
        } finally {
            if (!completed) {
                Files.deleteIfExists(temporary);
            }
        }
    }

    private static InputStream originalContent(ZipFile source, ZipEntry entry, String name) throws IOException {
        if (entry == null) {
            throw new IOException("El JAR seleccionado no contiene la entrada esperada: " + name);
        }
        return source.getInputStream(entry);
    }

    private static Map<String, EntrySpec> readExpected(String resourceName) throws IOException {
        String manifest;
        try (InputStream input = resource(resourceName)) {
            manifest = new String(input.readAllBytes(), StandardCharsets.UTF_8);
        }
        Map<String, EntrySpec> result = new LinkedHashMap<>();
        for (String line : manifest.lines().toList()) {
            if (line.isBlank()) continue;
            String[] fields = line.split("\t", 4);
            if (fields.length != 4) throw new IOException("Manifiesto de contenido invalido.");
            boolean directory = fields[0].equals("D");
            if (!directory && !fields[0].equals("F")) throw new IOException("Tipo de entrada invalido.");
            String name = fields[3];
            if (name.startsWith("/") || name.contains("\\") || List.of(name.split("/")).contains("..")) {
                throw new IOException("Ruta invalida en manifiesto.");
            }
            EntrySpec previous = result.put(name, new EntrySpec(name, fields[1], Long.parseLong(fields[2]), directory));
            if (previous != null) throw new IOException("Entrada duplicada en manifiesto.");
        }
        if (result.isEmpty()) throw new IOException("Manifiesto vacio.");
        return result;
    }

    private static Set<String> readChanged() throws IOException {
        try (InputStream input = resource("changed.txt")) {
            return new HashSet<>(new String(input.readAllBytes(), StandardCharsets.UTF_8)
                .lines().filter(line -> !line.isBlank()).toList());
        }
    }

    private static void verify(Path output, Map<String, EntrySpec> expected) throws Exception {
        Set<String> seen = new HashSet<>();
        try (ZipFile archive = new ZipFile(output.toFile())) {
            var entries = archive.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                EntrySpec spec = expected.get(entry.getName());
                if (spec == null || !seen.add(entry.getName()) || entry.isDirectory() != spec.directory()) {
                    throw new IOException("El JAR generado contiene entradas inesperadas o duplicadas.");
                }
                try (InputStream content = archive.getInputStream(entry)) {
                    MessageDigest digest = MessageDigest.getInstance("SHA-256");
                    long size = transfer(content, OutputStream.nullOutputStream(), digest);
                    check(spec, size, HexFormat.of().formatHex(digest.digest()));
                }
            }
        }
        if (!seen.equals(expected.keySet())) {
            throw new IOException("Al JAR generado le faltan entradas.");
        }
    }

    private static void check(EntrySpec expected, long size, String sha256) throws IOException {
        if (size != expected.size() || !sha256.equals(expected.sha256())) {
            throw new IOException("Contenido incorrecto en " + expected.name() + "; no se guardo IF36.");
        }
    }

    private static InputStream resource(String name) throws IOException {
        InputStream input = ActualizarIF36.class.getResourceAsStream(RESOURCE_ROOT + name);
        if (input == null) throw new IOException("Falta un recurso del actualizador: " + name);
        return new BufferedInputStream(input);
    }

    private static long transfer(InputStream input, OutputStream output, MessageDigest digest) throws IOException {
        byte[] buffer = new byte[131072];
        long size = 0;
        int read;
        while ((read = input.read(buffer)) != -1) {
            output.write(buffer, 0, read);
            digest.update(buffer, 0, read);
            size += read;
        }
        return size;
    }

    private static String hash(InputStream input) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        transfer(input, OutputStream.nullOutputStream(), digest);
        return HexFormat.of().formatHex(digest.digest());
    }
}
