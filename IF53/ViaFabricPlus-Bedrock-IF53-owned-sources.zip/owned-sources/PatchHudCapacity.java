import java.nio.file.*;
import java.io.*;
import java.security.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import org.objectweb.asm.util.*;

/** Isolated HUD-only candidate. Preserve all57 native slots and accept an explicit legacy54 prefix without discarding opaque tail. */
public final class PatchHudCapacity implements Opcodes {
  static final String OWNER="net/raphimc/viabedrock/api/model/container/player/HudContainer";
  static final String SUPER="net/raphimc/viabedrock/api/model/container/player/InventoryRedirectContainer";
  static final String ARRAY="[Lnet/raphimc/viabedrock/protocol/model/BedrockItem;";
  static String sha(byte[] b)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));}
  static ClassNode read(byte[] b){ClassNode c=new ClassNode();new ClassReader(b).accept(c,ClassReader.EXPAND_FRAMES);return c;}
  static String text(ClassNode c){StringWriter s=new StringWriter();c.accept(new TraceClassVisitor(new PrintWriter(s)));return s.toString();}
  static MethodNode ctor(ClassNode c){return c.methods.stream().filter(m->m.name.equals("<init>")).findFirst().orElseThrow();}
  public static void main(String[] a)throws Exception {
    byte[] input=Files.readAllBytes(Path.of(a[0]));if(!sha(input).equals("de73050c143918d1d698716481ad2177cf6026c15af393c043c9739ec7b51ba0"))throw new AssertionError("Exact frozen IF52 HUD input required");
    ClassReader cr=new ClassReader(input);ClassNode c=new ClassNode();cr.accept(c,0);
    if(c.methods.stream().anyMatch(m->m.name.equals("setItems")))throw new AssertionError("Unexpected existing override");
    int constants=0;for(AbstractInsnNode n:ctor(c).instructions)if(n instanceof IntInsnNode i&&i.operand==54){if(i.getOpcode()!=BIPUSH)throw new AssertionError("Unexpected storage constant");i.operand=57;constants++;}
    if(constants!=1)throw new AssertionError("Exactly one original HUD storage constant");
    MethodNode m=new MethodNode(ACC_PUBLIC,"setItems","("+ARRAY+")Z",null,null);m.visitCode();Label full=new Label();
    m.visitVarInsn(ALOAD,1);m.visitInsn(ARRAYLENGTH);m.visitIntInsn(BIPUSH,54);m.visitJumpInsn(IF_ICMPNE,full);
    m.visitVarInsn(ALOAD,0);m.visitMethodInsn(INVOKEVIRTUAL,OWNER,"getItems","()"+ARRAY,false);m.visitVarInsn(ASTORE,2);
    m.visitVarInsn(ALOAD,1);m.visitInsn(ICONST_0);m.visitVarInsn(ALOAD,2);m.visitInsn(ICONST_0);m.visitIntInsn(BIPUSH,54);
    m.visitMethodInsn(INVOKESTATIC,"java/lang/System","arraycopy","(Ljava/lang/Object;ILjava/lang/Object;II)V",false);
    m.visitVarInsn(ALOAD,0);m.visitVarInsn(ALOAD,2);m.visitMethodInsn(INVOKESPECIAL,SUPER,"setItems","("+ARRAY+")Z",false);m.visitInsn(IRETURN);
    m.visitLabel(full);m.visitFrame(F_SAME,0,null,0,null);m.visitVarInsn(ALOAD,0);m.visitVarInsn(ALOAD,1);m.visitMethodInsn(INVOKESPECIAL,SUPER,"setItems","("+ARRAY+")Z",false);m.visitInsn(IRETURN);
    m.visitMaxs(5,3);m.visitEnd();c.methods.add(m);
    ClassWriter cw=new ClassWriter(cr,0);c.accept(cw);byte[] output=cw.toByteArray();ClassNode after=read(output);
    for(MethodNode method:after.methods)if((method.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(after.name,method);
    if(!after.methods.removeIf(method->method.name.equals("setItems")&&method.desc.equals("("+ARRAY+")Z")))throw new AssertionError("Override absent in written output");
    int restored=0;for(AbstractInsnNode n:ctor(after).instructions)if(n instanceof IntInsnNode i&&i.operand==57){i.operand=54;restored++;}
    if(restored!=1||!text(read(input)).equals(text(after)))throw new AssertionError("Whole-class inverse must restore all original events");
    Path out=Path.of(a[1]);Files.createDirectories(out.getParent());Files.write(out,output);
    System.out.println("PASS HUD-only storage54to57 plus one setItems override:57full,54prefix preserving3existing opaque tail entries, all other sizes delegated to strict base reject");
    System.out.println("PASS written-class canonical inverse and BasicVerifier; no global Container edit or new slot-name/Java-action mapping");
    System.out.println("INPUT_SHA256="+sha(input));System.out.println("CANDIDATE_SHA256="+sha(output));System.out.println("CANDIDATE_BYTES="+output.length);
  }
}
