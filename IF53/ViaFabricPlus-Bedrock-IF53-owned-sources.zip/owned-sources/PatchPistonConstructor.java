import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

/** Initialize the existing Bedrock-only moving block before publishing it to the chunk. */
public final class PatchPistonConstructor implements Opcodes {
    static final String OWNER="com/viaversion/viafabricplus/bedrock/injection/mixin/features/block/MixinBedrockMovingPistonBlock";
    static final String PISTON="net/minecraft/world/level/block/piston/PistonMovingBlockEntity";
    static final String STATE="net/minecraft/world/level/block/state/BlockState";
    static final String SHA="4fb418fee43602f7bc63827a29588d43033928a19ce929c5e66a1a37e9ad7455";
    static final String OLD="(Lnet/minecraft/core/BlockPos;L"+STATE+";)V";
    static final String NEW="(Lnet/minecraft/core/BlockPos;L"+STATE+";L"+STATE+";Lnet/minecraft/core/Direction;ZZ)V";
    static ClassNode read(byte[] b){ClassNode c=new ClassNode();new ClassReader(b).accept(c,0);return c;}
    static byte[] canonical(ClassNode c){ClassWriter w=new ClassWriter(0);c.accept(w);return w.toByteArray();}
    static String sha(byte[] b)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));}
    static MethodNode target(ClassNode c){return c.methods.stream().filter(m->m.name.equals("createNativeMovingBlock")).findFirst().orElseThrow();}
    static void verify(ClassNode c)throws Exception{for(var m:c.methods)if((m.access&(ACC_NATIVE|ACC_ABSTRACT))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);}
    static InsnList arguments(){InsnList a=new InsnList();
        a.add(new FieldInsnNode(GETSTATIC,"net/minecraft/world/level/block/Blocks","AIR","Lnet/minecraft/world/level/block/Block;"));
        a.add(new MethodInsnNode(INVOKEVIRTUAL,"net/minecraft/world/level/block/Block","defaultBlockState","()L"+STATE+";",false));
        a.add(new VarInsnNode(ALOAD,2));
        a.add(new FieldInsnNode(GETSTATIC,"net/minecraft/world/level/block/piston/MovingPistonBlock","FACING","Lnet/minecraft/world/level/block/state/properties/EnumProperty;"));
        a.add(new MethodInsnNode(INVOKEVIRTUAL,STATE,"getValue","(Lnet/minecraft/world/level/block/state/properties/Property;)Ljava/lang/Comparable;",false));
        a.add(new TypeInsnNode(CHECKCAST,"net/minecraft/core/Direction"));
        a.add(new InsnNode(ICONST_0));a.add(new InsnNode(ICONST_0));return a;
    }
    public static void main(String[] args)throws Exception {
        byte[] input=Files.readAllBytes(Path.of(args[0],OWNER+".class"));if(!sha(input).equals(SHA))throw new AssertionError("Unexpected exact IF52 input");
        ClassNode c=read(input);MethodNode m=target(c);int oldMax=m.maxStack;if(oldMax!=5)throw new AssertionError("Unexpected original maxStack");int changed=0;
        for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode call&&call.owner.equals(PISTON)&&call.name.equals("<init>")){
            if(call.getOpcode()!=INVOKESPECIAL||!call.desc.equals(OLD)||!(call.getPrevious() instanceof VarInsnNode state&&state.getOpcode()==ALOAD&&state.var==2))throw new AssertionError("Unexpected constructor callsite");
            m.instructions.insertBefore(call,arguments());call.desc=NEW;changed++;
        }
        if(changed!=1)throw new AssertionError("Unexpected constructor count");m.maxStack=9;
        verify(read(input));verify(c);byte[] output=canonical(c);verify(read(output));
        ClassNode reverse=read(output);MethodNode rm=target(reverse);int restored=0;
        for(var i:rm.instructions.toArray())if(i instanceof MethodInsnNode call&&call.owner.equals(PISTON)&&call.name.equals("<init>")&&call.desc.equals(NEW)){
            for(int n=0;n<8;n++)rm.instructions.remove(call.getPrevious());call.desc=OLD;restored++;
        }
        rm.maxStack=oldMax;
        if(restored!=1||!Arrays.equals(canonical(read(input)),canonical(reverse)))throw new AssertionError("Whole-class canonical reversal failed");
        Path path=Path.of(args[1],OWNER+".class");Files.createDirectories(path.getParent());Files.write(path,output);
        System.out.println("PASS exact IF52 input "+SHA);
        System.out.println("PASS sole constructor call2args ->6args(pos,state,AIR,state.FACING,false,false),8new argument instructions");
        System.out.println("PASS original Bedrock and null-return guards, method/class annotations, frames, locals and all other instructions unchanged");
        System.out.println("PASS original/candidate all methods BasicVerifier; only maxStack5->9 changed");
        System.out.println("PASS serialized whole-class canonical inverse restores original constructor site and maxStack");
        System.out.println("CANDIDATE_SHA256="+sha(output));System.out.println("CANDIDATE_BYTES="+output.length);
    }
}
