import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

/** Private two-class derivative. Original ContainerUi APIs and all other methods are retained. */
public final class PatchSerializedContainerScene implements Opcodes {
    static final String UI="net/raphimc/viabedrock/api/resourcepack/ui/ContainerUi";
    static final String VIEW=UI+"$MenuView";
    static final String RESULT="net/raphimc/viabedrock/api/resourcepack/ui/SerializedContainerScene";
    static final String JSON="com/viaversion/viaversion/libs/gson/JsonObject";
    static final String SCREEN="com/viaversion/viafabricplus/bedrock/screen/container/BedrockNativeContainerScreen";
    static final String SCENE="com/viaversion/viafabricplus/bedrock/screen/ui/NativeUiScene";
    static final String OLD_DESC="(L"+VIEW+";)L"+JSON+";";
    static final String NEW_DESC="(L"+VIEW+";)L"+RESULT+";";
    static final String JAR_SHA="be93f17052182a9658e019e77da23c26b1ec44d80a686ee40f3b2bf1adee71b8";
    static final String CORE_SHA="73ca6b2dbd8150d41d58467073f9791fb8bc7ded88a90db91d282aa6c5512b97";
    static final String UI_SHA="0f1ba766e8dbb48657a5918adc7b8b9072bc474149f04bb25f91a46b9e78ca8e";
    static final String SCREEN_SHA="902b8b6b4a99ffd887bc21f8f0364e14cb5ed2494e5912842c631ca3c009e57d";
    static String sha(byte[] b)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));}
    static void require(boolean b,String s){if(!b)throw new AssertionError(s);}
    static ClassNode read(byte[] b){var c=new ClassNode();new ClassReader(b).accept(c,ClassReader.EXPAND_FRAMES);return c;}
    static byte[] canonical(ClassNode c){var w=new ClassWriter(0);c.accept(w);return w.toByteArray();}
    static MethodNode method(ClassNode c,String name,String desc){return c.methods.stream().filter(m->m.name.equals(name)&&m.desc.equals(desc)).findFirst().orElseThrow();}
    static MethodNode copy(MethodNode m){var result=new MethodNode(ASM9,m.access,m.name,m.desc,m.signature,m.exceptions.toArray(String[]::new));m.accept(result);return result;}
    static void verify(ClassNode c)throws Exception{for(var m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);}
    static byte[] zip(ZipFile z,String n)throws Exception{var e=z.getEntry(n);require(e!=null,"Missing "+n);return z.getInputStream(e).readAllBytes();}
    static void output(Path root,String layer,ClassNode c)throws Exception{var p=root.resolve(layer).resolve(c.name+".class");Files.createDirectories(p.getParent());Files.write(p,canonical(c));}
    static AbstractInsnNode previousReal(AbstractInsnNode n){do{n=n.getPrevious();}while(n!=null&&n.getOpcode()<0);return n;}
    static int updateFrameLocal(MethodNode m,String before,String after,int slot){int count=0;for(var n:m.instructions)if(n instanceof FrameNode f&&f.local!=null&&f.local.size()>slot&&Objects.equals(f.local.get(slot),before)){f.local.set(slot,after);count++;}return count;}

    static ClassNode patchCore(byte[] input)throws Exception{
        require(sha(input).equals(UI_SHA),"Wrong exact IF52 ContainerUi");var c=read(input);
        require(c.methods.stream().noneMatch(m->m.name.equals("resolveSerialized")||m.name.equals("resolveSerializedScene")),"Names already present");
        var wrapper=copy(method(c,"resolve",OLD_DESC));wrapper.name="resolveSerialized";wrapper.desc=NEW_DESC;wrapper.signature=null;wrapper.localVariables=null;
        int delegate=0;for(var n:wrapper.instructions)if(n instanceof MethodInsnNode call&&call.owner.equals(UI)&&call.name.equals("resolveScene")&&call.desc.equals(OLD_DESC)){call.name="resolveSerializedScene";call.desc=NEW_DESC;delegate++;}
        require(delegate==1,"Expected exactly one legacy try/catch delegate");c.methods.add(wrapper);

        var clone=copy(method(c,"resolveScene",OLD_DESC));clone.name="resolveSerializedScene";clone.desc=NEW_DESC;clone.signature=null;clone.localVariables=null;
        int strings=0,returns=0;
        for(var n:clone.instructions.toArray())if(n instanceof MethodInsnNode call&&call.owner.equals(JSON)&&call.name.equals("toString")&&call.desc.equals("()Ljava/lang/String;")){
            var save=new InsnList();save.add(new InsnNode(DUP));save.add(new VarInsnNode(ASTORE,7));clone.instructions.insert(call,save);strings++;
        }
        for(var n:clone.instructions.toArray())if(n.getOpcode()==ARETURN&&previousReal(n) instanceof VarInsnNode v&&v.getOpcode()==ALOAD&&v.var==6){
            var result=new InsnList();result.add(new VarInsnNode(ALOAD,7));result.add(new MethodInsnNode(INVOKESTATIC,RESULT,"of","(L"+JSON+";Ljava/lang/String;)L"+RESULT+";",false));clone.instructions.insertBefore(n,result);returns++;
        }
        require(strings==1&&returns==1,"Expected one String and one non-null scene return");
        require(updateFrameLocal(clone,"com/viaversion/viaversion/libs/gson/JsonArray","java/lang/String",7)==1,"Expected final checked-String frame");
        clone.maxStack=Math.max(clone.maxStack,2);c.methods.add(clone);verify(c);
        var reversed=read(canonical(c));require(reversed.methods.removeIf(m->m.name.equals("resolveSerialized")||m.name.equals("resolveSerializedScene")),"Missing new methods");
        require(Arrays.equals(canonical(read(input)),canonical(reversed)),"Original ContainerUi bodies/fields/attributes changed");
        return c;
    }

    static ClassNode patchScreen(byte[] input)throws Exception{
        require(sha(input).equals(SCREEN_SHA),"Wrong exact IF52 prepared screen");var c=read(input);var m=method(c,"refresh","()V");
        int resolve=0,bridge=0;
        for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode call&&call.owner.equals(UI)&&call.name.equals("resolve")&&call.desc.equals(OLD_DESC)){
            call.name="resolveSerialized";call.desc=NEW_DESC;
            var keep=new InsnList();keep.add(new InsnNode(DUP));keep.add(new VarInsnNode(ASTORE,2));keep.add(new MethodInsnNode(INVOKESTATIC,RESULT,"sceneOrNull","(L"+RESULT+";)L"+JSON+";",false));m.instructions.insert(call,keep);resolve++;
        }
        for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode call&&call.owner.equals(JSON)&&call.name.equals("toString")&&call.desc.equals("()Ljava/lang/String;")){
            var prior=previousReal(call);require(prior instanceof VarInsnNode v&&v.getOpcode()==ALOAD&&v.var==3,"Unexpected refresh String source");
            ((VarInsnNode)prior).var=2;call.owner=RESULT;call.name="json";bridge++;
        }
        require(resolve==1&&bridge==1,"Expected exactly two refreshed call sites");
        int frames=updateFrameLocal(m,VIEW,RESULT,2);require(frames>0,"Expected live menu/result frame local");m.maxStack=Math.max(m.maxStack,2);verify(c);
        var r=read(canonical(c));var rm=method(r,"refresh","()V");int reversedResolve=0,reversedBridge=0;
        for(var n:rm.instructions.toArray())if(n instanceof MethodInsnNode call&&call.owner.equals(UI)&&call.name.equals("resolveSerialized")&&call.desc.equals(NEW_DESC)){
            var a=call.getNext();var b=a.getNext();var d=b.getNext();
            require(a.getOpcode()==DUP&&b instanceof VarInsnNode v&&v.getOpcode()==ASTORE&&v.var==2&&d instanceof MethodInsnNode h&&h.owner.equals(RESULT)&&h.name.equals("sceneOrNull"),"Unexpected result unwrap pattern");
            rm.instructions.remove(a);rm.instructions.remove(b);rm.instructions.remove(d);call.name="resolve";call.desc=OLD_DESC;reversedResolve++;
        }
        for(var n:rm.instructions.toArray())if(n instanceof MethodInsnNode call&&call.owner.equals(RESULT)&&call.name.equals("json")){
            var prior=previousReal(call);require(prior instanceof VarInsnNode v&&v.getOpcode()==ALOAD&&v.var==2,"Unexpected retained String source");((VarInsnNode)prior).var=3;call.owner=JSON;call.name="toString";reversedBridge++;
        }
        require(reversedResolve==1&&reversedBridge==1,"Reversal site mismatch");require(updateFrameLocal(rm,RESULT,VIEW,2)==frames,"Reversal frame mismatch");
        rm.maxStack=method(read(input),"refresh","()V").maxStack;
        require(Arrays.equals(canonical(read(input)),canonical(r)),"Changes outside exact two screen call sites/local frames");
        return c;
    }
    public static void main(String[] args)throws Exception{
        require(args.length==2,"Usage exact-published-IF52.jar output-directory");var jar=Path.of(args[0]);require(sha(Files.readAllBytes(jar)).equals(JAR_SHA),"Wrong full IF52 artifact");var out=Path.of(args[1]);require(!Files.exists(out.resolve("core/"+UI+".class")),"Never overwrite a staged candidate");
        byte[] ui,screen,core;try(var z=new ZipFile(jar.toFile())){core=zip(z,"META-INF/jars/ViaBedrock-0.0.31-StackAnvil.jar");screen=zip(z,SCREEN+".class");}
        require(sha(core).equals(CORE_SHA),"Wrong exact IF52 core");try(var z=new ZipInputStream(new java.io.ByteArrayInputStream(core))){ui=null;for(ZipEntry e;(e=z.getNextEntry())!=null;)if(e.getName().equals(UI+".class")){ui=z.readAllBytes();break;}}
        require(ui!=null,"Missing core UI class");var a=patchCore(ui);var b=patchScreen(screen);output(out,"core",a);output(out,"addon",b);
        System.out.println("PASS exact IF52 JAR/core/UI/screen SHA guards");System.out.println("PASS all original ContainerUi methods preserved; only 2 new cloned methods");System.out.println("PASS new resolveSerialized catch types and old resolveScene UTF8 limit inherited unchanged");System.out.println("PASS screen exact canonical inverse: only 2 call sites, result local2 and its stack frames");System.out.println("PASS ASM BasicVerifier every method in both derivative classes; original field/API layout retained");
        System.out.println("CORE_UI_SHA256="+sha(canonical(a)));System.out.println("ADDON_SCREEN_SHA256="+sha(canonical(b)));System.out.println("LIMIT private CPU-only prototype, no real Minecraft classload/client/Mixin/GPU/packet proof; not packaged");
    }
}
