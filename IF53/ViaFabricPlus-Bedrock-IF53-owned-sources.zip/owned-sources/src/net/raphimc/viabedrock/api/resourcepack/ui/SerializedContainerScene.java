package net.raphimc.viabedrock.api.resourcepack.ui;

import com.viaversion.viaversion.libs.gson.JsonObject;

/** One resolution's scene and the exact String already checked against its UTF-8 limit.
 * The caller must treat scene as read-only while using json; this is not a cache.
 */
public record SerializedContainerScene(JsonObject scene, String json) {
    public static SerializedContainerScene of(JsonObject scene, String json) {
        return new SerializedContainerScene(scene, json);
    }

    /** Retains the legacy resolve-null branch at the screen's existing guard. */
    public static JsonObject sceneOrNull(SerializedContainerScene resolved) {
        return resolved == null ? null : resolved.scene();
    }
}
