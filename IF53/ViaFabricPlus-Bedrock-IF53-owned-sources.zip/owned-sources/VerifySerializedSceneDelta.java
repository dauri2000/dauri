import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import java.io.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

/** Separate recognizer/inverse, written against the emitted bytecode contract. */
public final class VerifySerializedSceneDelta implements Opcodes {
    static final String U="net/raphimc/viabedrock/api/resourcepack/ui/ContainerUi",V=U+"$MenuView";
    static final String R="net/raphimc/viabedrock/api/resourcepack/ui/SerializedContainerScene";
    static final String J="com/viaversion/viaversion/libs/gson/JsonObject";
    static final String S="com/viaversion/viafabricplus/bedrock/screen/container/BedrockNativeContainerScreen";
    static final String OD="(L"+V+";)L"+J+";",ND="(L"+V+";)L"+R+";";
    static int checks;
    static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}
    static ClassNode read(byte[]b){var c=new ClassNode();new ClassReader(b).accept(c,ClassReader.EXPAND_FRAMES);return c;}
    static byte[] bytes(ClassNode c){var w=new ClassWriter(0);c.accept(w);return w.toByteArray();}
    static MethodNode m(ClassNode c,String n){return c.methods.stream().filter(x->x.name.equals(n)).findFirst().orElseThrow();}
    static byte[] methodCode(MethodNode source){var copy=new MethodNode(ASM9,source.access,source.name,source.desc,source.signature,source.exceptions.toArray(String[]::new));source.accept(copy);copy.localVariables=null;for(var n:copy.instructions.toArray())if(n instanceof LineNumberNode)copy.instructions.remove(n);var c=new ClassNode();c.version=V25;c.access=ACC_PUBLIC|ACC_SUPER;c.name=U;c.superName="java/lang/Object";c.methods.add(copy);return bytes(c);}
    static int callCount(MethodNode m,String owner,String name){int count=0;for(var n:m.instructions)if(n instanceof MethodInsnNode x&&x.owner.equals(owner)&&x.name.equals(name))count++;return count;}
    static int frameReplace(MethodNode m,String a,String b,int slot){int count=0;for(var n:m.instructions)if(n instanceof FrameNode f&&f.local!=null&&f.local.size()>slot&&Objects.equals(f.local.get(slot),a)){f.local.set(slot,b);count++;}return count;}
    public static void main(String[]a)throws Exception{
        byte[] core,screenOriginal,uiOriginal=null;try(var z=new ZipFile(a[0])){core=z.getInputStream(z.getEntry("META-INF/jars/ViaBedrock-0.0.31-StackAnvil.jar")).readAllBytes();screenOriginal=z.getInputStream(z.getEntry(S+".class")).readAllBytes();}
        try(var z=new ZipInputStream(new ByteArrayInputStream(core))){for(ZipEntry e;(e=z.getNextEntry())!=null;)if(e.getName().equals(U+".class")){uiOriginal=z.readAllBytes();break;}}
        var p=Path.of(a[1]);var ui=read(Files.readAllBytes(p.resolve("core/"+U+".class")));var screen=read(Files.readAllBytes(p.resolve("addon/"+S+".class")));var helper=read(Files.readAllBytes(p.resolve("core/"+R+".class")));
        check(uiOriginal!=null,"Original UI exists");var old=read(uiOriginal);
        check(ui.methods.size()==old.methods.size()+2,"Exactly two added UI methods");check(ui.fields.size()==old.fields.size(),"No added UI state");
        var wrap=m(ui,"resolveSerialized");check(wrap.desc.equals(ND)&&wrap.access==ACC_PUBLIC,"Public added API");check(callCount(wrap,U,"resolveSerializedScene")==1,"Exactly one resolver delegate");
        wrap.name="resolve";wrap.desc=OD;for(var n:wrap.instructions)if(n instanceof MethodInsnNode x&&x.owner.equals(U)&&x.name.equals("resolveSerializedScene")){x.name="resolveScene";x.desc=OD;}
        check(Arrays.equals(methodCode(wrap),methodCode(m(old,"resolve"))),"Exact old wrapper code and catch table after inverse");
        var scene=m(ui,"resolveSerializedScene");check(scene.desc.equals(ND),"Added resolver descriptor");check(callCount(scene,U.replace("ContainerUi","JsonUiProgram"),"resolveScreen")==1,"Exactly one underlying resolution");check(callCount(scene,J,"toString")==1,"Exactly one resolution serialization");check(callCount(scene,"java/lang/String","getBytes")==1,"Exactly one original byte-length check");check(callCount(scene,R,"of")==1,"Exactly one paired result construction");
        int saves=0,results=0;for(var n:scene.instructions.toArray())if(n instanceof MethodInsnNode x&&x.owner.equals(J)&&x.name.equals("toString")){
            var dup=x.getNext();var store=dup.getNext();check(dup.getOpcode()==DUP&&store instanceof VarInsnNode v&&v.getOpcode()==ASTORE&&v.var==7,"Preserve exact serialized String in dead local7");scene.instructions.remove(dup);scene.instructions.remove(store);saves++;
        }
        for(var n:scene.instructions.toArray())if(n instanceof MethodInsnNode x&&x.owner.equals(R)&&x.name.equals("of")){
            var load=x.getPrevious();check(load instanceof VarInsnNode v&&v.getOpcode()==ALOAD&&v.var==7,"Return uses checked exact String");scene.instructions.remove(load);scene.instructions.remove(x);results++;
        }
        check(saves==1&&results==1,"Exactly two local pair additions inverse");check(frameReplace(scene,"java/lang/String","com/viaversion/viaversion/libs/gson/JsonArray",7)==1,"One final local type frame inverse");scene.name="resolveScene";scene.desc=OD;
        check(Arrays.equals(methodCode(scene),methodCode(m(old,"resolveScene"))),"Exact resolution code incl UTF8 and strict limit after inverse");
        ui.methods.remove(wrap);ui.methods.remove(scene);check(Arrays.equals(bytes(ui),bytes(old)),"Full original class restored including all legacy method bodies/fields");
        var refresh=m(screen,"refresh");check(callCount(refresh,U,"resolveSerialized")==1&&callCount(refresh,U,"resolve")==0,"Screen uses new API once");check(callCount(refresh,J,"toString")==0&&callCount(refresh,R,"json")==1,"Screen has no duplicate scene serialization");
        int resolutions=0,strings=0;for(var n:refresh.instructions.toArray())if(n instanceof MethodInsnNode x&&x.owner.equals(U)&&x.name.equals("resolveSerialized")){
            var dup=x.getNext();var store=dup.getNext();var unwrap=store.getNext();check(dup.getOpcode()==DUP&&store instanceof VarInsnNode v&&v.getOpcode()==ASTORE&&v.var==2&&unwrap instanceof MethodInsnNode h&&h.getOpcode()==INVOKESTATIC&&h.owner.equals(R)&&h.name.equals("sceneOrNull"),"Nullable result wrapping exact pattern");refresh.instructions.remove(dup);refresh.instructions.remove(store);refresh.instructions.remove(unwrap);x.name="resolve";x.desc=OD;resolutions++;
        }
        for(var n:refresh.instructions.toArray())if(n instanceof MethodInsnNode x&&x.owner.equals(R)&&x.name.equals("json")){
            var load=x.getPrevious();check(load instanceof VarInsnNode v&&v.getOpcode()==ALOAD&&v.var==2,"Screen exact per-call result source");((VarInsnNode)load).var=3;x.owner=J;x.name="toString";strings++;
        }
        check(resolutions==1&&strings==1,"Exact two screen callsite inverse");check(frameReplace(refresh,R,V,2)>0,"Local2 frame type restored");refresh.maxStack=m(read(screenOriginal),"refresh").maxStack;check(Arrays.equals(bytes(screen),bytes(read(screenOriginal))),"Full screen canonical inverse exact");
        check(helper.fields.size()==2&&helper.fields.stream().allMatch(f->(f.access&ACC_STATIC)==0&&(f.access&ACC_FINAL)!=0),"Helper has only two final per-result fields; no cache");
        for(var layer:List.of("core","addon"))for(Path f:Files.walk(p.resolve(layer)).filter(f->f.toString().endsWith(".class")).toList()){var c=read(Files.readAllBytes(f));for(var method:c.methods)if((method.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,method);checks++;}
        System.out.println("PASS independent static delta checks="+checks+"; exact full-class inverses; unchanged legacy APIs, one resolver+serialization, exact UTF8 limit, nullable screen guard, no global state.");
        System.out.println("LIMIT screen JVM/MC/Fabric execution not performed; ASM verification is a static boundary.");
    }
}
