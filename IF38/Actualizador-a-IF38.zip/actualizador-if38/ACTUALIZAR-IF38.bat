@echo off
setlocal
if "%~1"=="" (
    java -jar "%~dp0Actualizar-a-IF38.jar"
) else (
    if "%~2"=="" (
        java -jar "%~dp0Actualizar-a-IF38.jar" "%~1" "%~dp0."
    ) else (
        java -jar "%~dp0Actualizar-a-IF38.jar" "%~1" "%~2"
    )
)
set "IF38_UPDATE_EXIT=%ERRORLEVEL%"
if not "%IF38_UPDATE_EXIT%"=="0" echo Revisa el mensaje anterior. Se necesita Java 17 o superior accesible con el comando java.
pause
exit /b %IF38_UPDATE_EXIT%
