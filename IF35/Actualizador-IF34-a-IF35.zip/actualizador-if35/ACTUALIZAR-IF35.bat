@echo off
setlocal
if "%~1"=="" (
    java -jar "%~dp0Actualizar-IF34-a-IF35.jar"
) else (
    if "%~2"=="" (
        java -jar "%~dp0Actualizar-IF34-a-IF35.jar" "%~1" "%~dp0."
    ) else (
        java -jar "%~dp0Actualizar-IF34-a-IF35.jar" "%~1" "%~2"
    )
)
set "IF35_UPDATE_EXIT=%ERRORLEVEL%"
if not "%IF35_UPDATE_EXIT%"=="0" echo Revisa el mensaje anterior. Se necesita Java 17 o superior accesible con el comando java.
pause
exit /b %IF35_UPDATE_EXIT%
